import React, { createContext, useEffect, useState } from "react";
import Cookies from "js-cookie";
import { v4 as uuidv4 } from "uuid";
import { useDispatch } from "react-redux";
import { getCartItems } from "../redux/features/CartService";

export const AuthContext = createContext();

export const Authprovider = (props) => {
  const accessToken = Cookies.get("stashed_token");
  // const [authStatus, setAuthStatus] = useState(AuthStatus.loading);
  const [authStatus, setAuthStatus] = useState(0);

  const dispatch = useDispatch();

  const updateAuthStatus = (status) => {
    setAuthStatus(status);
    if (accessToken) {
      setAuthStatus(1);
    } else {
      setAuthStatus(status);
    }
  };

  useEffect(() => {
    if (accessToken) {
      updateAuthStatus(1);
      dispatch(getCartItems());
      Cookies.remove("guest_user_id");
    } else {
      updateAuthStatus(0);
      if (!Cookies.get("guest_user_id")) {
        Cookies.set("guest_user_id", uuidv4());
      }
    }
  }, []);

  return (
    <AuthContext.Provider value={{ authStatus, updateAuthStatus }}>
      {props.children}
    </AuthContext.Provider>
  );
};
