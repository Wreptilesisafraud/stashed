import { combineReducers } from "redux";
import storage from "redux-persist/lib/storage";
import authReducer from "./features/AuthsService";
import categoryReducer from "./features/CategoryService";
import productReducer from "./features/ProductService";
import homeReducer from "./features/HomeService";
import blogReducer from "./features/BlogService";
import catalogReducer from "./features/CatalogService";
import footerReducer from "./features/FooterService";
import aboutUsReducer from "./features/AboutUsService";
import orderReducer from "./features/OrderService";
import walletReducer from "./features/WalletService";
import transactionReducer from "./features/TranscationService";
import userReducer from "./features/UserService";
import cartReducer from "./features/CartService";
import pageReducer from "./features/PageService";
import newsletterReducer from "./features/SubscribeNewsletterService";

const rootPersistConfig = {
  key: "root",
  storage,
  keyPrefix: "redux-",
  whitelist: [],
};

const rootReducer = combineReducers({
  auths: authReducer,
  categorys: categoryReducer,
  products: productReducer,
  home: homeReducer,
  blogs: blogReducer,
  catalogs: catalogReducer,
  footers: footerReducer,
  aboutUs: aboutUsReducer,
  orders: orderReducer,
  wallets: walletReducer,
  transactions: transactionReducer,
  users: userReducer,
  cart: cartReducer,
  page: pageReducer,
  newsletter: newsletterReducer,
});

export { rootPersistConfig, rootReducer };
