import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetCatalogListData = createAsyncThunk(
  "catalogs/getCatalog",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/catalog`, {
        headers: getHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const CatalogSlice = createSlice({
  name: "catalogs",
  initialState: {
    error: false,
    loading: false,
    catalogData: [],
  },
  reducers: {
    setCatalogPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetCatalogListData.pending]: (state) => {
      state.loading = true;
    },
    [GetCatalogListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.catalogData = action.payload;
    },
    [GetCatalogListData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setCatalogPage } = CatalogSlice.actions;

export default CatalogSlice.reducer;
