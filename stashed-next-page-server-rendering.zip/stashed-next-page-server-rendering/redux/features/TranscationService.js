import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getAuthenticationHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetTransactionData = createAsyncThunk(
  "transactions/GetTransactionData",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/transactions`, {
        headers: getAuthenticationHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const TransactionSlice = createSlice({
  name: "transactions",
  initialState: {
    error: false,
    loading: false,
    transactionsListData: [],
  },
  reducers: {
    setTransactionPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetTransactionData.pending]: (state) => {
      state.loading = true;
    },
    [GetTransactionData.fulfilled]: (state, action) => {
      state.loading = false;
      state.transactionsListData = action.payload;
    },
    [GetTransactionData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setTransactionPage } = TransactionSlice.actions;

export default TransactionSlice.reducer;
