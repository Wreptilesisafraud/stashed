import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const SubscribeToNewsLetter = createAsyncThunk(
  "SubscribeNewsletter/getSubscribeNewsletterList",
  async (args, { rejectWithValue }) => {
    try {
      const resp = await axios.post(`${url}/subscribers`, args, {
        headers: getHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const SubscribeNewsletterSlice = createSlice({
  name: "SubscribeNewsletter",
  initialState: {
    error: false,
    loading: false,
    SubscribeNewsletterData: null,
  },
  extraReducers: {
    [SubscribeToNewsLetter.pending]: (state) => {
      state.loading = true;
    },
    [SubscribeToNewsLetter.fulfilled]: (state, action) => {
      state.loading = false;
      state.SubscribeNewsletterData = action.payload;
    },
    [SubscribeToNewsLetter.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setSubscribeNewsletterPage } = SubscribeNewsletterSlice.actions;

export default SubscribeNewsletterSlice.reducer;
