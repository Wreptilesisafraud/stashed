import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getAuthenticationHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetWalletData = createAsyncThunk(
  "orders/GetWalletData",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/wallet`, {
        headers: getAuthenticationHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const StripeWalletUpdate = createAsyncThunk(
  "orders/WalletUpdate",
  async (args, { getState, dispatch, rejectWithValue }) => {
    const data = {
      transactionStatus: args.transactionStatus,
      paymentStatus: args.paymentStatus,
      sessionId: args.sessionId,
    };
    try {
      const resp = await axios.post(`${url}/stripe/wallet/update`, data, {
        headers: getAuthenticationHeader(),
      });
      return resp;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const GetPaymentUrl = createAsyncThunk(
  "orders/GetPaymentUrl",
  async (payload, { rejectWithValue }) => {
    try {
      console.log("payload", payload);
      const response = await axios.post(`${url}/stripe/wallet`, payload, {
        headers: getAuthenticationHeader(),
      });
      return response;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const WalletSlice = createSlice({
  name: "wallets",
  initialState: {
    error: false,
    loading: false,
    walletListData: [],
  },
  reducers: {
    setWalletPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetWalletData.pending]: (state) => {
      state.loading = true;
    },
    [GetWalletData.fulfilled]: (state, action) => {
      state.loading = false;
      state.walletListData = action.payload;
    },
    [GetWalletData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setWalletPage } = WalletSlice.actions;

export default WalletSlice.reducer;
