import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetCategoryListData = createAsyncThunk(
  "categorys/category",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/category-list?parent_id=0`, {
        headers: getHeader(),
      });

      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const GetSingleCategoryData = createAsyncThunk(
  "categorys/single-category",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/category-list`, {
        headers: getHeader(),
      });

      return resp.data.data;
      // return resp.data.data?.find(cat => cat.slug === _.categoryId);
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const CategorySlice = createSlice({
  name: "categorys",
  initialState: {
    error: false,
    loading: false,
    categoryData: [],
  },
  reducers: {
    setCategoryPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetCategoryListData.pending]: (state) => {
      state.loading = true;
    },
    [GetCategoryListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.categoryData = action.payload.data;
    },
    [GetCategoryListData.rejected]: (state) => {
      state.loading = false;
    },

    [GetSingleCategoryData.pending]: (state) => {
      state.loading = true;
    },
    [GetSingleCategoryData.fulfilled]: (state, action) => {
      state.loading = false;
      // state.categoryData = action.payload.data;
    },
    [GetSingleCategoryData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setCategoryPage } = CategorySlice.actions;

export default CategorySlice.reducer;
