import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetProductListData = createAsyncThunk(
  "products/products",
  async (args, { rejectWithValue }) => {
    const { categoryId } = args;
    try {
      if (!categoryId) return;
      const resp = await axios.get(
        `${url}/products-list?category_id=${categoryId}&include[category]=${categoryId}`,
        {
          headers: getHeader(),
        }
      );
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const GetParentProductListData = createAsyncThunk(
  "products/products",
  async (args, { rejectWithValue }) => {
    const { categoryId, childCategoryId } = args;
    try {
      const resp = await axios.get(
        `${url}/products-list?category_slug=${categoryId}&include[category]=${categoryId}`,
        {
          headers: getHeader(),
        }
      );
      return {
        ...resp.data,
        categoryIdMatch: categoryId,
        childCategoryIdMatch: childCategoryId,
      };
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const GetCategoryProductListData = createAsyncThunk(
  "products/category-products",
  async (args, { rejectWithValue }) => {
    const { categoryId, childCategoryId, page = 1, listPerPage } = args;
    const cat = childCategoryId
      ? `${categoryId},${childCategoryId}`
      : `${categoryId}`;
    try {
      const resp = await axios.get(
        `${url}/products-list-1?category_slug=${cat}&include[category]=${categoryId}&page=${page}&per_page=${listPerPage}`,
        {
          headers: getHeader(),
        }
      );
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

// export const GetCategoryProductListData = createAsyncThunk(
//   "products/category-products",
//   async (args, { rejectWithValue }) => {
//     const { categoryId } = args;
//     try {
//       const resp = await axios.get(`${url}/products-list?category_slug=${categoryId}&include[category]=${categoryId}`, {
//         headers: getHeader(),
//       });
//       return resp.data;
//     } catch (err) {
//       return rejectWithValue(err);
//     }
//   }
// );

export const GetSingleProductListData = createAsyncThunk(
  "products/singleProduct",
  async (args, { rejectWithValue }) => {
    const { categoryId, childCategoryId, productId } = args;
    try {
      const resp = await axios.get(
        `${url}/products-list?slug=${productId}&include[category]=${categoryId}&include[with]=variation_list,groups.items,tags`,
        {
          headers: getHeader(),
        }
      );
      return {
        ...resp.data,
        categoryIdMatch: categoryId,
        subCategoryIdMatch: childCategoryId,
      };
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const ProductSlice = createSlice({
  name: "products",
  initialState: {
    error: false,
    loading: false,
    productData: [],
    productListingData: [],
    singleProductData: [],
    singleProductCategoryData: [],
    subCategory: {},
  },
  reducers: {
    setProductPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetCategoryProductListData.pending]: (state) => {
      state.loading = true;
    },
    [GetCategoryProductListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.productListingData = action.payload.products.data.length
        ? action.payload.products.data
        : [];
    },
    [GetCategoryProductListData.rejected]: (state) => {
      state.loading = false;
    },
    [GetParentProductListData.pending]: (state) => {
      state.loading = true;
    },
    [GetParentProductListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.productData = action.payload.products.data.length
        ? action.payload.products.data
        : [];
      state.singleProductCategoryData =
        action.payload.products.data.length > 0
          ? action.payload.products.data[0].categories.length === 1
            ? action.payload.products.data[0].categories[0]
            : action.payload.products.data[0].categories.find(
                (categoryData) =>
                  categoryData.slug === action.payload.categoryIdMatch
              )
          : null;
    },
    [GetParentProductListData.rejected]: (state) => {
      state.loading = false;
    },
    [GetProductListData.pending]: (state) => {
      state.loading = true;
    },
    [GetProductListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.productData = action.payload.products.data.length
        ? action.payload.products.data
        : [];
      state.singleProductCategoryData =
        action.payload.products.data.length > 0
          ? action.payload.products.data[0].categories.length === 1
            ? action.payload.products.data[0].categories[0]
            : action.payload.products.data[0].categories.filter(
                (categoryData) =>
                  categoryData.id !== action.payload.categoryIdMatch
              )[0]
          : null;
    },
    [GetProductListData.rejected]: (state) => {
      state.loading = false;
    },
    [GetSingleProductListData.pending]: (state) => {
      state.loading = true;
    },
    [GetSingleProductListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.singleProductData = action.payload.products.data[0];
      state.singleProductCategoryData =
        action.payload.products.data[0].categories.length === 1
          ? action.payload.products.data[0].categories[0]
          : action.payload.products.data[0].categories.filter(
              (categoryData) =>
                categoryData.id !== action.payload.categoryIdMatch
            )[0];
      state.subCategory = action.payload.products.data.length
        ? action.payload.products.data[0]?.categories.find(
            (cat) => cat.slug === action.payload.subCategoryIdMatch
          )
        : "";
    },
    [GetSingleProductListData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setProductPage } = ProductSlice.actions;

export default ProductSlice.reducer;
