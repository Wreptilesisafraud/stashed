import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const SinglePageData = createAsyncThunk(
  "page/singlePage",
  async (args, { rejectWithValue }) => {
    const { slug } = args;
    try {
      const resp = await axios.get(`${url}/pages/${slug}`, {
        headers: getHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const PageSlice = createSlice({
  name: "page",
  initialState: {
    error: false,
    loading: false,
    pagesData: [],
    singlePage: null,
    totalPage: 0,
  },
  reducers: {
    setPagePage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [SinglePageData.pending]: (state) => {
      state.loading = true;
    },
    [SinglePageData.fulfilled]: (state, action) => {
      state.loading = false;
      state.singlePage = action.payload;
    },
    [SinglePageData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setPagePage } = PageSlice.actions;

export default PageSlice.reducer;
