import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getAuthenticationHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const getCartItems = createAsyncThunk(
  "cart/get",
  async (_, { rejectWithValue }) => {
    const response = await axios.get(`${url}/carts`, {
      headers: getAuthenticationHeader(),
    });
    return response.data;
  }
);

export const addCartItem = createAsyncThunk(
  "cart/add",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${url}/carts/add`, payload, {
        headers: getAuthenticationHeader(),
      });
      return response.data;
    } catch (err) {
      // console.log(err);
      return rejectWithValue(err);
    }
  }
);

export const removeCartItem = createAsyncThunk(
  "cart/remove",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${url}/carts/delete`,
        { cart_id: payload },
        { headers: getAuthenticationHeader() }
      );

      return response.data;
    } catch (err) {
      // console.log(err);
      return rejectWithValue(err);
    }
  }
);

export const clearCart = createAsyncThunk(
  "cart/clear",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${url}/carts/clear`,
        {},
        { headers: getAuthenticationHeader() }
      );

      return response;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const checkoutStripe = createAsyncThunk(
  "cart/checkout",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${url}/stripe/create-session`,
        payload,
        { headers: getAuthenticationHeader() }
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const completedPayment = createAsyncThunk(
  "cart/complate_order",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${url}/checkout/completed`, payload, {
        headers: getAuthenticationHeader(),
      });
      return response.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const applyCouponCart = createAsyncThunk(
  "cart/apply-coupon",
  async (payload, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${url}/carts/apply-coupon`, payload, {
        headers: getAuthenticationHeader(),
      });
      console.log(response);
      return response.data;
    } catch (err) {
      // console.log(err);
      return rejectWithValue(err);
    }
  }
);

const cartSlice = createSlice({
  name: "cart",
  initialState: {
    error: false,
    loading: false,
    preCartItem: null, // this is for cart item before login
    cartItems: [],
    totalPrice: 0,
  },
  reducers: {
    addPreCartItem: (state, action) => {
      state.preCartItem = action.payload;
    },
  },
  extraReducers: {
    [applyCouponCart.pending]: (state) => {
      state.loading = true;
    },
    [applyCouponCart.fulfilled]: (state, action) => {
      state.loading = false;
      console.log(action.payload);
      // state.cartItems = action.payload.carts;
      // state.totalPrice = action.payload.total;
    },
    [applyCouponCart.rejected]: (state) => {
      state.loading = false;
    },
    [getCartItems.pending]: (state) => {
      state.loading = true;
    },
    [getCartItems.fulfilled]: (state, action) => {
      state.loading = false;
      state.cartItems = action.payload.carts;
      state.totalPrice = action.payload.total;
    },
    [getCartItems.rejected]: (state) => {
      state.loading = false;
    },
    [addCartItem.pending]: (state) => {
      state.loading = true;
      state.error = false;
    },
    [addCartItem.fulfilled]: (state, action) => {
      state.loading = false;
      state.cartItems = action.payload.carts;
      state.totalPrice = action.payload.total;
    },
    [addCartItem.rejected]: (state, action) => {
      state.loading = false;
      state.error = true;
    },
    [removeCartItem.pending]: (state, action) => {
      state.loading = true;
    },
    [removeCartItem.fulfilled]: (state, action) => {
      state.loading = false;
      state.cartItems = action.payload.carts;
      state.totalPrice = action.payload.total;
    },
    [removeCartItem.rejected]: (state, action) => {
      state.loading = false;
    },
    [checkoutStripe.pending]: (state, action) => {
      state.loading = true;
    },
    [checkoutStripe.fulfilled]: (state, action) => {
      state.error = false;
      state.loading = false;
      state.cartItems = [];
    },
    [checkoutStripe.rejected]: (state, action) => {
      state.loading = false;
    },
    [completedPayment.pending]: (state, action) => {
      state.loading = true;
    },
    [completedPayment.fulfilled]: (state, action) => {
      state.loading = false;
      // state.cartItems = [];
    },
    [clearCart.pending]: (state, action) => {
      state.loading = true;
    },
    [clearCart.fulfilled]: (state, action) => {
      state.error = false;
      state.loading = false;
      state.cartItems = [];
      state.totalPrice = 0;
      state.preCartItem = null;
    },
    [clearCart.rejected]: (state, action) => {
      state.loading = false;
    },
  },
});

export const { addPreCartItem } = cartSlice.actions;

export default cartSlice.reducer;
