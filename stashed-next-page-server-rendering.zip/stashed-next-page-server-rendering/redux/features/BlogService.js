import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetCategoryBlogListData = createAsyncThunk(
  "blogs/getCategoryBlogList",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/blog?category=true`, {
        headers: getHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const GetBlogListData = createAsyncThunk(
  "blogs/getBlogListData",
  async (args, { rejectWithValue }) => {
    const { categoryId, perPage, search } = args;
    try {
      const resp = await axios.get(
        `${url}/blog?category=true&category_id=${categoryId}&per_page=${perPage}&search=${search}`,
        {
          headers: getHeader(),
        }
      );
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const SignleBlogListData = createAsyncThunk(
  "blogs/singleBlogList",
  async (args, { rejectWithValue }) => {
    const { slug } = args;
    try {
      const resp = await axios.get(`${url}/blog/${slug}`, {
        headers: getHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const BlogSlice = createSlice({
  name: "blogs",
  initialState: {
    error: false,
    loading: false,
    categoriesBlogData: [],
    blogsData: [],
    singleBlogDetail: null,
    totalBlog: 0,
  },
  reducers: {
    setBlogPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetCategoryBlogListData.pending]: (state) => {
      state.loading = true;
    },
    [GetCategoryBlogListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.categoriesBlogData = action.payload.categories;
    },
    [GetCategoryBlogListData.rejected]: (state) => {
      state.loading = false;
    },
    [GetBlogListData.pending]: (state) => {
      state.loading = true;
    },
    [GetBlogListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.totalBlog = action.payload.blogs.total;
      state.blogsData = action.payload.blogs.data;
    },
    [GetBlogListData.rejected]: (state) => {
      state.loading = false;
    },
    [SignleBlogListData.pending]: (state) => {
      state.loading = true;
    },
    [SignleBlogListData.fulfilled]: (state, action) => {
      state.loading = false;
      state.singleBlogDetail = action.payload.blog;
    },
    [SignleBlogListData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setBlogPage } = BlogSlice.actions;

export default BlogSlice.reducer;
