import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getAuthenticationHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetUserData = createAsyncThunk(
  "users/GetUserData",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/customer-profile`, {
        headers: getAuthenticationHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const UpdateSecurityData = createAsyncThunk(
  "users/UpdateSecurityData",
  async (args, { rejectWithValue }) => {
    try {
      const resp = await axios.post(`${url}/customer-profile`, args, {
        headers: getAuthenticationHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const UserSessionsLogoutData = createAsyncThunk(
  "users/SessionsLogout",
  async (args, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/all-logout`, args, {
        headers: getAuthenticationHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);
export const UpdateUserData = createAsyncThunk(
  "users/UpdateUserData",
  async (args, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      formData.append("avatar", args);
      const headers = {
        ...getAuthenticationHeader(),
        "Content-Type": "multipart/form-data",
      };
      const resp = await axios.post(
        `${url}/customer-profile?type=info`,
        formData,
        {
          headers: headers,
        }
      );
      return resp?.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const UserSlice = createSlice({
  name: "users",
  initialState: {
    error: false,
    loading: false,
    userData: [],
  },
  reducers: {
    setUserPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetUserData.pending]: (state) => {
      state.loading = true;
    },
    [GetUserData.fulfilled]: (state, action) => {
      state.loading = false;
      state.userData = action.payload.user;
    },
    [GetUserData.rejected]: (state) => {
      state.loading = false;
    },
    [UpdateSecurityData.pending]: (state) => {
      state.loading = true;
    },
    [UpdateSecurityData.fulfilled]: (state, action) => {
      state.loading = false;
      // state.userData = action.payload;
    },
    [UpdateSecurityData.rejected]: (state) => {
      state.loading = false;
    },
    [UpdateUserData.pending]: (state) => {
      state.loading = true;
    },
    [UpdateUserData.fulfilled]: (state, action) => {
      state.loading = false;
      // state.userData = action.payload;
    },
    [UpdateUserData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setUserPage } = UserSlice.actions;

export default UserSlice.reducer;
