import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const HomePageService = createAsyncThunk(
  "home/homes",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/home`, {
        headers: getHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const HomeSlice = createSlice({
  name: "home",
  initialState: {
    error: false,
    loading: false,
    homeSliderData: [],
    faqData: [],
    giftData: [],
    featuresData: [],
    feedBackData: [],
    bannerSectionData: [],
    trustpilot: "",
  },
  reducers: {
    setHomePage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [HomePageService.pending]: (state) => {
      state.loading = true;
    },
    [HomePageService.fulfilled]: (state, action) => {
      // console.log(action.payload)
      state.loading = false;
      state.homeSliderData = action.payload.hero_sliders ?? [];
      state.faqData = action.payload.faq ?? [];
      state.giftData = action.payload.gift ?? [];
      state.featuresData = action.payload.features ?? [];
      state.feedBackData = action.payload.client_feedback ?? [];
      state.bannerSectionData = action.payload.banner_section_one_banners
        ? action.payload.banner_section_one_banners[0]
        : null;
      state.trustpilot = action.payload.trustpilot;
    },
    [HomePageService.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setHomePage } = HomeSlice.actions;

export default HomeSlice.reducer;
