import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getAuthenticationHeader, getHeader } from "../../utils/axiosHeader";
import { addCartItem } from "./CartService";

let url = process.env.NEXT_PUBLIC_API_URL;

export const SignUpService = createAsyncThunk(
  "auth/SignUp",
  async (args, { rejectWithValue }) => {
    const data = {
      name: args.name,
      email: args.email,
      password: args.password,
      password_confirmation: args.password,
    };
    try {
      const resp = await axios.post(`${url}/register`, data, {
        headers: getHeader(),
      });
      return resp;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const SignInService = createAsyncThunk(
  "auth/SignIn",
  async (args, { getState, dispatch, rejectWithValue }) => {
    const data = {
      email: args.email,
      password: args.password,
    };
    try {
      const resp = await axios.post(`${url}/login`, data, {
        headers: getHeader(),
      });

      return resp;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const ForgetPasswordService = createAsyncThunk(
  "auth/ForgetPassword",
  async (args, { getState, dispatch, rejectWithValue }) => {
    const data = {
      email: args.email,
    };
    try {
      const resp = await axios.post(`${url}/password/email`, data, {
        headers: getHeader(),
      });
      return resp;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const LogoutService = createAsyncThunk(
  "auth/Logout",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/logout`, {
        headers: getAuthenticationHeader(),
      });
      return resp;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const SignInGoogleService = createAsyncThunk(
  "auth/SignInGoogle",
  async (args, { getState, dispatch, rejectWithValue }) => {
    try {
      const resp = await axios.get(
        `${url}/social-login/google/callback?` + new URLSearchParams(args),
        {
          headers: getHeader(),
        }
      );

      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

export const SignInGoogleURLService = createAsyncThunk(
  "auth/SignIn",
  async (args, { getState, dispatch, rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/social-login/redirect/google`, {
        headers: getHeader(),
      });

      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const AuthSlice = createSlice({
  name: "auth",
  initialState: {
    error: "",
    loading: false,
    googleUrl: "",
  },
  reducers: {
    setAuthPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [SignUpService.pending]: (state) => {
      state.loading = true;
    },
    [SignUpService.fulfilled]: (state, action) => {
      state.loading = false;
    },
    [SignUpService.rejected]: (state) => {
      state.loading = false;
    },
    [SignInService.pending]: (state) => {
      state.loading = true;
    },
    [SignInService.fulfilled]: (state, action) => {
      state.loading = false;
    },
    [SignInService.rejected]: (state) => {
      state.loading = false;
    },
    [LogoutService.pending]: (state) => {
      state.loading = true;
    },
    [LogoutService.fulfilled]: (state, action) => {
      state.loading = false;
      console.log("action.payload", action.payload);
    },
    [LogoutService.rejected]: (state) => {
      state.loading = false;
    },
    [SignInGoogleURLService.pending]: (state) => {
      state.loading = true;
      state.googleUrl = "";
    },
    [SignInGoogleURLService.fulfilled]: (state, action) => {
      state.loading = false;
      console.log(action.payload.url, "action.payload.url");
      state.googleUrl = action.payload.url;
    },
    [SignInGoogleURLService.rejected]: (state) => {
      state.loading = false;
      state.googleUrl = "";
    },
  },
});

export const { setAuthPage } = AuthSlice.actions;

export default AuthSlice.reducer;
