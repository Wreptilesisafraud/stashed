import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getAuthenticationHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetOrderData = createAsyncThunk(
  "orders/GetOrderData",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/orders`, {
        headers: getAuthenticationHeader(),
      });
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const OrderSlice = createSlice({
  name: "orders",
  initialState: {
    error: false,
    loading: false,
    orderListData: [],
  },
  reducers: {
    setOrderPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetOrderData.pending]: (state) => {
      state.loading = true;
    },
    [GetOrderData.fulfilled]: (state, action) => {
      state.loading = false;
      state.orderListData = action.payload.orders?.data;
    },
    [GetOrderData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setOrderPage } = OrderSlice.actions;

export default OrderSlice.reducer;
