import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../../utils/axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const GetAboutUsData = createAsyncThunk(
  "aboutUs/getAboutUsList",
  async (_, { rejectWithValue }) => {
    try {
      const resp = await axios.get(`${url}/about`, {
        headers: getHeader(),
      });
      console.log("in redux", resp.data);
      return resp.data;
    } catch (err) {
      return rejectWithValue(err);
    }
  }
);

const AboutUsSlice = createSlice({
  name: "aboutUs",
  initialState: {
    error: false,
    loading: false,
    aboutUsData: null,
  },
  reducers: {
    setAboutUsPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: {
    [GetAboutUsData.pending]: (state) => {
      state.loading = true;
    },
    [GetAboutUsData.fulfilled]: (state, action) => {
      state.loading = false;
      state.aboutUsData = action.payload;
    },
    [GetAboutUsData.rejected]: (state) => {
      state.loading = false;
    },
  },
});

export const { setAboutUsPage } = AboutUsSlice.actions;

export default AboutUsSlice.reducer;
