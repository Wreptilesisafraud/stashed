import React, { useEffect, useState } from "react";
import { Nav, Button, Offcanvas, NavDropdown } from "react-bootstrap";
// import { useNavigate } from "react-router-dom";
import { useRouter } from "next/navigation";

// Images
import TextAlignLeft from "../../../assets/images/TextAlignLeft.svg";
import { handleOnClickBlock, handleOnClickNon } from "../../../utils/designs";
import { useDispatch, useSelector } from "react-redux";
import { GetCatalogListData } from "../../../redux/features/CatalogService";
import { useDeviceWidth } from "../../../utils/useDeviceWidth";
import { isMobileUi } from "../../../utils/lib";
import Image from "next/image";
import Link from "next/link";

const UserDashboardSidebar = () => {
  const checkWidth = useDeviceWidth();
  const [show, setShow] = useState(false);
  const dispatch = useDispatch();
  const { catalogData } = useSelector((state) => state.catalogs);
  const [isCategoryData, setCategoryData] = useState([]);
  const router = useRouter();

  // useEffect(() => {
  //   dispatch(GetCatalogListData());
  // }, [dispatch]);

  useEffect(() => {
    if (catalogData.length) {
      const parentCategries = [];
      catalogData.forEach((element) => {
        const childCat = element.child_categories.filter(
          (cat) => cat.products.length > 0
        );
        if (childCat.length > 0) {
          parentCategries.push({
            id: element.id,
            slug: element.slug,
            name: element.name,
            child_categories: childCat,
          });
        }
      });
      setCategoryData((prev) => parentCategries);
    }
  }, [catalogData]);

  const handleClose = () => {
    setShow(false);
    handleOnClickBlock();
  };
  const handleShow = () => {
    setShow(true);
    handleOnClickNon();
  };

  const handleCategorySelectRedirect = (parentCat, childCat) => {
    setShow(false);
    router.push(`/games/${parentCat}/${childCat}`);
  };

  return (
    <>
      <Button className="buttonStyle1" variant="primary" onClick={handleShow}>
        <Image src={TextAlignLeft} alt="Catalog Icon" />
      </Button>
      <Offcanvas className="MenuSidebar" show={show} onHide={handleClose}>
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Choose game</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body className="scrollDesign_y">
          <Nav className="me-auto gap-5 flex-column">
            <div id="sidebar" className="UserSidebar">
              <div>
                {isCategoryData.map((parentCatDetail) => (
                  <p key={parentCatDetail.id} className="nav-link">
                    <NavDropdown
                      title={`${parentCatDetail.name}`}
                      id="basic-nav-dropdown"
                    >
                      {parentCatDetail?.child_categories.length > 0
                        ? parentCatDetail?.child_categories.map((childCat) => (
                            <p
                              onClick={() =>
                                handleCategorySelectRedirect(
                                  parentCatDetail.slug,
                                  childCat.slug
                                )
                              }
                              key={childCat.id}
                              className="dropdown-item"
                            >
                              {childCat.name}
                            </p>
                          ))
                        : ""}
                    </NavDropdown>
                  </p>
                ))}

                {isMobileUi(checkWidth) && (
                  <>
                    {" "}
                    <p className="nav-item mb-0">
                      <Nav title={`blog`} id="basic-nav-dropdown">
                        <Link href="/about" className="nav-link">
                          Work With Us
                        </Link>
                      </Nav>
                    </p>
                    <p className="nav-item mb-0">
                      <Nav title={`about`} id="basic-nav-dropdown">
                        <Link href="/blog" className="nav-link">
                          Blog
                        </Link>
                      </Nav>
                    </p>
                  </>
                )}
              </div>
            </div>
          </Nav>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
};

export default UserDashboardSidebar;
