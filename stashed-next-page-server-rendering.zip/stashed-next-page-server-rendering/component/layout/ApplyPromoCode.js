import { useState } from "react"
import { Button, Form, Spinner } from "react-bootstrap"
import { useDispatch, useSelector } from "react-redux"
import { toast } from "react-toastify"
import { applyCouponCart } from "../../redux/features/CartService"


const ApplyPromoCode = ({ cartItems }) => {
	const [promoCode, setPromoCode] = useState("")
	const [promoActive, setPromoActive] = useState(false)
	const dispatch = useDispatch();
	const { loading } = useSelector(state => state.cart)

	const handlePromocode = () => {
		if (promoCode?.length === 0) {
			toast.error("Please enter promocode")
			return false;
		}
		dispatch(applyCouponCart({ code: promoCode }));
	}
	// if()
	return (
		<>
			<div className="d-flex justify-content-between align-items-center py-2">
				<div>Apply promo code</div>
				<div className="d-flex justify-content-between align-items-center">
					{!promoActive && <b onClick={() => setPromoActive(true)}>+</b>}
					{
						promoActive &&
						<>
							<Form.Control
								style={{ width: "110px" }}
								className="me-2"
								type="text"
								name="name"
								placeholder="Enter code"
								onChange={e => setPromoCode(e.target.value)}
							/>
							<Button
								style={{ minWidth: "auto" }}
								variant="primary"
								type="button"
								className="buttonStyle1 submitBtn px-2"
								disabled={promoCode?.length === 0 || loading ? true : false}
								onClick={handlePromocode}
							>
								{!loading ? 'Apply' : <Spinner size="sm" />}
							</Button>
						</>
					}
				</div>
			</div>
			<hr className="m-0" />
		</>
	)
}

export default ApplyPromoCode