import React, { useEffect } from "react";
import { Row, Col } from "react-bootstrap";
// Images
import FacebookIcon from "../../assets/images/FacebookIcon.png";
import InstagramIcon from "../../assets/images/InstagramIcon.png";
import TwitterIcon from "../../assets/images/TwitterIcon.png";
import YoutubeIcon from "../../assets/images/YoutubeIcon.png";
import { useDispatch, useSelector } from "react-redux";
import { GetFooterData } from "../../redux/features/FooterService";
// import { Link, useNavigate } from "react-router-dom";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Image from "next/image";

const Footer = ({ res }) => {
  // const dispatch = useDispatch();
  // const router = useRouter();
  // const { footerData } = useSelector((state) => state.footers);
  const footerData = res;

  // useEffect(() => {
  //   dispatch(GetFooterData());
  // }, [dispatch]);

  return (
    <footer className="footer">
      <div className="container">
        <Row className="align-items-center firstRow">
          <Col xs={12} xl={2} className="py-2 my-1 col1">
            <Image
              src={footerData.footer_logo}
              className="sectionHeadingIcon"
              alt="Site Logo"
              width={100}
              height={107}
            />
          </Col>
          <Col xs={12} sm={6} xl={4} className="py-2 my-1 col2">
            <div
              className="content"
              dangerouslySetInnerHTML={{
                __html: footerData?.footer_text,
              }}
            ></div>
            <div className="socialMedia">
              <span className="title">Social Media</span>
              <ul className="iconList">
                <li>
                  <a
                    href={footerData.facebook_url}
                    className="socialMediaLink"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Image
                      src={FacebookIcon}
                      className="socialMediaIcon"
                      alt="Facebook Icon"
                      height={29}
                      width={29}
                    />
                  </a>
                </li>
                <li>
                  <a
                    href={footerData.instagram_url}
                    className="socialMediaLink"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Image
                      src={InstagramIcon}
                      className="socialMediaIcon"
                      alt="Instagram Icon"
                      height={29}
                      width={29}
                    />
                  </a>
                </li>
                <li>
                  <a
                    href={footerData.twitter_url}
                    className="socialMediaLink"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Image
                      src={TwitterIcon}
                      className="socialMediaIcon"
                      alt="Twitter Icon"
                      height={29}
                      width={29}
                    />
                  </a>
                </li>
                <li>
                  <a
                    href={footerData.youtube_url}
                    className="socialMediaLink"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Image
                      src={YoutubeIcon}
                      className="socialMediaIcon"
                      alt="Youtube Icon"
                      height={29}
                      width={29}
                    />
                  </a>
                </li>
              </ul>
            </div>
          </Col>
          <Col xl={2} className="col2 d-none d-xl-block"></Col>
          <Col
            xs={6}
            sm={3}
            lg={3}
            xl={2}
            className="py-2 my-1 footerMenuCol col3"
          >
            <div className="title">Games</div>
            <ul className="menu menu1">
              {footerData?.footer_categories?.length > 0
                ? footerData?.footer_categories.map((categoryData) => (
                    <li key={categoryData.id}>
                      <Link href={`/games/${categoryData.slug}`}>
                        {categoryData.name}
                      </Link>
                    </li>
                  ))
                : ""}
            </ul>
          </Col>
          <Col
            xs={6}
            sm={3}
            lg={3}
            xl={2}
            className="py-2 my-1 footerMenuCol col4"
          >
            <div className="title">Legal</div>
            <ul className="menu menu2">
              {footerData?.quick_links?.length > 0
                ? footerData?.quick_links.map((quickLinkData) => (
                    <li key={quickLinkData.id}>
                      <Link href={`/page/${quickLinkData.slug}`}>
                        {quickLinkData.title}
                      </Link>
                    </li>
                  ))
                : ""}
            </ul>
          </Col>
        </Row>
        <div className="secondRow">
          <div
            className="copyrightText"
            dangerouslySetInnerHTML={{
              __html: footerData?.copyright_text,
            }}
          ></div>
          <ul className="menuList">
            {footerData?.footer_links?.length > 0
              ? footerData?.footer_links.map((footerLink) => (
                  <li key={footerLink.slug}>
                    <Link href={`/page/${footerLink.slug}`}>
                      {footerLink.title}
                    </Link>
                  </li>
                ))
              : ""}
          </ul>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
