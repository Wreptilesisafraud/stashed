// Component
import { useEffect, useState, useRef, useContext } from "react";
import {
  Container,
  Row,
  Col,
  Navbar,
  OverlayTrigger,
  Popover,
  Card,
  Nav,
  Modal,
  // Spinner
} from "react-bootstrap";
// import { useNavigate, Link } from "react-router-dom";
import { useRouter } from "next/router";
import Link from "next/link";
import LogoDesk from "@/assets/images/site_logo.webp";
import LogoMobile from "@/assets/images/site_logo_mobile.webp";
import TrashIconWithBG from "../../assets/images/TrashIconWithBG.svg";
import cartIconDesk from "../../assets/images/cartIcon.svg";
import cartIconMobile from "../../assets/images/shoopingCart.svg";
import userIcon from "../../assets/images/user.svg";
import Dul_userIcon from "../../assets/images/dulUser.svg";
import userDefaultImg from "../../assets/images/default_user.webp";
import plusIcon from "../../assets/images/plusIcon.svg";
import List_Icon from "../../assets/images/List_Icon.svg";
import Notifications_Icon from "../../assets/images/Notifications_Icon.svg";
import Messages_Icon from "../../assets/images/Messages_Icon.svg";
import Setting_Icon from "../../assets/images/settingIcon.svg";
import Dolar_Icon from "../../assets/images/dolarIcon.svg";
import TextAlignLeft from "../../assets/images/TextAlignLeft.svg";
import CloseIcon from "../../assets/images/Close_icon.webp";

// Images
import menuItem1 from "../../assets/images/List_Icon.svg";
import menuItem2 from "../../assets/images/Wallet_Icon.svg";
import menuItem3 from "../../assets/images/Notifications_Icon.svg";
import menuItem4 from "../../assets/images/Messages_Icon.svg";
import menuItem6 from "../../assets/images/Profile_Icon.svg";

import CategorySideBar from "./Mobile_Menu/index";
import { handleOnClickBlock, handleOnClickNon } from "../../utils/designs";
import { AuthContext } from "../../contexts/AuthContexts";
import { useDispatch, useSelector } from "react-redux";
import { GetCatalogListData } from "../../redux/features/CatalogService";
import Cookies from "js-cookie";
import { LogoutService } from "../../redux/features/AuthsService";
import { GetUserData } from "../../redux/features/UserService";
import { getCartItems, removeCartItem } from "../../redux/features/CartService";
import RightArrow from "../../assets/images/RightArrow.webp";
import ApplyPromoCode from "./ApplyPromoCode";
import { useDeviceWidth } from "../../utils/useDeviceWidth.js";
import { isMobileUi } from "../../utils/lib";
import Image from "next/image";

const Header = () => {
  const checkWidth = useDeviceWidth();
  const [isScroll, setScroll] = useState("");
  const [isShowCatalog, setShowCatalog] = useState(false);
  const router = useRouter();
  const dispatch = useDispatch();
  const { catalogData } = useSelector((state) => state.catalogs);
  const { userData, loading } = useSelector((state) => state.users);
  const { cartItems, totalPrice } = useSelector((state) => state.cart);
  const [categoryProductData, setCategoryProductData] = useState([]);
  const [showPopover, setShowPopover] = useState(false);
  const [showPopover11, setShowPopover11] = useState(false);
  const [show, setShow] = useState(false);
  const handleCloseModal = () => setShow(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const urlSegmentsToCheck = [
    "order",
    "wallet",
    "notifications",
    "transactions",
    "preferance",
    "security",
  ];
  const handleShowModal = () => {
    setShow(true);
  };
  // const [catalogLoading, setCatalogLoading] = useState(false);
  const [isActiveCat, setActiveCat] = useState(
    catalogData.length > 0 ? catalogData[0]?.id : 0
  );
  // console.log("catalogue:", catalogData);
  const { authStatus, updateAuthStatus } = useContext(AuthContext);
  useEffect(() => {
    const onScroll = () => {
      setScroll(window.pageYOffset > 10 ? "stickyHeader" : "");
    };
    // clean up code
    window.removeEventListener("scroll", onScroll);
    window.addEventListener("scroll", onScroll, { passive: true });

    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const currentURL = router.asPath;
    const shouldShowDiv = urlSegmentsToCheck.some((segment) =>
      currentURL.includes(segment)
    );
    setShowUserMenu(shouldShowDiv);
  }, [router]);

  useEffect(() => {
    if (authStatus === 1) {
      // User is logged in, you can add your JavaScript code here
      // Example: Fetch additional user data
      // dispatch(GetUserData());

      // Example: Execute custom JavaScript function if userData is available
      if (userData && !loading) {
        if (
          window.location.href.indexOf("order-failed") !== -1 ||
          window.location.href.indexOf("order-completed") !== -1
        ) {
          customFunction();
        }
        document.addEventListener("DOMContentLoaded", function () {
          snowEffect();
          setTimeout(function () {
            customFunction();
          }, 10000);
        });
      }
    } else {
      document.addEventListener("DOMContentLoaded", function () {
        snowEffect();
        setTimeout(function () {
          customTwoFunction();
        }, 10000);
      });
    }
  }, [authStatus, userData, loading]); // Listen to authStatus, userData, and loading changes

  const customFunction = () => {
    (function () {
      var w = window;
      var ic = w.Intercom;
      if (typeof ic === "function") {
        ic("reattach_activator");
        ic("update", w.intercomSettings);
      } else {
        var d = document;
        var i = function () {
          i.c(arguments);
        };
        i.q = [];
        i.c = function (args) {
          i.q.push(args);
        };
        w.Intercom = i;
        var l = function () {
          var s = d.createElement("script");
          s.type = "text/javascript";
          s.async = true;
          s.src = "https://widget.intercom.io/widget/a3rlm6s1";
          var x = d.getElementsByTagName("script")[0];
          x.parentNode.insertBefore(s, x);
        };
        if (document.readyState === "complete") {
          l();
        } else if (w.attachEvent) {
          w.attachEvent("onload", l);
        } else {
          w.addEventListener("load", l, false);
        }
      }
    })();
    window.Intercom("update", {
      api_base: "https://api-iam.intercom.io",
      app_id: "a3rlm6s1",
      name: userData.name, // Full name
      email: userData.email, // Email address
      user_id: userData.id, // current_user_id
      created_at: Date.now(),
    });

    if (window.location.pathname === "/order-completed") {
      window.Intercom("show");
    }

    window.addEventListener("resize", function () {
      if (document.documentElement.clientWidth >= 1250) {
        const dropdownLinks = document.querySelectorAll(
          ".zactra-top-navbar-section-dropdown"
        );
        dropdownLinks.forEach(function (link) {
          link.setAttribute("href", "javascript:void(0)");
        });
      } else {
        const dropdownLinks = document.querySelectorAll(
          ".zactra-top-navbar-section-dropdown"
        );
        dropdownLinks.forEach(function (link) {
          link.setAttribute("href", link.getAttribute("data-url"));
        });
      }
    });

    window.dispatchEvent(new Event("resize"));
  };

  const customTwoFunction = () => {
    (function () {
      var w = window;
      var ic = w.Intercom;
      if (typeof ic === "function") {
        ic("reattach_activator");
        ic("update", w.intercomSettings);
      } else {
        var d = document;
        var i = function () {
          i.c(arguments);
        };
        i.q = [];
        i.c = function (args) {
          i.q.push(args);
        };
        w.Intercom = i;
        var l = function () {
          var s = d.createElement("script");
          s.type = "text/javascript";
          s.async = true;
          s.src = "https://widget.intercom.io/widget/a3rlm6s1";
          var x = d.getElementsByTagName("script")[0];
          x.parentNode.insertBefore(s, x);
        };
        if (document.readyState === "complete") {
          l();
        } else if (w.attachEvent) {
          w.attachEvent("onload", l);
        } else {
          w.addEventListener("load", l, false);
        }
      }
    })();
    window.intercomSettings = {
      api_base: "https://api-iam.intercom.io",
      app_id: "a3rlm6s1",
      created_at: Date.now(),
    };

    if (window.location.pathname === "/order-completed") {
      window.Intercom("show");
    }

    // window.addEventListener("resize", function () {
    //   if (document.documentElement.clientWidth >= 1250) {
    //     const dropdownLinks = document.querySelectorAll(
    //       ".zactra-top-navbar-section-dropdown"
    //     );
    //     dropdownLinks.forEach(function (link) {
    //       link.setAttribute("href", "javascript:void(0)");
    //     });
    //   } else {
    //     const dropdownLinks = document.querySelectorAll(
    //       ".zactra-top-navbar-section-dropdown"
    //     );
    //     dropdownLinks.forEach(function (link) {
    //       link.setAttribute("href", link.getAttribute("data-url"));
    //     });
    //   }
    // });

    window.dispatchEvent(new Event("resize"));
  };

  const snowEffect = () => {
    var targetDiv = document.querySelector(
      ".heroSlider .carousel .carousel-inner"
    );

    if (targetDiv) {
      for (var i = 0; i < 100; i++) {
        var newDiv = document.createElement("div");
        newDiv.classList.add("snow");
        newDiv.style.animationDuration = Math.random() * 10 + 5 + "s";
        targetDiv.insertBefore(newDiv, targetDiv.firstChild);
      }
    }
  };

  useEffect(() => {
    if (authStatus === 1) dispatch(GetUserData());
  }, [dispatch, authStatus]);

  // catalog
  // const handleCalalogHover = () => {
  //   setCatalogLoading(true)
  //   dispatch(GetCatalogListData());
  // }

  const handlePopoverOpen = () => {
    setShowCatalog(true);
    setCategoryProductData(catalogData[0]?.child_categories);
    handleCatalogCatData(isActiveCat);
    handleOnClickNon();
  };

  useEffect(() => {
    dispatch(GetCatalogListData());
  }, [dispatch]);

  // catalog
  const handlePopoverClose = () => {
    setShowPopover(false);
    setShowCatalog(false);
    handleOnClickBlock();
  };

  const handleLogout = () => {
    Cookies.remove("stashed_token");
    dispatch(LogoutService());
    updateAuthStatus(0);
    window.location.href = "/signin";
  };

  // const handleCategoryClick = (catId) => {
  //   handlePopoverClose();
  //   setShowCatalog(false);
  //   setShowPopover(false);
  //   window.scrollTo(0, 0);
  //   navigate(`/all-products/${catId}`);
  // }

  useEffect(() => {
    if (catalogData.length > 0 && isActiveCat === 0) {
      setActiveCat(catalogData.length > 0 ? catalogData[0]?.id : 0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catalogData]);

  const modalRef = useRef(null);

  const handleClickUserPopup = (navigateUrl) => {
    handleOnClickBlock();
    setShowPopover11(false);
    // debu
    router.push(`${navigateUrl}`);
  };

  const handleCatalogCatData = (catId) => {
    setShowPopover(true);
    let finalProCatData = catalogData
      .map(
        (childCatProData) =>
          childCatProData.id === catId && childCatProData?.child_categories
      )
      .filter((finalMapData) => finalMapData)[0];
    setActiveCat(catId);
    setCategoryProductData(finalProCatData);
  };

  const handleProductClick = (categoryId, productId) => {
    handlePopoverClose();
    setShowCatalog(false);
    setShowPopover(false);
    window.scrollTo(0, 0);
    const parent = catalogData.find((cat) =>
      cat?.child_categories?.find((cat1) => cat1.slug === categoryId)
    );
    router.push(`/games/${parent.slug}/${categoryId}/${productId}`);
  };

  const handleClickRemoveCartItem = (item) => {
    dispatch(removeCartItem(item.id));
  };

  const handleClickCheckOut = () => {
    handlePopoverClose();
    setShowCatalog(false);
    setShowPopover(false);
    router.push("/checkout");
  };

  const handleCardItems = () => {
    dispatch(getCartItems());
  };
  return (
    <>
      <header className={`header ${isScroll}`}>
        <Navbar fixed="top" collapseOnSelect expand="lg" variant="dark">
          <Container fluid>
            <div className="d-md-none me-3 mobileMenuSidebar">
              <CategorySideBar />
            </div>
            <Navbar.Brand onClick={() => router.push("/")}>
              <Image
                src={LogoDesk}
                alt="Site Logo"
                className="d-none d-md-block"
                height={38}
                width={171}
                loading="lazy"
              />
              <Image
                src={LogoMobile}
                alt="Site Logo"
                className="d-md-none"
                height="37"
                width="37"
              />
            </Navbar.Brand>
            {/* Catalogue  */}
            <div className="me-3 headerMenu d-none d-md-block">
              <OverlayTrigger
                trigger="click"
                key="bootom"
                placement="bottom"
                rootClose={true}
                onEnter={handlePopoverOpen}
                onExited={handlePopoverClose}
                show={showPopover}
                onToggle={setShowPopover}
                overlay={
                  <Popover
                    className="headerMenuPopup"
                    id="popover-positioned-bottom"
                  >
                    <Popover.Body className="p-0">
                      <Row className="m-0">
                        <Col xs={12} md={4} className="iconCol">
                          {catalogData.map((parentCatDetail) => (
                            <>
                              <div
                                className={`${
                                  isActiveCat === parentCatDetail.id
                                    ? "active"
                                    : ""
                                } iconItem`}
                                key={parentCatDetail.id}
                              >
                                <a
                                  onClick={() =>
                                    handleCatalogCatData(parentCatDetail.id)
                                  }
                                >
                                  <img
                                    src={parentCatDetail.image_url}
                                    alt="categorys"
                                    loading="lazy"
                                    style={{ width: "50px" }}
                                  />
                                </a>
                              </div>
                            </>
                          ))}
                        </Col>
                        <Col xs={12} md={8} className="tabCol m-0 p-0">
                          <Row className="m-0">
                            {categoryProductData?.length > 0 ? (
                              categoryProductData.map((childData, childIndex) =>
                                childIndex <= 3 ? (
                                  <>
                                    <Col
                                      sm={6}
                                      key={childData.id}
                                      className="tabData p-0"
                                    >
                                      <div className="item">
                                        <h4>
                                          <span
                                            style={{ background: "#fda649" }}
                                          >
                                            <Image
                                              src={
                                                childData.meta_image_url
                                                  ? childData.meta_image_url
                                                  : RightArrow
                                              }
                                              height={15}
                                              width={15}
                                              alt="Category brand"
                                              loading="lazy"
                                            />
                                          </span>
                                          {childData.name}
                                        </h4>

                                        <p>
                                          <div
                                            dangerouslySetInnerHTML={{
                                              __html: childData.description,
                                            }}
                                          />
                                        </p>
                                        {childData?.products.length > 0 ? (
                                          childData.products.map(
                                            (prodcutDetail, index) => {
                                              return (
                                                <>
                                                  {index <= 2 ? (
                                                    <h4
                                                      className="link"
                                                      key={prodcutDetail.id}
                                                    >
                                                      <p
                                                        onClick={() =>
                                                          handleProductClick(
                                                            childData.slug,
                                                            prodcutDetail.slug
                                                          )
                                                        }
                                                      >
                                                        {prodcutDetail.name}
                                                      </p>
                                                    </h4>
                                                  ) : (
                                                    ""
                                                  )}
                                                </>
                                              );
                                            }
                                          )
                                        ) : (
                                          <></>
                                        )}
                                      </div>
                                    </Col>
                                  </>
                                ) : (
                                  <></>
                                )
                              )
                            ) : (
                              <></>
                            )}
                          </Row>
                        </Col>
                      </Row>
                    </Popover.Body>
                  </Popover>
                }
              >
                <button className="buttonStyle1 catalogBtn">
                  {!isShowCatalog ? (
                    <Image
                      src={TextAlignLeft}
                      alt="Catalog Icon"
                      width={15}
                      height={15}
                    />
                  ) : (
                    <Image
                      src={CloseIcon}
                      alt="Close Icon"
                      className="filter_invert"
                      width={15}
                      height={15}
                    />
                  )}
                  <span className="ms-2">Catalog</span>
                </button>
              </OverlayTrigger>
            </div>
            {!isMobileUi(checkWidth) && (
              <Nav className="me-auto ms-2 navMenu me-5">
                <Link className="nav-link" href="/blog">
                  Blog
                </Link>
                <Link className="nav-link" href="/about">
                  Work With Us
                </Link>
                {showUserMenu ? (
                  <>
                    <Link className="nav-link" href="/order">
                      My Order
                    </Link>
                    <Link className="nav-link" href="#">
                      Chat
                    </Link>
                  </>
                ) : (
                  ""
                )}
              </Nav>
            )}

            <div className="d-flex align-items-center buttonGroup test">
              <div onClick={handleShowModal}>
                <Image
                  className="mobileImg filter_invert d-md-none"
                  src={userIcon}
                  alt="userIcon"
                  width={40}
                  height={40}
                />
              </div>
              {authStatus !== 1 ? (
                <>
                  <Link href="/signin" className="loginBtn d-none d-md-block">
                    Login
                  </Link>
                  <Link
                    eventkey={2}
                    href="/signup"
                    className="buttonStyle1 signUp_btn m-0 ms-md-2 ms-lg-4 d-none d-md-block"
                  >
                    Sign Up
                  </Link>
                </>
              ) : (
                <>
                  <div className="userMenu d-none d-md-block wallet-amount">
                    <div className="align-items-center d-flex justify-content-between dataItem">
                      <Link
                        className="no-decoration top-menu-icon me-1"
                        href="/wallet"
                      >
                        <Image
                          src={plusIcon}
                          alt="plus"
                          className="filter_invert cs-icon"
                          loading="lazy"
                          width={21}
                          height={21}
                        />
                      </Link>
                      ${totalPrice.toFixed(2)}
                    </div>
                  </div>
                  <div className="userMenu d-none d-md-block">
                    <OverlayTrigger
                      trigger="click"
                      key="top"
                      placement="bottom"
                      show={showPopover11}
                      rootClose={true}
                      onEnter={handleOnClickNon}
                      onExited={handleOnClickBlock}
                      onToggle={setShowPopover11}
                      overlay={
                        <Popover
                          id="popover-positioned-bottom"
                          className="userDataModel"
                        >
                          <Popover.Body>
                            <a
                              onClick={() => handleClickUserPopup("/order")}
                              className="nav-link"
                            >
                              <div className="iconBlock">
                                <Image
                                  src={menuItem1}
                                  alt="Menu Icon"
                                  loading="lazy"
                                />
                              </div>
                              <span>My Order History</span>
                            </a>
                            <a
                              onClick={() => handleClickUserPopup("/")}
                              className="nav-link"
                            >
                              <span className="iconBlock">
                                <Image
                                  src={menuItem4}
                                  alt="Menu Icon"
                                  loading="lazy"
                                />
                              </span>
                              <span>Messages</span>
                            </a>
                            <a
                              onClick={() =>
                                handleClickUserPopup("/notifications")
                              }
                              className="nav-link"
                            >
                              <span className="iconBlock">
                                <Image
                                  src={menuItem3}
                                  alt="Menu Icon"
                                  loading="lazy"
                                />
                              </span>
                              <span>Notifications</span>
                            </a>
                            <a
                              onClick={() =>
                                handleClickUserPopup("/preferance")
                              }
                              className="nav-link"
                            >
                              <span className="iconBlock">
                                <Image
                                  src={menuItem6}
                                  alt="Menu Icon"
                                  loading="lazy"
                                />
                              </span>
                              <span>Profile</span>
                            </a>
                            <a
                              onClick={() => handleClickUserPopup("/wallet")}
                              className="nav-link"
                            >
                              <span className="iconBlock">
                                <Image
                                  src={menuItem2}
                                  alt="Wallet Icon"
                                  loading="lazy"
                                />
                              </span>
                              <span>Wallet</span>
                            </a>
                            <button
                              className="logoutBtn nav-link"
                              onClick={handleLogout}
                            >
                              Logout
                            </button>
                            {/* <Link
                            href="/#"
                            className={`nav-link text-center ${
                              title === "message" ? "active" : ""
                            }`}
                          >
                            Logout
                          </Link> */}
                          </Popover.Body>
                        </Popover>
                      }
                    >
                      {userData?.avatar_url && !loading !== "" ? (
                        <Image
                          className="realUserIcon"
                          src={userData?.avatar_url}
                          alt="userIcon"
                          loading="lazy"
                          width={40}
                          height={40}
                        />
                      ) : (
                        <div className="box">
                          <Image
                            className="userIcon"
                            src={Dul_userIcon}
                            alt="userIcon"
                            loading="lazy"
                          />
                        </div>
                      )}
                    </OverlayTrigger>
                  </div>
                  {/* Shopping Cart */}
                  <OverlayTrigger
                    trigger="click"
                    key="bootom"
                    placement="bottom"
                    onClick={() => console.log("0")}
                    rootClose={true}
                    onEnter={handleOnClickNon}
                    onExited={handleOnClickBlock}
                    overlay={
                      <Popover className="shoppingCart">
                        <Popover.Header>
                          <h3 className="m-0">Shopping Cart </h3>
                          <span className="cartItemCount">
                            ({cartItems.length} Items)
                          </span>
                        </Popover.Header>
                        <Popover.Body className="scrollDesign_y">
                          {cartItems.map((item) => (
                            <Card className="productCard mb-2" key={item.id}>
                              <div className="d-flex align-items-center productInfo">
                                <Image
                                  src={item.product.image_url}
                                  alt="Product"
                                  className="productImg"
                                  loading="lazy"
                                  width={50}
                                  height={50}
                                />
                                <div className="productName text-white">
                                  {item.product.name}
                                </div>
                                <span className="m-0 ms-auto text-white">
                                  ${item.subtotal.toFixed(2)}
                                </span>
                              </div>
                              <hr />
                              <div className="productOrderInfo">
                                {/* <div className="mb-2">
                                  <Image
                                    src={UserIconWithBG}
                                    alt="Product"
                                    className="infoImg"
                                  />
                                  <span>
                                    <b>Sold by:</b> Bilzard Entertainment
                                  </span>
                                </div>
                                <div>
                                  <Image
                                    src={TimeIconWithBG}
                                    alt="Product"
                                    className="infoImg"
                                  />
                                  <span>
                                    <b>Delivery time:</b> 20 Minutes
                                  </span>
                                </div> */}
                                <div className="productVariations">
                                  <label className="productTitle text-white">
                                    Variations
                                  </label>
                                  <dl>
                                    {item.variations.map((v, index) => (
                                      <li
                                        key={index}
                                        className="productVariation"
                                      >
                                        {v.variation.code}
                                      </li>
                                    ))}
                                  </dl>
                                </div>
                                <div className="productAdditionalOptions">
                                  <label className="productTitle">
                                    Additional Options
                                  </label>
                                  <dl>
                                    {item.addons.map((addon, index) => (
                                      <li
                                        key={index}
                                        className="productAdditionalOptions"
                                      >
                                        {addon?.addon?.title}
                                      </li>
                                    ))}
                                  </dl>
                                </div>
                              </div>
                              <hr />
                              <div className="d-flex justify-content-between">
                                <div className="orderQty text-white">
                                  <b>Quantity:</b> {item.qty}
                                </div>
                                <a
                                  className="d-flex"
                                  onClick={() =>
                                    handleClickRemoveCartItem(item)
                                  }
                                >
                                  <Image
                                    src={TrashIconWithBG}
                                    alt="Trash Icon"
                                    className="Trash Icon me-1"
                                    loading="lazy"
                                  />
                                  <span className="text-white">Remove</span>
                                </a>
                              </div>
                            </Card>
                          ))}
                        </Popover.Body>
                        <div className="PopoverFooter px-3 mt-3">
                          <hr className="m-0" />
                          <div className="d-flex justify-content-between py-2">
                            <div>Item(s)</div>
                            <div>
                              <b>${totalPrice.toFixed(2)}</b>
                            </div>
                          </div>
                          <hr className="m-0" />
                          {cartItems?.length > 0 && (
                            <ApplyPromoCode cartItems={cartItems} />
                          )}
                          <div className="d-flex justify-content-between py-2">
                            <div>Subtotal</div>
                            <div>
                              <b>${totalPrice.toFixed(2)}</b>
                            </div>
                          </div>
                          <hr className="m-0" />
                          <button
                            className="buttonStyle1 d-flex text-center mx-auto my-4"
                            onClick={handleClickCheckOut}
                          >
                            Secure Checkout
                          </button>
                        </div>
                      </Popover>
                    }
                  >
                    <div className="viewCartBtn ms-2 ms-lg-4">
                      <button
                        className="d-none d-md-block"
                        onClick={handleCardItems}
                      >
                        <Image
                          className="deskImg"
                          src={cartIconDesk}
                          alt="Cart Icon"
                          loading="lazy"
                        />
                      </button>
                      <Image
                        className="mobileImg filter_invert d-md-none"
                        src={cartIconMobile}
                        alt="Cart Icon"
                        width="50"
                        height="50"
                        loading="lazy"
                      />
                    </div>
                  </OverlayTrigger>
                </>
              )}
            </div>
          </Container>
        </Navbar>
      </header>
      <Modal
        className="modal fade M_loginModel"
        show={show}
        onHide={handleCloseModal}
        centered
      >
        <button
          type="button"
          className="btn-close filter_invert"
          data-bs-dismiss="modal"
          aria-label="Close"
          onClick={handleCloseModal}
        ></button>
        <div className="modal-body scrollDesign_y">
          <div className="text-center userData">
            <div className="userImg">
              <Image
                src={
                  userData?.avatar_url && !loading !== ""
                    ? userData?.avatar_url
                    : userDefaultImg
                }
                alt="userDefaultImg"
                width={100}
                height={100}
                loading="lazy"
              />
            </div>
            <h6 className="mt-2 mb-0 userName">
              {userData?.name ?? "UserName"}
            </h6>
          </div>
          <div className="row justify-content-center userDataList">
            <div className="col-12 px-1 my-1">
              <div className="align-items-center d-flex justify-content-between dataItem">
                <div className="titleBlock">
                  <h6 className="title">{userData?.name ?? "UserName"}</h6>
                  <p className="subTitle">
                    ${userData?.user_balance ? userData.user_balance : 0}
                  </p>
                </div>
                <div className="tag">
                  <Image
                    src={plusIcon}
                    alt="plus"
                    className="filter_invert tagIcon"
                    loading="lazy"
                  />
                  <Link className="no-decoration" href="/wallet">
                    <p className="tagText">Add Funds</p>
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-6 px-1 my-1">
              <div className="dataItem">
                <Link className="no-decoration" href="/order">
                  <Image
                    src={List_Icon}
                    alt="My Orders"
                    className="dataImg mb-1"
                    loading="lazy"
                  />
                  <h6 className="title">My Orders</h6>
                </Link>
              </div>
            </div>
            <div className="col-6 px-1 my-1">
              <div className="dataItem">
                <Image
                  src={Messages_Icon}
                  alt="Chats"
                  className="dataImg mb-1"
                  loading="lazy"
                />
                <h6 className="title">Chats</h6>
              </div>
            </div>
            <div className="col-6 px-1 my-1">
              <Link className="no-decoration" href="/notifications">
                <span className="dataItem">
                  <Image
                    src={Notifications_Icon}
                    alt="Notifications"
                    className="dataImg mb-1"
                  />
                  <h6 className="title">Notifications</h6>
                </span>
              </Link>
            </div>
            <div className="col-6 px-1 my-1">
              <Link className="no-decoration" href="/preferance">
                <span className="dataItem">
                  <Image
                    src={Setting_Icon}
                    alt="Profile Settings"
                    className="filter_invert dataImg mb-1"
                    loading="lazy"
                  />
                  <h6 className="title">Profile Settings</h6>
                </span>
              </Link>
            </div>
            <div className="col-12 px-1 my-1">
              <div className="align-items-center d-flex justify-content-between dataItem">
                <div className="titleBlock">
                  <h6 className="title">Currency</h6>
                </div>
                <div className="tag">
                  <Image
                    src={Dolar_Icon}
                    alt="Dolar"
                    className="filter_invert tagIcon"
                    loading="lazy"
                  />
                  {userData?.user_balance}
                  <div className="tagText">USD</div>
                </div>
              </div>
            </div>
          </div>
          {authStatus !== 1 ? (
            <>
              <Link
                href="/signin"
                className="buttonStyle1 loginBtn d-block mt-2"
              >
                Login
              </Link>
              <Link
                eventkey={2}
                href="/signup"
                className="buttonStyle2 signUp_btn d-block mt-2 m-0 ms-md-2 ms-lg-4"
              >
                Sign Up
              </Link>
            </>
          ) : (
            <></>
          )}
        </div>
      </Modal>
    </>
  );
};

export default Header;
