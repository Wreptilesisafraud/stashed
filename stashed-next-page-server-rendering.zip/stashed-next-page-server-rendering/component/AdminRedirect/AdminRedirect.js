import React, { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const AdminRedirect = () => {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const path = window.location.pathname;
    // If the path starts with "/admin/", redirect to the admin panel
    if (path.startsWith("/admin/")) {
      const newPath = path.replace("/admin", "");
      window.scrollTo(0, 0);
      navigate(`/admin${newPath}`);
    }
  }, [ navigate]);

  return null;
};

export default AdminRedirect;