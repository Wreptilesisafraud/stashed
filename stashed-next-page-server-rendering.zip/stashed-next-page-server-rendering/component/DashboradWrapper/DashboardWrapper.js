import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import Header from "../layout/Header";
import CookieBar from "../../pages/CookieBar/index";

const DashboardWrapper = () => {
  const [isShowCookie, setShowCookie] = useState(false);

  document.addEventListener("DOMContentLoaded", function () {
    setTimeout(function () {
      setShowCookie(true)
    }, 5000);
  });
  return (
    <>
      <Header />
      <Outlet />
      
      {isShowCookie ? <CookieBar /> : ''}
    </>
  );
};

export default DashboardWrapper;
