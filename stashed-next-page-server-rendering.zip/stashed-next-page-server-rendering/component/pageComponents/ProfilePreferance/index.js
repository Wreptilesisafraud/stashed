import React, { useEffect, useState } from "react";
import { Form, Button, Col, Row, FormControl } from "react-bootstrap";
import UserDashboard from "../UserDashboard";
import { useFormik } from "formik";
import UserDashboardSidebar from "../UserDashboard/Sidebar/index";

import UserImg from "@/assets/images/dummyUser.webp";
import { useDispatch, useSelector } from "react-redux";
import {
  GetUserData,
  UpdateSecurityData,
  UpdateUserData,
} from "@/redux/features/UserService";
import { toast } from "react-toastify";
import Image from "next/image";

const validate = (values) => {
  const errors = {};

  if (!values.email) {
    errors.email = "Please enter email address";
  } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = "Invalid email address";
  }

  if (!values.userName) {
    errors.userName = "Please enetr user name";
  }

  return errors;
};

const Preferance = () => {
  const [filess, setFile] = useState(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState(UserImg);
  const dispatch = useDispatch();
  const { userData, loading } = useSelector((state) => state.users);

  const handleFileChange = (event) => {
    const reader = new FileReader();
    const file = event.target.files[0];

    reader.onloadend = () => {
      setFile(file);
      setImagePreviewUrl(reader.result);
    };

    reader.readAsDataURL(file);
  };

  const formik = useFormik({
    initialValues: {
      fileUpload: "",
    },
    onSubmit: async () => {
      if (filess) {
        const response = await dispatch(UpdateUserData(filess));
        if (response.type === "users/UpdateUserData/fulfilled") {
          dispatch(GetUserData());
          setFile(null);
          setImagePreviewUrl(null);
          toast.success(response.payload.message, { autoClose: 3000 });
        } else {
          toast.error(response.payload.message, { autoClose: 3000 });
        }
      }
    },
  });

  const formikUserDetail = useFormik({
    initialValues: {
      email: userData.email,
      userName: userData?.name,
    },
    validate,
    onSubmit: async (values) => {
      const data = {
        name: values.userName,
      };
      const response = await dispatch(UpdateSecurityData(data));
      if (response.type === "users/UpdateSecurityData/fulfilled") {
        toast.success(response.payload.message, { autoClose: 3000 });
      } else {
        toast.error(response.payload.message, { autoClose: 3000 });
      }
    },
  });

  useEffect(() => {
    if (userData) {
      formikUserDetail.setValues({
        email: userData.email,
        userName: userData.name,
      });

      if (userData?.avatar_url && !loading) {
        setImagePreviewUrl(userData?.avatar_url);
      } else {
        setImagePreviewUrl(UserImg);
      }
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userData]);

  return (
    <UserDashboard title="preferance" className="preferancePage">
      <div className="pageTitleBlock">
        <div className="titleBlock">
          <div className="pageTitle">User Profile</div>
          <div className="d-flex gap-2 justify-content-between blockAction">
            <div className="d-lg-none categorySideBarBtn">
              <UserDashboardSidebar title="preferance" />
            </div>
          </div>
        </div>
      </div>
      <div className="UserDashboard_body scrollDesign_y">
        <Row className="">
          <Col xs={12} sm={6} lg={5} className="preferencesData">
            <Form onSubmit={formikUserDetail.handleSubmit}>
              <div className="data">
                <h2 className="title mb-3">Preferences</h2>
                <Form.Group className="formGroup" controlId="formBasicEmail">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    placeholder="Enter your Email"
                    onChange={formikUserDetail.handleChange}
                    value={formikUserDetail.values.email}
                  />
                  {formikUserDetail.touched.email &&
                  formikUserDetail.errors.email ? (
                    <div className="error">{formikUserDetail.errors.email}</div>
                  ) : null}
                </Form.Group>
                <Form.Group className="formGroup" controlId="formBasicUserName">
                  <Form.Label>User Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="userName"
                    placeholder="Enter your username"
                    onChange={formikUserDetail.handleChange}
                    value={formikUserDetail.values.userName}
                  />
                  {formikUserDetail.touched.userName &&
                  formikUserDetail.errors.userName ? (
                    <div className="error">
                      {formikUserDetail.errors.userName}
                    </div>
                  ) : null}
                </Form.Group>
                <Button type="submit" className="buttonStyle1 d-flex mt-2">
                  Submit
                </Button>
              </div>
            </Form>
          </Col>
          <Col xs={12} sm={6} lg={7} className="profileData">
            <div className="data">
              <h2 className="title mb-3">Profile Picture</h2>
              <Form onSubmit={formik.handleSubmit}>
                <div className="profileSelector d-flex flex-wrap gap-3">
                  {(imagePreviewUrl !== null || imagePreviewUrl !== "") &&
                  !loading ? (
                    <Image
                      src={imagePreviewUrl}
                      alt="Preview"
                      className="userProfileImage"
                      width={128}
                      height={128}
                    />
                  ) : (
                    <Image
                      src={UserImg}
                      alt="Preview"
                      className="userProfileImage"
                      width={128}
                      height={128}
                    />
                  )}
                  <Form.Group
                    controlId="userProfileImage"
                    className="formGroup"
                  >
                    <p className="m-0 info">minimum 200x200 px</p>
                    <p className="mb-3 info">jpeg, png, jpg</p>
                    <Form.Label>Upload image from URL</Form.Label>
                    <FormControl
                      type="file"
                      placeholder="URL"
                      name="fileUpload"
                      onChange={handleFileChange}
                      accept=".jpg, .jpeg .png"
                    />
                    <Button
                      type="submit"
                      className="buttonStyle1 d-flex mt-2"
                      disabled={filess ? false : true}
                    >
                      Submit
                    </Button>
                  </Form.Group>
                </div>
              </Form>
            </div>
          </Col>
        </Row>
      </div>
    </UserDashboard>
  );
};

export default Preferance;
