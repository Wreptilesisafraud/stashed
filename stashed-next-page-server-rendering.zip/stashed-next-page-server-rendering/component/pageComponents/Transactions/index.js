import React, { useEffect } from "react";
import { Button } from "react-bootstrap";
import UserDashboard from "../UserDashboard";
import UserDashboardSidebar from "../UserDashboard/Sidebar/index";
import { useDispatch, useSelector } from "react-redux";
import { GetTransactionData } from "@/redux/features/TranscationService";
import moment from "moment";
import Table from "./table";
import dataEmptyImg from "@/assets/images/dataEmpty.webp";
import Image from "next/image";

const Transactions = () => {
  const dispatch = useDispatch();
  const { transactionsListData } = useSelector((state) => state.transactions);

  useEffect(() => {
    dispatch(GetTransactionData());
  }, [dispatch]);

  const columns = [
    {
      dataField: "user",
      text: "User Email",
      formatter: (user) => user.email,
    },
    {
      dataField: "amount",
      text: "Amount",
      formatter: (cell, row, rowIndex) => (
        <span className="amountCell">${cell}</span>
      ),
    },
    {
      dataField: "type",
      text: "Type",
      formatter: (cell, row, rowIndex) => (
        <span className="text-capitalize">{cell}</span>
      ),
    },
    {
      dataField: "created_at",
      text: "Date Created",
      formatter: (text) => moment(text).format("DD.MM.YYYY"),
    },
    {
      dataField: "status",
      text: "Status",
    },
  ];

  return (
    <UserDashboard title="transaction" className="transactionsPage">
      <div className="pageTitleBlock">
        <div className="titleBlock">
          <div className="pageTitle">Transactions</div>
          <div className="blockAction d-flex justify-content-between gap-2">
            {/* <Button className="buttonStyle1">Save</Button> */}
            <div className="d-lg-none categorySideBarBtn">
              <UserDashboardSidebar title="transaction" />
            </div>
          </div>
        </div>
      </div>
      <div className="UserDashboard_body productList scrollDesign_y dataTable">
        {transactionsListData?.data?.data.length ? (
          <Table data={transactionsListData.data.data} columns={columns} />
        ) : (
          <div className="align-items-center d-flex h-100 justify-content-center w-100 dataNotFound">
            <Image
              src={dataEmptyImg}
              alt="Empty Img"
              className="DataEmptyImg"
              width={500}
              height={373}
            />
          </div>
        )}
      </div>
    </UserDashboard>
  );
};

export default Transactions;
