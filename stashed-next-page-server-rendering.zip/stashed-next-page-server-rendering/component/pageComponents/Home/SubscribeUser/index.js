import React, { useContext, useState } from "react";
import { Button, Carousel, Form, NavLink, Spinner } from "react-bootstrap";
import { toast } from "react-toastify";
import { useDispatch, useSelector } from "react-redux";
import { SubscribeToNewsLetter } from "@/redux/features/SubscribeNewsletterService";
import { useFormik } from "formik";

const validate = (values) => {
  const errors = {};

  if (!values.email) {
    errors.email = "Please enter email address";
  } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = "Invalid email address";
  }

  return errors;
};
const SubscribeUser = () => {
  const dispatch = useDispatch();
  const { loading } = useSelector((state) => state.newsletter);

  const formik = useFormik({
    initialValues: {
      email: "",
    },
    validate,
    onSubmit: async (values, { resetForm }) => {
      dispatch(SubscribeToNewsLetter(values)).then((resp) => {
        toast.success("You have successfully subscribed to our newsletter");
        resetForm({ values: "" });
      });
    },
  });

  return (
    <section className="subscribeUser">
      <div className="container text-center">
        <h2 className="py-4 text-white">Subscribe to our Newsletter</h2>
        <p className="py-2 text-white">Receive daily updates</p>
        <Form onSubmit={formik.handleSubmit}>
          <div className="d-flex justify-content-center align-items-center">
            <Form.Control
              style={{ width: "300px" }}
              className="me-2 p-3 "
              type="email"
              name="email"
              placeholder="Enter a valid email address"
              onChange={formik.handleChange}
              value={formik.values.email}
            />
            <Button
              style={{ minWidth: "auto", width: "100px" }}
              variant="primary"
              type="submit"
              className="buttonStyle1 submitBtn px-2 p-4"
            >
              Submit
            </Button>
          </div>
          {formik.touched.email && formik.errors.email ? (
            <div className="error">{formik.errors.email}</div>
          ) : null}
        </Form>
      </div>
    </section>
  );
};

export default SubscribeUser;
