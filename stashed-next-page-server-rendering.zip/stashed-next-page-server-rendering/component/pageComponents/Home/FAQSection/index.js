// Component
import { Accordion } from "react-bootstrap";
import LazyLoad from "react-lazyload";

// Images
import QuestionMark from "@/assets/images/QuestionMark.webp";
import Image from "next/image";

const FAQSection = ({ faqData }) => (
  <section className="AccordionSec">
    <div className="container">
      <div className="titleBlock">
        <LazyLoad once>
          <Image
            src={QuestionMark}
            className="sectionHeadingIcon"
            alt="QuestionMark Icon"
            width={126}
            height={126}
          />
        </LazyLoad>
        <h2 className="sectionTitle ">Frequently Asked Questions</h2>
      </div>
      <Accordion defaultActiveKey="0">
        {faqData?.map((faqDetail, index) => (
          <Accordion.Item eventKey={index} key={index}>
            <Accordion.Header>{faqDetail.title}</Accordion.Header>
            <Accordion.Body
              dangerouslySetInnerHTML={{ __html: faqDetail.description }}
            />
          </Accordion.Item>
        ))}
      </Accordion>
    </div>
  </section>
);

export default FAQSection;
