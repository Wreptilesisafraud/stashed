import React from "react";
// import { useDispatch, useSelector } from "react-redux";
import HeroSlider from "./HeroSlider";
import CategoryTabbing from "./CategoryTabbing";
import FeaturesCard from "./FeaturesCard";
import ReviewSlider from "./ReviewSlider/ReviewSlider";
import GiftTabbing from "./GiftTabbing";
import FAQSection from "./FAQSection";
import CTASection from "./CTA";
// import { HomePageService } from "@/redux/features/HomeService";
import SubscribeUser from "./SubscribeUser";

const Home = ({ res }) => {
  const homeSliderData = res.hero_sliders ?? [];
  const faqData = res.faq ?? [];
  const giftData = res.gift ?? [];
  const featuresData = res.features ?? [];
  const feedBackData = res.client_feedback ?? [];
  const bannerSectionData = res.banner_section_one_banners
    ? res.banner_section_one_banners[0]
    : null;
  const trustpilot = res.trustpilot;
  // useEffect(() => {
  //   dispatch(HomePageService());
  // }, [dispatch]);
  // console.log(faqData);

  return (
    <>
      <div className="indexPage">
        <HeroSlider homeSliderData={homeSliderData} trustpilot={trustpilot} />
        <CategoryTabbing />
        <FeaturesCard featuresData={featuresData} />
        <ReviewSlider feedBackData={feedBackData} trustpilot={trustpilot} />
        <GiftTabbing giftData={giftData} />
        <FAQSection faqData={faqData} />
        <CTASection bannerSectionData={bannerSectionData} />
        <SubscribeUser />
      </div>
    </>
  );
};

export default Home;
