// Component
import React, { useEffect, useRef, useState } from "react";
import { Tab, Nav, Row, Col } from "react-bootstrap";

const delay = 5000;

const GiftTabbing = ({ giftData }) => {
  const [slideIndex, setSlideIndex] = useState(0);
  const [progressBarValue, setProgressBarValue] = useState(0);
  const timeoutRef = useRef(null);
  const linkRef = useRef(null);

  function resetTimeout() {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
  }

  useEffect(() => {
    resetTimeout();
    // linkRef.currents
    timeoutRef.current = setTimeout(
      () =>
        setSlideIndex((prevIndex) => {
          setProgressBarValue(0);
          if (prevIndex === giftData.length - 1) {
            return 0;
          } else {
            return prevIndex + 1;
          }
          // return prevIndex === (giftData.length - 1) ? 0 : prevIndex + 1
        }),
      delay
    );
    return () => {
      resetTimeout();
    };
  }, [slideIndex, setProgressBarValue]);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setProgressBarValue((prev) => {
        if (prev >= 100) {
          clearInterval(intervalId);
          return 100;
        } else {
          return prev + 2;
        }
      });
    }, 90);

    return () => clearInterval(intervalId);
  }, [progressBarValue, setProgressBarValue]);

  return (
    <section className="GiftTabbing" key="giftData1">
      <div className="container">
        <Tab.Container
          transition={true}
          activeKey={`${slideIndex}`}
          id="left-tabs-example"
          defaultActiveKey="0"
        >
          <Row className="align-items-center">
            <Col sm={12} lg={7}>
              {slideIndex}
              <Tab.Content>
                {giftData.map((giftDetail, index) => (
                  <Tab.Pane eventKey={`${index}`} key={index}>
                    <img src={giftDetail.image} key={index} alt="Tabbing Img" />
                  </Tab.Pane>
                ))}
              </Tab.Content>
            </Col>
            <Col sm={12} lg={5}>
              <Nav variant="pills" className="flex-column">
                {giftData.map((giftDetail, index) => (
                  <Nav.Item key={`${index}_${index}`}>
                    <Nav.Link
                      className="position-relative"
                      eventKey={`${index}`}
                      key={`${index}_${index}`}
                      ref={linkRef}
                      onClick={(eventKey) => {
                        setSlideIndex(index);
                        resetTimeout();
                      }}
                    >
                      <div
                        className="custom-progressbar"
                        style={{ height: `${progressBarValue}%` }}
                      ></div>
                      <div className="tabNav">
                        <div className="tabTitle">{giftDetail.title}</div>
                        <div className="tabContent">
                          {giftDetail.description}
                        </div>
                      </div>
                    </Nav.Link>
                  </Nav.Item>
                ))}
              </Nav>
            </Col>
          </Row>
        </Tab.Container>
      </div>
    </section>
  );
};

export default GiftTabbing;
