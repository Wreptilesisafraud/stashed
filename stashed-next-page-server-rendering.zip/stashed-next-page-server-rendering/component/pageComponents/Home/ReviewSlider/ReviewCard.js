import Carousel from "react-multi-carousel";
import { Card } from "react-bootstrap";
import Image from "next/image";
import ReviewStar from "@/assets/images/ReviewSingalStar.webp";
import "react-multi-carousel/lib/styles.css";
import UAParser from "ua-parser-js";

import LeftArrow from "@/assets/images/Left_Arrow.webp";
import RightArrow from "@/assets/images/Right_Arrow.webp";

const responsive = {
  desktop: {
    breakpoint: { max: 5000, min: 1199 },
    items: 3,
    paritialVisibilityGutter: 70,
  },
  tablet: {
    breakpoint: { max: 1199, min: 767 },
    items: 2,
    paritialVisibilityGutter: 50,
  },
  mobile: {
    breakpoint: { max: 767, min: 0 },
    items: 1,
    paritialVisibilityGutter: 35,
  },
};

const CustomLeftArrow = ({ onClick }) => (
  <Image
    src={LeftArrow}
    onClick={() => onClick()}
    className="leftArrow CArrow"
    alt="Left Arrow"
  />
);
const CustomRightArrow = ({ onClick }) => (
  <Image
    src={RightArrow}
    onClick={() => onClick()}
    className="rightArrow CArrow"
    alt="Right Arrow"
  />
);

// const variableValue = 5;

const renderItems = (variableValue) => {
  const items = [];
  for (let i = 0; i < variableValue; i++) {
    items.push(
      <Image className="me-1" src={ReviewStar} alt="Review Star" key={i} />
    );
  }
  return items;
};

// Because this is an inframe, so the SSR mode doesn't not do well here.
// It will work on real devices.
const ReviewCard = ({ deviceType, feedBackData }) => (
  <Carousel
    deviceType={deviceType}
    itemClass="image-item"
    responsive={responsive}
    customLeftArrow={<CustomLeftArrow />}
    customRightArrow={<CustomRightArrow />}
    infinite={true}
  >
    {feedBackData.map((feedBackDetail, index) => (
      <a
        href="https://www.trustpilot.com/review/stashed.gg"
        key={`card_${index}`}
        className="text-decoration-none"
      >
        <Card className="mb-2 mx-2" key={`card_${index}`}>
          <Card.Header>
            <span>{feedBackDetail.name}</span>
            <div>{renderItems(feedBackDetail.rating)}</div>
          </Card.Header>
          <Card.Body>
            <Card.Text
              dangerouslySetInnerHTML={{ __html: feedBackDetail.review }}
            />
          </Card.Body>
        </Card>
      </a>
    ))}
  </Carousel>
);
ReviewCard.getInitialProps = ({ req }) => {
  let userAgent;
  if (req) {
    userAgent = req.headers["user-agent"];
  } else {
    userAgent = navigator.userAgent;
  }
  const parser = new UAParser();
  parser.setUA(userAgent);
  const result = parser.getResult();
  const deviceType = (result.device && result.device.type) || "desktop";
  return { deviceType };
};
export default ReviewCard;
