// Images
import Trustpilot from "@/assets/images/Trustpilot.webp";
import ReviewCard from "./ReviewCard";
import Image from "next/image";

const ReviewSlider = ({ feedBackData, trustpilot }) => (
  <section className="ReviewSlider">
    <div className="container">
      <h2 className="sectionTitle ">
        <span>Reviews</span>
        <div className="reviewsLogo">
          <a
            href="https://www.trustpilot.com/review/stashed.gg"
            className="text-decoration-none"
          >
            <Image
              src={Trustpilot}
              alt="Trustpilot Logo"
              width={100}
              height={24.5}
            />
            <p>{trustpilot}</p>
          </a>
        </div>
      </h2>
      <ReviewCard feedBackData={feedBackData} />
      <div className="sliderArrow"></div>
    </div>
  </section>
);

export default ReviewSlider;
