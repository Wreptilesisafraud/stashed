import React, { useContext } from "react";
import { useRouter } from "next/navigation";
import { AuthContext } from "@/contexts/AuthContexts";
import LazyLoad from "react-lazyload";
import Image from "next/image";

const CTASection = ({ bannerSectionData }) => {
  const router = useRouter();
  const { authStatus } = useContext(AuthContext);

  return (
    <section className="CTASection">
      <div className="container">
        <div className="data">
          <h2 className="sectionTitle">{bannerSectionData?.title}</h2>
          <div
            className="content"
            dangerouslySetInnerHTML={{
              __html: bannerSectionData?.description,
            }}
          ></div>
          {authStatus !== 1 && (
            <a
              href=""
              onClick={() => router.push(`${bannerSectionData?.link}`)}
              className="buttonStyle2 CreatAccountBtn"
            >
              {bannerSectionData?.btnText}
            </a>
          )}
        </div>
      </div>
      <div className="bgImg">
        <LazyLoad once>
          <Image
            src={bannerSectionData?.image}
            alt="CTA BG"
            width={1500}
            height={631}
          />
        </LazyLoad>
      </div>
    </section>
  );
};

export default CTASection;
