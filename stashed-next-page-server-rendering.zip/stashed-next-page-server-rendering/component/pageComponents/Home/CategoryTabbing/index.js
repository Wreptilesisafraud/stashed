import React, { useEffect, useState } from "react";
// Component
import { Tab, Tabs, Row, Col, Button, Spinner, Badge } from "react-bootstrap";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { GetProductListData } from "@/redux/features/ProductService";
import { GetCategoryListData } from "@/redux/features/CategoryService";
import { useParams } from "react-router-dom";
import Carousel from "react-multi-carousel";

// Images
// import dataEmptyImg from "../../../assets/images/dataEmpty.webp";
import LazyLoad from "react-lazyload";
import Image from "next/image";
import Link from "next/link";

const responsive = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 6,
    paritialVisibilityGutter: 60,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 6,
    paritialVisibilityGutter: 50,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 6,
    paritialVisibilityGutter: 30,
  },
};
const style = {
  padding: "15px 10px",
  background: "#1e0550",
  border: "1px #FFF solid",
  color: "#FFF",
  fontSize: "12px",
  borderRadius: "5px",
};
const CategoryTabbing = () => {
  const { categorySlug } = useParams();
  const dispatch = useDispatch();
  const router = useRouter();
  const { categoryData } = useSelector((state) => state.categorys);
  const [isCategoryId, setCategoryId] = useState(categoryData[0]?.id);
  const [isCategoryData, setCategoryData] = useState([categoryData]);
  const [selectedCategory, setSelectedCategory] = useState({});
  const [subCategory, setSubCategory] = useState([]);
  const [isProductData, setProductData] = useState([]);
  const [activeKey, setActiveKey] = useState(
    isCategoryData.length > 0
      ? !categorySlug
        ? isCategoryData[0].id
        : isCategoryData.find((cat) => cat.url === categorySlug)?.id
      : null
  );
  const { productData, loading } = useSelector((state) => state.products);
  useEffect(() => {
    dispatch(GetCategoryListData());
  }, [dispatch]);

  useEffect(() => {
    if (isCategoryData.length) {
      handleCategorySelect(
        !categorySlug
          ? isCategoryData[0].id
          : isCategoryData.find((cat) => cat.url === categorySlug)?.id
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isCategoryData]);

  const handleBuyNow = (categoryId, subCategoryId, productId) => {
    router.push(`/games/${categoryId}/${subCategoryId}/${productId}`);
  };

  const handleCategorySelect = (categoryId, isClicked = false) => {
    if (loading) return;
    let clickedCategory = isCategoryData?.find(
      (cat) => Number(cat.id) === Number(categoryId)
    );
    setSelectedCategory(clickedCategory);
    // setSubCategory(prev => categoryData?.filter(cat => cat.parent_id === Number(categoryId)));
    setCategoryId(categoryId);
    setActiveKey(categoryId);
    setProductData([]);
    categoryId && dispatch(GetProductListData({ categoryId }));
    isClicked && window.history.replaceState("", "", clickedCategory.url);
  };

  useEffect(() => {
    setProductData(productData);
  }, [productData]);

  useEffect(() => {
    if (categoryData.length > 0) {
      setCategoryData(
        [...categoryData]
          .filter((cat) => cat.parent_id === 0)
          .sort((a, b) => a.parent_id - b.parent_id)
      );
    }
  }, [categoryData]);

  return (
    <section className="tabbing">
      <div className="container">
        <Tabs
          disabled={true}
          activeKey={activeKey}
          id="tabs"
          className="mb-3 position-relative scrollDesign_x"
          fill
          onSelect={(e) => handleCategorySelect(e, true)}
        >
          {isCategoryData.length
            ? isCategoryData.map((categoryDetail) => (
                <Tab
                  key={categoryDetail.id + "-"}
                  eventKey={categoryDetail.id}
                  title={
                    <div className="tabHeading">
                      <Image
                        src={categoryDetail.image_url}
                        alt={categoryDetail.name}
                        loading="lazy"
                        height={40}
                        width={40}
                      />
                      <span className="categoryName">
                        {categoryDetail.name}
                      </span>
                    </div>
                  }
                >
                  {/* <Carousel
                  // ssr
                  // partialVisbile
                  centerMode={false}
                  // deviceType={deviceType}
                  itemClass="image-item"
                  responsive={responsive}
                >
                  {subCategory.map(item => {
                    return (
                      <button style={style}>{item.name}</button>
                    );
                  })}
                </Carousel> */}
                  <div className="tabContent productList">
                    <Row className="justify-content-center">
                      {isProductData.length > 0 ? (
                        isProductData.map((product, itemIndex) =>
                          itemIndex < 8 ? (
                            <Col
                              xs={12}
                              md={6}
                              xl={3}
                              key={itemIndex}
                              className="productItem"
                            >
                              <div className="productCard" key={itemIndex}>
                                <LazyLoad once>
                                  <Image
                                    className="productImg"
                                    alt="product Images"
                                    src={product.image_url}
                                    height={500}
                                    width={365}
                                  />
                                </LazyLoad>
                                <div className="productContent">
                                  <div className="PTag">
                                    {product.has_hot_offer ? (
                                      <div className="productTag hot">
                                        <span>Hot Offer</span>
                                      </div>
                                    ) : (
                                      ""
                                    )}
                                    {product.discount_value ? (
                                      <div className="productTag sale">
                                        <span>{product.discount_value} %</span>
                                      </div>
                                    ) : (
                                      ""
                                    )}
                                  </div>
                                  <div className="productTitle">
                                    {product.name}
                                  </div>
                                  <div
                                    className="productTagList"
                                    dangerouslySetInnerHTML={{
                                      __html: product.short_description,
                                    }}
                                  ></div>
                                  <div className="productFooter">
                                    <Button
                                      className={`buttonStyle1 product_btn ${categoryDetail.id}`}
                                    >
                                      <Link
                                        href={`/games/${categoryDetail.slug}/${
                                          product?.categories?.find(
                                            (cat) => cat?.parent_id != 0
                                          ).slug
                                        }/${product.slug}`}
                                        style={{
                                          textDecoration: "none",
                                          color: "#fff",
                                        }}
                                      >
                                        Buy Now
                                      </Link>
                                    </Button>
                                    <div className="productPrice">
                                      <span>From</span> $
                                      {!product.min_purchase_qty ||
                                      product.min_purchase_qty === 0 ||
                                      product.min_purchase_qty === "" ||
                                      product.min_purchase_qty === null
                                        ? (
                                            product.min_purchase_qty * 1
                                          ).toFixed(2)
                                        : (
                                            product.min_price *
                                            product.min_purchase_qty
                                          ).toFixed(2)}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </Col>
                          ) : (
                            ""
                          )
                        )
                      ) : loading ? (
                        <>
                          <div className="text-center my-5">
                            <Spinner animation="border" variant="light" />
                          </div>
                        </>
                      ) : (
                        ""
                      )}
                    </Row>

                    {isProductData.length > 0 ? (
                      <a
                        href={() => false}
                        className="loadMore"
                        onClick={() =>
                          router.push(`/games/${selectedCategory?.slug}`)
                        }
                      >
                        Load More
                      </a>
                    ) : (
                      ""
                    )}
                  </div>
                </Tab>
              ))
            : ""}
        </Tabs>
      </div>
    </section>
  );
};

export default CategoryTabbing;
