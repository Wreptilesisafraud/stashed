// Component
import Image from "next/image";
import { Card, Row, Col } from "react-bootstrap";
import LazyLoad from "react-lazyload";

const FeaturesCard = ({ featuresData }) => {
  const bgColor = [
    "157.6deg, #915BFF 30.24%, #581CD8 88.83%",
    "125.37deg, #FFD15A 22.92%, #FF7E62 95.08%",
    "125.37deg, #21E29D 22.92%, #12A4C4 92.08%",
  ];

  return (
    <>
      <section className="FeaturesCard">
        <div className="container">
          <h2 className="sectionTitle text-center">Features</h2>
          <Row className="justify-content-center">
            {featuresData.map((featursDetail, index) => (
              <Col xs={12} md={6} xl={4} className="py-2 my-1" key={index}>
                <Card
                  className="mb-2"
                  style={{
                    background: `linear-gradient(${bgColor[index]})`,
                  }}
                >
                  <Card.Header>
                    <LazyLoad once>
                      <Image
                        src={featursDetail.image}
                        alt="Features Card Icon 111"
                        width={57}
                        height={57}
                      />
                    </LazyLoad>
                    <span>{featursDetail.title}</span>
                  </Card.Header>
                  <Card.Body>
                    <Card.Text>{featursDetail.description}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </div>
      </section>
    </>
  );
};

export default FeaturesCard;
