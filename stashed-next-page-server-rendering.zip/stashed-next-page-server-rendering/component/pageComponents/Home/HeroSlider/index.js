import React, { useContext, useState } from "react";
import { Button, Carousel, NavLink } from "react-bootstrap";
// import SliderDown_arrow from "../../../assets/images/sliderDown_arrow.webp";
import Trustpilot from "@/assets/images/Trustpilot.webp";
import { useRouter } from "next/navigation";
import LazyLoad from "react-lazyload";
import { AuthContext } from "@/contexts/AuthContexts";
import Image from "next/image";

const HeroSlider = ({ homeSliderData, trustpilot }) => {
  const { authStatus } = useContext(AuthContext);

  const router = useRouter();
  const [activeIndex, setActiveIndex] = useState(0);

  const handleSelect = (selectedIndex) => {
    setActiveIndex(selectedIndex);
  };
  // console.log("heroslider:", homeSliderData);
  return (
    <section className="heroSlider carousel-container">
      <Carousel fade activeIndex={activeIndex} onSelect={handleSelect}>
        {homeSliderData?.map((sliderDetail, index) => (
          <Carousel.Item
            key={index}
            style={{
              backgroundImage: `url(${sliderDetail.image})`,
            }}
            className={index === activeIndex ? "active" : ""}
          >
            <Carousel.Caption>
              <h2
                className="title"
                dangerouslySetInnerHTML={{
                  __html: sliderDetail.title,
                }}
              />
              <h3 className="subTitle">{sliderDetail.sub_title}</h3>
              {authStatus !== 1 && (
                <NavLink>
                  <Button
                    className="buttonStyle1 slideBtn"
                    onClick={() => router.push(`${sliderDetail.link}`)}
                  >
                    {sliderDetail.text}
                  </Button>
                </NavLink>
              )}
            </Carousel.Caption>
          </Carousel.Item>
        ))}
      </Carousel>
      <div className="TrustpilotReviews">
        <a
          href="https://www.trustpilot.com/review/stashed.gg"
          className="text-decoration-none"
        >
          <LazyLoad>
            <Image
              src={Trustpilot}
              alt="Trustpilot Logo"
              width={100}
              height={25}
            />
          </LazyLoad>
          <span>{trustpilot}</span>
        </a>
      </div>
    </section>
  );
};

export default HeroSlider;
