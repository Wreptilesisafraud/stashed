import React, { useEffect, useState, useRef } from "react";
import {
  Container,
  Row,
  Col,
  Nav,
  NavDropdown,
  Breadcrumb,
  Badge,
  Spinner,
  Popover,
  OverlayTrigger,
} from "react-bootstrap";

// Section
import CategorySideBar from "../Category/Sidebar/index";
import ProductData from "./ProductData";
import CustomOrderSection from "../Category/customOrderCTA/index";
import ProductOption from "./ProductOption";
// import { useNavigate, useParams, Link } from "react-router-dom";
import { useRouter, useParams } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { GetSingleProductListData } from "@/redux/features/ProductService";
import RightArrow from "@/assets/images/RightArrow.webp";
import LazyLoad from "react-lazyload";
import Image from "next/image";
import Link from "next/link";
const ProductsList = ({
  childCategoryId,
  categoryId,
  productId,
  singleProductCategoryData,
  singleProductData,
}) => {
  if (typeof window !== "undefined") {
    window.scrollTo(0, 0);
  }

  // const navigate = useNavigate();
  const router = useRouter();
  const [toggleMenu, setToggleMenu] = useState(true);
  const dispatch = useDispatch();
  const { subCategory, loading } = useSelector((state) => state.products);
  const { catalogData } = useSelector((state) => state.catalogs);
  const [showPopover, setShowPopover] = useState(false);
  const triggerElement = useRef(null);

  const handleClick = () => {
    setShowPopover(!showPopover);
  };

  const handleOutsideClick = (e) => {
    // Check if the click is outside the Popover and the trigger element
    if (
      showPopover &&
      triggerElement.current &&
      !triggerElement.current.contains(e.target)
    ) {
      setShowPopover(false);
    }
  };

  useEffect(() => {
    if (categoryId && productId) {
      dispatch(
        GetSingleProductListData({
          categoryId,
          childCategoryId,
          productId,
          loading,
        })
      );
    }
  }, [categoryId, childCategoryId, productId, dispatch]);

  useEffect(() => {
    document.addEventListener("click", handleOutsideClick);
    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, [showPopover]);

  const handleRedirect = (slug) => {
    router.push("/games/" + slug);
  };

  const popoverBottom = (
    <Popover
      className="headerMenuPopup category-popover"
      id="popover-positioned-bottom"
    >
      <Popover.Body className="p-0">
        <Col xs={12} md={4} className="iconCol">
          {catalogData.map((parentCatDetail, index) => (
            <div
              className="side-cat-list"
              onClick={(e) => handleRedirect(parentCatDetail?.slug)}
              key={index}
            >
              {console.log(parentCatDetail.slug)}
              <div className="mainMenu">
                <Image
                  src={parentCatDetail?.image_url}
                  alt="Category Logo"
                  width={35}
                  height={35}
                />
                <span className="title">{parentCatDetail?.name}</span>
              </div>
            </div>
          ))}
        </Col>
      </Popover.Body>
    </Popover>
  );

  return (
    <div className="ProductDetailsPage">
      <Container fluid>
        <Row>
          <Col
            xs={12}
            lg={3}
            id="sidebar"
            className="sidebar d-none d-lg-block"
          >
            <OverlayTrigger
              trigger="click"
              placement="bottom"
              overlay={popoverBottom}
              show={showPopover}
            >
              <div
                ref={triggerElement}
                onClick={handleClick}
                className="dropdown side-parent-cat"
              >
                <div
                  className="mainMenu"
                  // onClick={() => {
                  //   setToggleMenu(prev => !prev)
                  // }}
                >
                  <LazyLoad once>
                    <Image
                      src={singleProductCategoryData?.image_url}
                      alt="Category Logo"
                      width={35}
                      height={35}
                    />
                  </LazyLoad>
                  <span className="title">
                    {singleProductCategoryData?.name}
                  </span>
                </div>
              </div>
            </OverlayTrigger>
            <Nav className="me-auto flex-column">
              <NavDropdown show={toggleMenu}>
                {singleProductCategoryData?.child_categories?.map(
                  (childData, index) => (
                    <NavDropdown.Item
                      onClick={() =>
                        router.push(
                          `/games/${singleProductCategoryData.slug}/${childData.slug}`
                        )
                      }
                      className={childData.slug === categoryId ? "active" : ""}
                      key={index}
                    >
                      <Image
                        width={35}
                        height={35}
                        src={
                          childData.meta_image_url
                            ? childData.meta_image_url
                            : childData.image_url
                            ? childData.image_url
                            : RightArrow
                        }
                        alt={childData?.name}
                      />
                      <span>{childData?.name}</span>
                    </NavDropdown.Item>
                  )
                )}
              </NavDropdown>
            </Nav>
          </Col>
          <Col xs={12} lg={9} id="pageContent" className="p-0 pageContent">
            <Container>
              {!Array.isArray(singleProductCategoryData) && !loading && (
                <div className="pageTitleBlock">
                  <div className="titleBlock">
                    <Breadcrumb>
                      <Breadcrumb.Item onClick={() => navigate("/")}>
                        Home
                      </Breadcrumb.Item>
                      <Breadcrumb.Item
                        onClick={() =>
                          navigate(`/games/${singleProductCategoryData.slug}`)
                        }
                      >
                        {singleProductCategoryData?.name}
                      </Breadcrumb.Item>
                      {subCategory && (
                        <Breadcrumb.Item
                          onClick={() =>
                            navigate(
                              `/games/${singleProductCategoryData.slug}/${subCategory.slug}`
                            )
                          }
                        >
                          {subCategory?.name}
                        </Breadcrumb.Item>
                      )}
                      <Breadcrumb.Item active>
                        {singleProductData?.name}
                      </Breadcrumb.Item>
                    </Breadcrumb>
                    <div className="pageTitle">{singleProductData?.name}</div>
                    {singleProductData?.tags?.length &&
                      singleProductData?.tags?.map((tag) => (
                        <Badge
                          key={tag.name}
                          pill
                          bg="success"
                          className={`me-2`}
                        >
                          {tag.name}
                        </Badge>
                      ))}
                  </div>
                  <div className="d-lg-none categorySideBarBtn">
                    <CategorySideBar
                      singleProductCategoryData={singleProductCategoryData}
                    />
                  </div>
                </div>
              )}
              {!Array.isArray(singleProductData) && !loading ? (
                <div className="ProductContentBlock">
                  <div className="contentBlock">
                    <ProductData productData={singleProductData} />
                  </div>
                  <div className="optionsBlock">
                    <ProductOption productData={singleProductData} />
                  </div>
                </div>
              ) : (
                <>
                  <div className="text-center my-5">
                    <Spinner animation="border" variant="light" />
                  </div>
                </>
              )}
              <CustomOrderSection />
            </Container>
          </Col>
        </Row>
      </Container>
    </div>
  );
};
export default ProductsList;
