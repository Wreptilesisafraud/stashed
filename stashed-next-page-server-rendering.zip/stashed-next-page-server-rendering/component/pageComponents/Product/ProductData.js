import React from "react";
import { Accordion } from "react-bootstrap";
import QuestionMark from "@/assets/images/QuestionMark.webp";
import FeaturesCard from "../Home/FeaturesCard";
import Image from "next/image";

const ProductData = ({ productData }) => (
  <>
    <div
      className="ProductData"
      dangerouslySetInnerHTML={{ __html: productData.description }}
    ></div>

    {productData?.features?.length > 0 ? (
      <>
        <FeaturesCard featuresData={productData.features} />
      </>
    ) : (
      <></>
    )}

    {productData?.faqs?.length > 0 ? (
      <>
        <section className="AccordionSec">
          <div className="container">
            <div className="titleBlock">
              <Image
                width={50}
                height={50}
                src={QuestionMark}
                className="sectionHeadingIcon"
                alt="QuestionMark Icon"
              />
              <h2 className="sectionTitle ">Frequently Asked Questions</h2>
            </div>
            <Accordion defaultActiveKey="0">
              {productData.faqs?.map((faqDetail, index) => (
                <Accordion.Item eventKey={index} key={index}>
                  <Accordion.Header>{faqDetail.title}</Accordion.Header>
                  <Accordion.Body
                    dangerouslySetInnerHTML={{
                      __html: faqDetail.description.replaceAll("\n", "<br/>"),
                    }}
                  />
                </Accordion.Item>
              ))}
            </Accordion>
          </div>
        </section>
      </>
    ) : (
      <></>
    )}
  </>
);

export default ProductData;
