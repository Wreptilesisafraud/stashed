import React, { useState } from "react";
import { Form } from "react-bootstrap";

const RangeSlider = ({ variation, onClick }) => {

  const rangeOptions = [];
  variation.variant_value.map((variantValueDetail, index) => {
    variantValueDetail.variant.split('-').map(opt => {
      rangeOptions.push(Number(opt));
    })
  })
  const minValue = rangeOptions.reduce((acc, current) => Math.min(acc, current));
  const maxValue = rangeOptions.reduce((acc, current) => Math.max(acc, current));

  const [textValue, setTextValue] = useState(minValue)

  const onChange = (e) => {
    setTextValue(e.target.value)
    const selectedVariationDetail = variation.variant_value.find(vd => {
      const variationRange = vd.variant.split('-');
      return (Number(variationRange[0]) <= Number(e.target.value) && Number(variationRange[1]) >= Number(e.target.value))
    });
    // console.log(selectedVariationDetail);
    onClick && onClick(selectedVariationDetail)
  }
  return (
    <Form.Group className="mb-3 FormGroup variation-element-select-control" key={variation.variant_name}>
      <Form.Label>{variation.variant_name}</Form.Label>
      <Form.Control
        type={"number"}
        className="variation-element-select text-white"
        value={textValue}
        min={minValue}
        max={maxValue}
        placeholder="Enter amount"
        onChange={onChange}
      />
      <Form.Range
        step={1}
        value={textValue}
        min={minValue}
        max={maxValue}
        onChange={onChange}
      />
    </Form.Group>
  );
};

export default RangeSlider;