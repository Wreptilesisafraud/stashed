import React, { useEffect } from "react";
import { Form } from "react-bootstrap";
import { isEmptyObject } from "@/utils/lib";

const DefaultCompoment = ({ variation, onClick, counter, data }) => {
  useEffect(() => {
    isEmptyObject(data) && counter === 0 && onClick(variation.variant_value[0]);
  }, []);

  return (
    <Form.Group className="mb-3 FormGroup" key={variation.variant_name}>
      <Form.Label>{variation.variant_name}</Form.Label>
      {variation.variant_value.map((variantValueDetail, index) => (
        <Form.Check
          defaultChecked={counter === 0 && index === 0}
          type="radio"
          key={`${variantValueDetail.nameId}-${variantValueDetail.valueId}`}
          name={variation.variant_name}
          label={variantValueDetail.variant}
          value={`${variantValueDetail.nameId}-${variantValueDetail.valueId}`}
          onClick={(e) => {
            onClick && onClick(variantValueDetail);
          }}
          id={`${variantValueDetail.nameId}-${variantValueDetail.valueId}`}
        />
      ))}
    </Form.Group>
  );
};

export default DefaultCompoment;
