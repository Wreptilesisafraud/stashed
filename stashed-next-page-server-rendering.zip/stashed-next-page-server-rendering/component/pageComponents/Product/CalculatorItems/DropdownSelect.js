import React, { useEffect, useState } from "react";
import Select from "react-dropdown-select";
import { Button, Form, Dropdown } from "react-bootstrap";

const DropdownSelect = ({ variation, onClick }) => {
  const options = variation.variant_value.map((variantValueDetail, index) => (
    {
      value: `${variantValueDetail.nameId}-${variantValueDetail.valueId}`,
      label: variantValueDetail.variant
    }
  ))

  const onChange = (values) => {
    const { label } = values[0];
    const selectedVariationDetail = variation.variant_value.find(vd => vd.variant === label);
    onClick && onClick(selectedVariationDetail)
  }
  return (
    <Form.Group className="mb-3 FormGroup variation-element-select-control" key={variation.variant_name}>
      <Form.Label>{variation.variant_name}</Form.Label>
      <Select 
        options={options} 
        onChange={(values) => onChange(values)} 
        className="variation-element-select"
      />
    </Form.Group>
  )
}

export default DropdownSelect;