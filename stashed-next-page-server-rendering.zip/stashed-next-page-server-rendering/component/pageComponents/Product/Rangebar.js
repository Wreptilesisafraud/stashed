import React, { useState } from "react";

const RangeBar = () => {
  const [minValue, setMinValue] = useState(0);
  const [maxValue, setMaxValue] = useState(100);

  const handleMinInputChange = (event) => {
    const newMinValue = parseInt(event.target.value);
    setMinValue(newMinValue);

    if (newMinValue > maxValue) {
      // Adjust the max value if the new min value is greater
      setMaxValue(newMinValue);
    }
  };

  const handleMaxInputChange = (event) => {
    const newMaxValue = parseInt(event.target.value);
    setMaxValue(newMaxValue);

    if (newMaxValue < minValue) {
      // Adjust the min value if the new max value is smaller
      setMinValue(newMaxValue);
    }
  };

  return (
    <div>
      <div>
        <label htmlFor="minInput">Minimum Value:</label>
        <input
          type="number"
          id="minInput"
          value={minValue}
          onChange={handleMinInputChange}
        />
      </div>
      <div>
        <label htmlFor="maxInput">Maximum Value:</label>
        <input
          type="number"
          id="maxInput"
          value={maxValue}
          onChange={handleMaxInputChange}
        />
      </div>
      <div>
        <input
          type="range"
          min={minValue}
          max={maxValue}
          value={minValue}
          onChange={(event) => setMinValue(parseInt(event.target.value))}
        />
      </div>
    </div>
  );
};

export default RangeBar;