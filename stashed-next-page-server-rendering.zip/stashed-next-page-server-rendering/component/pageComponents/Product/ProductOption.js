import { setNestedObjectValues, useFormik } from "formik";
import React, { useEffect, useState, useRef, useContext } from "react";
import { Badge, Button, Form } from "react-bootstrap";
import InputGroup from "react-bootstrap/InputGroup";
// import { useNavigate, useLocation } from "react-router-dom";
import { useRouter } from "next/router";
import { useDispatch, useSelector } from "react-redux";
import _ from "lodash";
import LightningIcon from "@/assets/images/LightningIcon.svg";
import ProductPageSidebarBG from "@/assets/images/ProductPageSidebarBG.webp";
// import MultiRangeSlider from "multi-range-slider-react";
import "react-range-slider-input/dist/style.css";
import DefaultCompoment from "./CalculatorItems/DefaultComponent";
import DropdownSelect from "./CalculatorItems/DropdownSelect";
import {
  addCartItem,
  addPreCartItem,
  getCartItems,
} from "@/redux/features/CartService";
import { AuthContext } from "@/contexts/AuthContexts";
import { toast } from "react-toastify";
import RangeSlider from "./CalculatorItems/RangeSlider";
import { NumberWithCommas } from "@/utils/lib.js";
import { usePathname } from "next/navigation";
import Image from "next/image";

const ProductOption = ({ productData }) => {
  // const navigate = useNavigate();
  // const location = useLocation();
  const router = useRouter();
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user);
  const auth = useContext(AuthContext);

  const ref_selected_variations = useRef([]);

  const [isVariationData, setVariationData] = useState([]);
  const [range, setRange] = useState({ pMin: 0, pMax: 100 });
  const [groupList, setGroupList] = useState([]);
  const [sliderRange, setSliderRange] = useState({
    pMin: 0,
    pMax: range?.pMax,
  });
  const [quantity, setQuantity] = useState(1);
  const [maxQuantity, setMaxQuantity] = useState(0);
  const [minPurchaseQty, setMinPurchaseQty] = useState(0);
  const [quantityFormatter, setQuantityFormatter] = useState("");
  const [price, setPrice] = useState(0);
  const [userLevel, setUserLevel] = useState(1);
  const [desiredLevel, setDesiredLevel] = useState(1);
  const [hasLevelUp, setHasLevelUp] = useState(false);
  const [levelVariants, setLevelVarients] = useState([]);
  const [selectedAdditionOptions, setAdditionalOptions] = useState([]);
  const [finalPrice, setFinalPrice] = useState(0);
  const [hasDiscount, setHasDiscount] = useState(false);
  const [calVal, setCalVal] = useState(0);
  const [previousQuantity, setPreviousQuantity] = useState(0);
  const [tempQuantity, setTempQuantity] = useState(0);

  useEffect(() => {
    if (productData && productData?.min_purchase_qty)
      setQuantity(productData.min_purchase_qty ?? 0);
    if (
      productData &&
      productData?.variation_list &&
      productData?.has_variation
    ) {
      const variationList = productData?.variation_list;
      const transformedData = variationList.reduce((result, item) => {
        const {
          veriant_name: variantName,
          variant_value: variantValue,
          name_id: nameId,
          value_id: valueId,
          variation,
        } = item;

        if (!result[variantName]) {
          result[variantName] = {
            product_id: item.product_id,
            variant_name: variantName,
            variant_value: [],
          };
        }
        const variantValues = {
          variant: variantValue,
          nameId: nameId,
          valueId: valueId,
        };
        result[variantName].variant_value.push(variantValues);
        result[variantName].variation = variation;
        return result;
      }, {});

      let transformedVariationList = Object.values(transformedData);
      let ok = transformedVariationList
        .map((itemVal) => {
          if (itemVal.variant_name === "LevelUp") {
            const min = Math.min(
              ...itemVal.variant_value.map((value) => {
                return parseInt(value.variant.split("-")[0]);
              })
            );
            const max = Math.max(
              ...itemVal.variant_value.map((value) =>
                parseInt(value.variant.split("-")[1])
              )
            );
            return {
              min: min,
              max: max,
            };
          }
        })
        .find((data) => data !== undefined);
      if (ok) {
        setRange({ pMin: ok?.min, pMax: ok?.max });
        setHasLevelUp(true);
        const _levelupVariants = transformedVariationList.filter(
          (itemVal) => itemVal.variant_name === "LevelUp"
        );
        setLevelVarients(_levelupVariants);
      }

      const finalList = transformedVariationList.filter(
        (itemVal) => itemVal.variant_name !== "LevelUp"
      );

      setVariationData(finalList);
    } else if (productData && !productData?.has_variation) {
      setPrice(productData.min_price ?? 0);
    }
    if (productData && productData?.groups) {
      setGroupList(productData?.groups);
    }

    if (productData && productData?.discount_value) {
      const today = new Date().getTime() / 1000;
      const discountStartDate = productData?.discount_start_date;
      const discountEndDate = productData?.discount_end_date;
      if (discountStartDate < today && today < discountEndDate) {
        setHasDiscount(true);
      }
    }
  }, [productData]);

  const formik = useFormik({
    initialValues: {},
    onSubmit: (values) => {
      // Handle the checked values as needed
    },
  });

  useEffect(() => {
    // Should sort values by name Id
    // Should need to add levelup logic
    let totalPrice = 0;
    const variants = Object.keys(formik.values).map(
      (key) => formik.values[key]
    );

    if (variants.length == 0) return;
    variants.sort((a, b) => parseInt(a.nameId) - parseInt(b.nameId));
    if (hasLevelUp) {
      // find selected variants by userLevel and desiredLevel.
      const possibleItems = levelVariants
        .map((lvVariants) => {
          return lvVariants.variant_value.map((lvvv) => {
            const values = lvvv.variant.split("-");
            const min = parseInt(values[0]);
            const max = parseInt(values[1]);
            if (
              (min <= userLevel && max >= userLevel) ||
              (min <= desiredLevel && max >= desiredLevel) ||
              (min >= userLevel && max <= desiredLevel)
            ) {
              return lvvv;
            }
          });
        })
        .flat()
        .filter((lv) => lv != undefined);
      ref_selected_variations.current = [];
      if (possibleItems.length) {
        const prices = possibleItems.map((item) => {
          const _variants = [...variants, item];
          const variationKeys = _variants.map(
            (variant) => `${variant.nameId}:${variant.valueId}`
          );
          const selectedVariationKey = variationKeys.join("/") + "/";
          if (productData?.variations) {
            const selectedVariation = productData?.variations.find(
              (v) => v.variation_key == selectedVariationKey
            );
            if (selectedVariation) {
              ref_selected_variations.current.push(selectedVariation.id);
              return selectedVariation.price;
            } else {
              return 0;
            }
          }
        });
        var sum = prices.reduce((accumulator, currentValue) => {
          return accumulator + currentValue;
        }, 0);
        totalPrice = sum;
      }
    } else {
      const variationKeys = variants.map(
        (variant) => `${variant.nameId}:${variant.valueId}`
      );
      const selectedVariationKey = variationKeys.join("/") + "/";
      if (productData?.variations) {
        const selectedVariation = productData?.variations.find(
          (v) => v.variation_key == selectedVariationKey
        );
        if (selectedVariation) {
          setMaxQuantity(
            selectedVariation?.product_variation_stock_without_location
              ?.stock_qty
          );
          setMinPurchaseQty(productData.min_purchase_qty ?? 0);
          setQuantityFormatter(
            productData.qty_in !== "" ? productData.qty_in : ""
          );
          if (
            quantity >
            selectedVariation?.product_variation_stock_without_location
              ?.stock_qty
          ) {
            setQuantity(
              selectedVariation?.product_variation_stock_without_location
                ?.stock_qty
            );
          }
          // ref_selected_variations.current.push(selectedVariation.id)
          ref_selected_variations.current = [selectedVariation.id];
          if (quantity == 0) {
            totalPrice = selectedVariation.price;
          } else {
            totalPrice = selectedVariation.price * quantity;
          }
        }
      }
    }
    if (selectedAdditionOptions.length) {
      selectedAdditionOptions.forEach((ad) => {
        totalPrice += ad.price;
      });
    }
    setPrice(totalPrice);
  }, [
    formik.values,
    userLevel,
    desiredLevel,
    selectedAdditionOptions,
    quantity,
  ]);

  useEffect(() => {
    if (price !== 0) {
      if (productData?.discount_value) {
        if (productData?.discount_type === "flat") {
          if (price >= productData?.discount_value) {
            setFinalPrice(price - productData?.discount_value);
          } else {
            setFinalPrice(0);
          }
        } else {
          setFinalPrice(price - price * (productData?.discount_value / 100));
        }
      } else {
        setFinalPrice(price);
      }
    }
  }, [price, quantity]);

  const handleSubmit = (isAddToCart = false) => {
    if (price === 0) {
      return;
    }

    const selectedVariationIds = _.uniq(ref_selected_variations.current);
    const selectedAddonIds = selectedAdditionOptions.map((option) => option.id);

    const { id: productId } = productData;

    const checkoutData = {
      productId,
      variations: selectedVariationIds,
      level: desiredLevel,
      qty: quantity,
      addons: selectedAddonIds,
      price,
      // price: Number(price) * Number(quantity),
    };

    if (auth.authStatus) {
      dispatch(addCartItem(checkoutData));
      if (!isAddToCart) {
        router.push("/checkout");
      } else {
        toast.success("Successfully added to cart");
        dispatch(getCartItems());
      }
    } else {
      dispatch(addPreCartItem(checkoutData));
      localStorage.setItem("pendingProductSlug", router.pathname);
      router.push("/signin");
    }
  };

  const handleInputUserLevelChange = (e) => {
    const value = parseInt(e.target.value);
    setUserLevel(value);
    if (value > range.pMin && value <= range.pMax) {
      setSliderRange({ ...sliderRange, pMin: value });
    } else if (value > range.pMax) {
      setSliderRange({ ...sliderRange, pMin: sliderRange?.pMax - 1 });
    } else {
      setSliderRange({ ...sliderRange, pMin: 0 });
    }
  };

  const handleInputMaxChange = (e) => {
    // clones range
    const value = parseInt(e.target.value);
    setDesiredLevel(value);
    if (value <= range.pMax && value > sliderRange.pMin) {
      setSliderRange({ ...sliderRange, pMax: e.target.value });
    } else {
      setSliderRange({ ...sliderRange, pMax: range?.pMax });
    }
  };

  const handleSlide = (e) => {
    setUserLevel(e.minValue);
    setDesiredLevel(e.maxValue);
    setSliderRange({ pMin: e.minValue, pMax: e.maxValue });
  };

  const renderCalculatorComponent = (variation, i) => {
    const { element } = variation.variation;
    let Element = DefaultCompoment;
    if (element === "default" || !element) {
      Element = DefaultCompoment;
    } else if (element === "dropdown") {
      Element = DropdownSelect;
    } else if (element === "custom") {
      Element = RangeSlider;
    }

    return (
      <Element
        variation={variation}
        counter={i}
        data={formik.values}
        onClick={(value) => {
          // console.log("clicekd", value);
          formik.setFieldValue(variation.variant_name, value);
        }}
      />
    );
  };

  const handleRangeInputLeave = (e) => {
    let inputVal = Number(e.target.value.replaceAll(",", ""));
    setQuantity(inputVal < minPurchaseQty ? minPurchaseQty : inputVal);
  };

  const handleRangeChange = (e) => {
    let inputVal = Number(e.target.value.replaceAll(",", ""));
    if (e.target.name) {
      setQuantity(inputVal);
    } else {
      setPreviousQuantity(quantity);
      setCalVal(calVal + 1);
      setTempQuantity(inputVal);
      if (calVal > 1)
        setQuantity(
          tempQuantity > minPurchaseQty ? tempQuantity : minPurchaseQty
        );
    }
  };

  const handleRangeClick = (e) => {
    if (calVal === 1) {
      setQuantity(
        tempQuantity <= minPurchaseQty && previousQuantity == minPurchaseQty
          ? minPurchaseQty
          : tempQuantity > previousQuantity
          ? previousQuantity + minPurchaseQty
          : previousQuantity - minPurchaseQty
      );
    }
    setCalVal(0);
  };

  const handleRangeDragEnd = (e) => {
    //Please do not delete for requirs for furter computation
  };

  const iconBackgroundStyle = {
    backgroundColor: "#fdb146",
    color: "white",
    border: "1px solid #402a6e",
  };

  return (
    <div className="ProductOptionBlock">
      {/* {console.log("test", formik.values)} */}
      <img
        src={productData ? productData.image_url : ProductPageSidebarBG}
        alt="Option Block BG"
        className="optionBlockBG"
      />
      {productData?.has_hot_offer ? (
        <div className="PTag">
          <div className="productTag hot">
            <span>HOT OFFER</span>
          </div>
        </div>
      ) : (
        <></>
      )}
      <Form onSubmit={formik.handleSubmit} className="ProductOptionForm">
        {isVariationData.map((variationData, i) =>
          renderCalculatorComponent(variationData, i)
        )}

        <div>
          {range && hasLevelUp && (
            <>
              <div className="form-label">Level Boost from to</div>
              <div className="levelInputBlock">
                <div className="formGroup">
                  <label>Your Level</label>
                  <input
                    className="form-control"
                    type="number"
                    value={userLevel}
                    onChange={handleInputUserLevelChange}
                  />
                </div>
                <span>=</span>
                <div className="formGroup">
                  <label>Desired Level</label>
                  <input
                    className="form-control"
                    type="number"
                    value={desiredLevel}
                    onChange={handleInputMaxChange}
                  />
                </div>
              </div>
              {/* <MultiRangeSlider
                className="levelRangeSilder"
                onInput={(e) => handleSlide(e)}
                step={1}
                max={range?.pMax}
                min={0}
                maxValue={sliderRange?.pMax}
                minValue={sliderRange?.pMin}
                ruler={false}
              /> */}
            </>
          )}
        </div>
        {productData?.brand_id === 1 && (
          <Form.Group className="mb-3 FormGroup variation-element-select-control">
            <Form.Label>Quantity</Form.Label>
            <InputGroup>
              <Form.Control
                name="quantities"
                className="variation-element-select text-white"
                value={NumberWithCommas(quantity)}
                min={minPurchaseQty}
                max={maxQuantity}
                placeholder="Enter amount"
                onChange={(e) => handleRangeChange(e)}
                onBlur={handleRangeInputLeave}
              />
              {quantityFormatter && (
                <InputGroup.Text id="basic-addon1" style={iconBackgroundStyle}>
                  {quantityFormatter}
                </InputGroup.Text>
              )}
            </InputGroup>

            <div className="custom-range">
              <Form.Range
                step={1}
                value={quantity}
                min={1}
                max={maxQuantity}
                onChange={handleRangeChange}
                onClick={handleRangeClick}
                onMouseUp={handleRangeDragEnd}
              />
            </div>
          </Form.Group>
        )}
        <div
          className="options productAddons"
          data-div-show={groupList?.length}
        >
          <Form.Group className="mb-3 FormGroup">
            {groupList?.length ? (
              groupList?.map((group) => (
                <>
                  <Form.Label className="label mb-2 h5">
                    {group?.title}
                  </Form.Label>
                  {group?.items?.map((item) => (
                    <Form.Check
                      label={
                        <div className="d-flex justify-content-between optionsItem">
                          <Image
                            src={LightningIcon}
                            alt={item?.title}
                            width={10}
                            height={16}
                          />
                          <div className="optionsName ms-2">{item?.title}</div>
                          <div className="optionsValue ms-auto">
                            +${item?.price}
                          </div>
                        </div>
                      }
                      type="checkbox"
                      key={item?.id}
                      id={item?.id}
                      name={group?.title}
                      value={group.title}
                      className={
                        selectedAdditionOptions.findIndex(
                          (ad) => ad.id === item.id
                        ) > -1
                          ? "form-check-active"
                          : ""
                      }
                      onChange={(e) => {
                        const isChecked = e.target.checked;
                        const ifIsExist =
                          selectedAdditionOptions.findIndex(
                            (ad) => ad.id === item.id
                          ) > -1;
                        if (isChecked) {
                          if (!ifIsExist) {
                            setAdditionalOptions((prev) => [...prev, item]);
                          }
                        } else {
                          if (ifIsExist) {
                            setAdditionalOptions((prev) =>
                              prev.filter((ad) => ad.id !== item.id)
                            );
                          }
                        }
                      }}
                    />
                  ))}
                </>
              ))
            ) : (
              <></>
            )}
          </Form.Group>
        </div>
        <div
          className="options"
          data-div-show={!!productData?.unit?.name ? 1 : 0}
        >
          <label>Delivery Time : {productData?.unit?.name}</label>
        </div>

        <hr className="mt-4" />
        <div className="price-summary">
          {hasDiscount && (
            <div className="discount-price">
              <div className="totalAmaountLable">Discount</div>
              <div className="totalAmaount">
                {productData?.discount_type === "flat"
                  ? `$${productData?.discount_value}`
                  : `${productData?.discount_value} %`}
              </div>
            </div>
          )}
          <div className="total-price">
            <div className="totalAmaountLable">Total Amount</div>
            {hasDiscount ? (
              <div>
                <span className="beforeDiscountPrice">${price.toFixed(2)}</span>
                <span className="totalAmaount">
                  ${finalPrice.toFixed(2)} USD
                </span>
              </div>
            ) : (
              <div className="totalAmaount">${price.toFixed(2)} USD</div>
            )}
          </div>
        </div>

        <Button
          variant="primary"
          type="submit"
          className="buttonStyle1 w-100 mt-2"
          onClick={() => handleSubmit(false)}
          disabled={!price}
        >
          Proceed
        </Button>

        <Button
          variant="primary"
          type="submit"
          className="buttonStyle1 w-100 mt-2 addToCartButton"
          onClick={() => handleSubmit(true)}
          disabled={!price}
        >
          Add to Cart
        </Button>
      </Form>
    </div>
  );
};

export default ProductOption;
