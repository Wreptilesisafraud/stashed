import React from "react";
import { Button } from "react-bootstrap";

// Images
import UserDashboard from "../UserDashboard";

// Section
import UserDashboardSidebar from "../UserDashboard/Sidebar/index";
// import NotificationImg from "../../assets/images/notification.png";

const Notifications = () => (
  <UserDashboard title="notification" className="notificationPage">
    <div className="pageTitleBlock">
      <div className="titleBlock">
        <div className="pageTitle">
          Notifications <sup>44</sup>
        </div>
        <div className="d-lg-none categorySideBarBtn">
          <UserDashboardSidebar title="notification" />
        </div>
        <div className="blockAction d-flex flex-grow-1 gap-1 gap-sm-2 align-items-center justify-content-between justify-content-lg-end">
          <p className="m-0">Mark All As Read</p>
          <div className="d-flex gap-1 gap-sm-2 align-items-center">
            <Button className="buttonStyle3">Read</Button>
            <Button className="buttonStyle1">UnRead</Button>
          </div>
        </div>
      </div>
    </div>
    <div className="UserDashboard_body notificationsList scrollDesign_y"></div>
  </UserDashboard>
);

export default Notifications;
