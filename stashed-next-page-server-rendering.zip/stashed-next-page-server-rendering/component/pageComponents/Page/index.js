import React, { useState, useRef, createRef } from "react";
import { Link, redirect, useNavigate, useParams } from "react-router-dom";
import { Breadcrumb, Col, Container, Row } from "react-bootstrap";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
// import { SinglePageData } from "../../redux/features/PageService";
import moment from "moment";
import LazyLoad from "react-lazyload";
import HTMLReactParser from "html-react-parser";
import _ from "lodash";
import slugify from "react-slugify";
import ScrollSpy from "react-ui-scrollspy";
import { Waypoint } from "react-waypoint";

const titleTag = "h3";

const Page = ({ data }) => {
  // const { slug } = useParams();
  // const dispatch = useDispatch();
  // const navigate = useNavigate();
  // const { singlePage } = useSelector((state) => state.page);
  const singlePage = data;
  const [subtitles, setSubtitles] = useState([]);
  const [parsedPage, setParsedPage] = useState(
    HTMLReactParser(singlePage?.content)
  );
  const [elementsRef, setElementRef] = useState([]);
  const [currentSubtitle, setCurrentSubtitle] = useState("");
  const [isStickySubtitle, setIsStickySubtitle] = useState(false);

  const subtitleNavigationRef = useRef();
  const parentContainerRef = useRef();
  const blogRef = useRef();
  const subtitleContainerRef = useRef();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // useEffect(() => {
  //   if (slug) {
  //     dispatch(SinglePageData({ slug }));
  //   }
  // }, [dispatch, slug]);

  return (
    <ScrollSpy
      navContainerRef={subtitleNavigationRef}
      parentScrollContainerRef={parentContainerRef}
      activeClass="active"
      onUpdateCallback={(event) => console.log(event)}
    >
      <div className="blogDetailsPage" ref={parentContainerRef}>
        <Container>
          <div className="pageTitleBlock">
            <div className="titleBlock">
              <div className="pageTitle">{singlePage?.title}</div>
            </div>
          </div>

          {singlePage?.image_url && (
            <LazyLoad once>
              <img
                src={singlePage?.image_url}
                alt="Blog"
                className="singalBlogImg"
              />
            </LazyLoad>
          )}
          <Row className="blogdataBlock" ref={blogRef}>
            <Col xs={12} lg={9} className="blogContent">
              {/* <h4>{singlePage?.title}</h4> */}
              {parsedPage}
              {/* <p
                dangerouslySetInnerHTML={{
                  __html: singlePage?.content,
                }}
              ></p> */}
            </Col>
          </Row>
        </Container>
      </div>
    </ScrollSpy>
  );
};

export default Page;
