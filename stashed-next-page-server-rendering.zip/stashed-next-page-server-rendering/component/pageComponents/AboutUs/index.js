import React, { useEffect, useState } from "react";
import { Button, Card, Col, Container, Row } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { GetAboutUsData } from "@/redux/features/AboutUsService";
import parse from "html-react-parser";
// import { useNavigate } from "react-router-dom";
import LazyLoad from "react-lazyload";

const AboutUs = ({ data }) => {
  const dispatch = useDispatch();
  // const navigate = useNavigate();
  const { aboutUsData } = useSelector((state) => state.aboutUs);
  // const aboutUsData = data;
  const [isAboutData, setAboutData] = useState(data);

  useEffect(() => {
    dispatch(GetAboutUsData());
  }, [dispatch]);

  useEffect(() => {
    if (aboutUsData) {
      setAboutData(aboutUsData);
    }
  }, [aboutUsData]);

  return (
    <>
      <Container className="aboutusPage">
        <Row className="heroSection">
          <Col xs={12} md={6} xl={6} className="contentBlock">
            <h2 className="title">{isAboutData?.intro?.title}</h2>
            <div
              className="subTitle"
              dangerouslySetInnerHTML={{
                __html: isAboutData?.intro.description,
              }}
            ></div>
            <Button
              onClick={() =>
                (window.location.href = `${isAboutData?.intro.button_link}`)
              }
              className="buttonStyle1"
            >
              {isAboutData?.intro.button_text}
            </Button>
          </Col>
          <Col xs={12} md={6} xl={6}>
            <LazyLoad once>
              <img
                src={isAboutData?.intro.image_url}
                alt="About"
                width="100%"
              />
            </LazyLoad>
          </Col>
        </Row>
        <section className="roleSection">
          <div className="text-center titleBlock">
            <h2 className="title">Choose your Role</h2>
            <p className="subTitle">
              You can select to be one or another or simply both
            </p>
          </div>
          <Row className="cardBlock">
            {isAboutData?.choose_your_role.map((roleData, index) => (
              <Col xs={12} md={6} xl={6} key={index}>
                <Card>
                  <h4>{roleData.title}</h4>
                  {parse(roleData.text)}
                  {/* <p dangerouslySetInnerHTML={{ __html: roleData.text }}></p> */}
                  <a href={roleData.button_link} className="buttonStyle1">
                    {roleData.button_text}
                  </a>
                </Card>
              </Col>
            ))}
          </Row>
        </section>

        <section className="benefitsSection">
          <h2 className="title">
            {isAboutData?.benefit?.benefits_title ?? "Benefits"}
          </h2>
          <Row className="justify-content-center">
            {isAboutData?.benefit.benefits.map((benefitData, index) => (
              <Col xs={12} md={6} xl={4} className="mb-3" key={index}>
                <Card>
                  <h5>
                    <span className="img">
                      <img
                        src={benefitData.image}
                        alt="Automation of process"
                      />
                    </span>
                    <span className="SecTitle">{benefitData.title}</span>
                  </h5>
                  <p
                    dangerouslySetInnerHTML={{
                      __html: benefitData.text,
                    }}
                  ></p>
                </Card>
              </Col>
            ))}
          </Row>
          {isAboutData?.benefit.benefits_button_text ? (
            <div className="text-center mt-2 mt-md-3">
              <a
                href={isAboutData?.benefit?.benefits_button_link}
                className="buttonStyle1"
              >
                {isAboutData?.benefit.benefits_button_text}
              </a>
            </div>
          ) : (
            <></>
          )}
        </section>
      </Container>
    </>
  );
};
export default AboutUs;
