import React, { useEffect, useState, useRef } from "react";
import {
  Container,
  Row,
  Col,
  Nav,
  NavDropdown,
  Breadcrumb,
  Button,
  Spinner,
  Popover,
  OverlayTrigger,
} from "react-bootstrap";
// import { useParams } from "react-router-dom";

// Section
import CategorySideBar from "./Sidebar/index";
import CustomOrderSection from "./customOrderCTA/index";
import HowItWork from "./howItWork/index";
// import { useNavigate } from "react-router-dom";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import {
  GetCategoryProductListData,
  GetParentProductListData,
} from "@/redux/features/ProductService";
import LazyLoad from "react-lazyload";
import { GetSingleCategoryData } from "@/redux/features/CategoryService";
import RightArrow from "@/assets/images/RightArrow.webp";
// import dataEmptyImg from "@/assets/images/dataEmpty.webp";
import Image from "next/image";
import Link from "next/link";

const ProductCategoryList = ({
  categoryId,
  singleProductCategoryData,
  categoryProductListData,
}) => {
  // const navigate = useNavigate();
  // const { categoryId } = params;
  const childCategoryId = null;
  const router = useRouter();
  const dispatch = useDispatch();

  const { loading } = useSelector((state) => state.products);
  const productListingData = categoryProductListData.products.data;
  const { catalogData } = useSelector((state) => state.catalogs);
  const [toggleMenu, setToggleMenu] = useState(true);
  const [categoryData, setCategoryData] = useState({});
  const [categoryList, setCategoryList] = useState([]);
  const [products, setProducts] = useState(
    categoryProductListData.products.data
  );
  const [listPerPage, setListPerPage] = useState(30);
  const [page, setPage] = useState(1);
  const [hasLoadMore, setHasLoadMore] = useState(false);
  const [isActiveLoadMore, setActiveLoadMore] = useState(false);

  // const { categoryId, childCategoryId } = useParams();

  // console.log("Category:", categoryId);
  if (typeof window !== "undefined") {
    window.scrollTo(0, 0);
  }

  const [showPopover, setShowPopover] = useState(false);
  const triggerElement = useRef(null);

  const handleClick = () => {
    setShowPopover(!showPopover);
  };

  const handleOutsideClick = (e) => {
    // Check if the click is outside the Popover and the trigger element
    if (
      showPopover &&
      triggerElement.current &&
      !triggerElement.current.contains(e.target)
    ) {
      setShowPopover(false);
    }
  };

  useEffect(() => {
    if (categoryId) {
      dispatch(GetParentProductListData({ categoryId: categoryId })).then(
        (r) => {
          const product = r?.payload?.products?.data?.[0]?.categories?.find(
            (cat) => cat.parent_id === 0
          );
          if (product) {
            // console.log("product", product);
            setCategoryData(
              product?.child_categories?.find(
                (cat) => cat.slug === childCategoryId
              )
            );
          }
        }
      );
    }
    dispatch(
      GetSingleCategoryData({
        categoryId: childCategoryId ? childCategoryId : categoryId,
      })
    ).then((res) => {
      setCategoryList(res?.payload);
      // setProducts([]);
      setPage(1);
    });
  }, []);

  useEffect(() => {
    if (categoryId || childCategoryId) {
      const cate = categoryList?.find(
        (cat) => cat.slug === (childCategoryId ? childCategoryId : categoryId)
      );
      if (
        categoryData?.slug !== (childCategoryId ? childCategoryId : categoryId)
      ) {
        setProducts([]);
        setPage(1);
      }
      setCategoryData(cate);
      dispatch(
        GetCategoryProductListData({
          categoryId: categoryId,
          childCategoryId: childCategoryId,
          page,
          listPerPage,
        })
      );
    }
  }, [categoryId, childCategoryId, page, dispatch, listPerPage]);

  useEffect(() => {
    setProducts((prev) => [...prev, ...productListingData]);
    setHasLoadMore(productListingData.length === 30 ? true : false);
  }, [productListingData]);

  const handleRedirect = (slug) => {
    router.push("/games/" + slug);
  };

  useEffect(() => {
    document.addEventListener("click", handleOutsideClick);
    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, [showPopover]);

  const popoverBottom = (
    <Popover
      className="headerMenuPopup category-popover"
      id="popover-positioned-bottom"
    >
      <Popover.Body className="p-0">
        <Col xs={12} md={4} className="iconCol">
          {catalogData.map((parentCatDetail, index) => (
            <div
              className="side-cat-list"
              onClick={(e) => handleRedirect(parentCatDetail?.slug)}
              key={index}
            >
              <div className="mainMenu">
                <Image
                  src={parentCatDetail?.image_url}
                  alt="Category Logo"
                  width={35}
                  height={35}
                />
                <span className="title">{parentCatDetail?.name}</span>
              </div>
            </div>
          ))}
        </Col>
      </Popover.Body>
    </Popover>
  );

  const handleLoadMore = () => {
    setActiveLoadMore(true);
    setListPerPage(10000);
  };

  // console.log("categorydata", products);
  return (
    <>
      <div className="CategoryList">
        <Container fluid className="p-0">
          <div className="d-flex flex-wrap">
            {/* Sidebar */}
            <div id="sidebar" className="sidebar d-none d-lg-block">
              <OverlayTrigger
                trigger="click"
                placement="bottom"
                overlay={popoverBottom}
                show={showPopover}
              >
                <div
                  ref={triggerElement}
                  onClick={handleClick}
                  className="dropdown side-parent-cat"
                >
                  <div
                    className="mainMenu"
                    onClick={() => {
                      // setToggleMenu(prev => !prev)
                      router.push(`/games/${singleProductCategoryData?.slug}`);
                    }}
                  >
                    <LazyLoad once>
                      <Image
                        src={singleProductCategoryData?.image_url}
                        alt="Category Logo"
                        width={35}
                        height={35}
                      />
                    </LazyLoad>
                    <span className="title">
                      {singleProductCategoryData?.name}
                    </span>
                  </div>
                </div>
              </OverlayTrigger>
              <Nav className="me-auto flex-column">
                <NavDropdown show={toggleMenu}>
                  {singleProductCategoryData?.child_categories?.map(
                    (childData) => (
                      <NavDropdown.Item
                        key={childData?.slug}
                        className={
                          childData.slug === childCategoryId ? "active" : ""
                        }
                        onClick={() =>
                          router.push(
                            `/games/${singleProductCategoryData?.slug}/${childData.slug}`
                          )
                        }
                      >
                        <Image
                          width={35}
                          height={35}
                          src={
                            childData.meta_image_url
                              ? childData.meta_image_url
                              : childData.image_url
                              ? childData.image_url
                              : RightArrow
                          }
                          alt={childData?.name}
                        />
                        <span>{childData?.name}</span>
                      </NavDropdown.Item>
                    )
                  )}
                </NavDropdown>
              </Nav>
            </div>
            {/* Main Content */}
            <div id="pageContent" className="p-0 pageContent">
              <Container>
                {/* Page Title */}
                <div className="pageTitleBlock">
                  {singleProductCategoryData?.slug && (
                    <div className="titleBlock">
                      <Breadcrumb>
                        <Breadcrumb.Item onClick={() => router.push("/")}>
                          Home
                        </Breadcrumb.Item>
                        <Breadcrumb.Item
                          active={childCategoryId ? false : true}
                          onClick={() =>
                            router.push(
                              `/games/${singleProductCategoryData?.slug}`
                            )
                          }
                        >
                          {singleProductCategoryData?.name}
                        </Breadcrumb.Item>
                        {childCategoryId && categoryData?.name && (
                          <Breadcrumb.Item active>
                            {categoryData?.name}
                          </Breadcrumb.Item>
                        )}
                      </Breadcrumb>
                      <div className="pageTitle">{categoryData?.name}</div>
                    </div>
                  )}
                  <div className="d-lg-none categorySideBarBtn">
                    <CategorySideBar
                      singleProductCategoryData={singleProductCategoryData}
                      categoryData={categoryData}
                    />
                  </div>
                </div>
                {/* Product List */}
                <div className="productList">
                  <Row>
                    {products?.length > 0 && !loading
                      ? products.map((product) => (
                          <Col
                            xs={12}
                            lg={6}
                            xl={4}
                            xxl={3}
                            key={`${product.id}_category`}
                            className="productItem"
                          >
                            <div
                              className="productCard"
                              // onClick={() => navigate(product.btnLink)}
                            >
                              <LazyLoad once>
                                <Image
                                  className="productImg"
                                  alt="product Images"
                                  src={product.image_url}
                                  width={222}
                                  height={280}
                                />
                              </LazyLoad>
                              <div className="productContent">
                                <div className="PTag">
                                  {product.has_hot_offer ? (
                                    <div className="productTag hot">
                                      <span>Hot Offer</span>
                                    </div>
                                  ) : (
                                    ""
                                  )}
                                  {product.discount_value ? (
                                    <div className="productTag sale">
                                      <span>{product.discount_value}</span>
                                    </div>
                                  ) : (
                                    ""
                                  )}
                                </div>
                                <div className="productTitle">
                                  {product.name}
                                </div>
                                <div
                                  className="productTagList"
                                  dangerouslySetInnerHTML={{
                                    __html: product.short_description,
                                  }}
                                ></div>
                                <div className="productFooter">
                                  <Button className="buttonStyle1 product_btn">
                                    <Link
                                      style={{
                                        textDecoration: "none",
                                        color: "#fff",
                                      }}
                                      href={`/games/${
                                        singleProductCategoryData.slug
                                      }/${
                                        (product?.categories?.find((cat) =>
                                          childCategoryId
                                            ? cat.parent_id != 0 &&
                                              cat.slug === childCategoryId
                                            : cat.parent_id != 0
                                        )).slug
                                      }/${product.slug}`}
                                    >
                                      Buy Now
                                    </Link>
                                  </Button>
                                  <div className="productPrice">
                                    <span>From</span> ${product.min_price}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Col>
                        ))
                      : !loading
                      ? ""
                      : ""}
                  </Row>
                  {loading ? (
                    <>
                      <div className="text-center my-5">
                        <Spinner animation="border" variant="light" />
                      </div>
                    </>
                  ) : (
                    <></>
                  )}
                  {singleProductCategoryData?.description && (
                    <p
                      className="white-color"
                      dangerouslySetInnerHTML={{
                        __html: singleProductCategoryData?.description,
                      }}
                    />
                  )}

                  {hasLoadMore && (
                    <Button
                      disabled={isActiveLoadMore}
                      onClick={() => handleLoadMore()}
                      className="loadMore"
                    >
                      Load More
                    </Button>
                  )}
                </div>
                <CustomOrderSection />
              </Container>
            </div>
          </div>
        </Container>
        <HowItWork />
      </div>
    </>
  );
};
export default ProductCategoryList;
