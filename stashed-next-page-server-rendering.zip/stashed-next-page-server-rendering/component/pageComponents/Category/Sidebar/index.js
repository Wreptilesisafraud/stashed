// Component
import React, { useState } from "react";
import { Nav, NavDropdown, Button, Offcanvas } from "react-bootstrap";
// import { useNavigate } from "react-router-dom";
import { useRouter } from "next/router";

const CategorySideBar = ({ singleProductCategoryData, categoryData }) => {
  // const navigate = useNavigate();
  const router = useRouter();
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => {
    setShow(true);
  };
  return (
    <>
      <Button className="buttonStyle1" variant="primary" onClick={handleShow}>
        Sidebar Menu
      </Button>
      <Offcanvas className="sidebar" show={show} onHide={handleClose}>
        <Offcanvas.Header closeButton></Offcanvas.Header>
        <Offcanvas.Body className="scrollDesign_y">
          <Nav className="me-auto gap-5 flex-column">
            <NavDropdown
              show
              title={
                <>
                  <img
                    src={singleProductCategoryData?.image_url}
                    alt="Category Logo"
                  />
                  <span className="title">
                    {singleProductCategoryData?.name}
                  </span>
                </>
              }
            >
              {singleProductCategoryData?.child_categories?.map((childData) => (
                <NavDropdown.Item
                  key={childData?.slug}
                  onClick={() =>
                    router.push(
                      `/games/${singleProductCategoryData?.slug}/${childData.slug}`
                    )
                  }
                  className="active"
                >
                  {childData?.name}
                </NavDropdown.Item>
              ))}
            </NavDropdown>
          </Nav>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
};
export default CategorySideBar;
