import { Row, Col, NavLink } from "react-bootstrap";

const CustomOrderCTA = () => {
  const handleIntercom = () => {
    window?.Intercom(
      "showNewMessage",
      "Hello, I would like to purchase a custom order"
    );
  };
  return (
    <section className="CustomOrderCTA">
      <Row>
        <Col xs={12} sm={7} className="leftPart">
          <div className="subTitle">Need Help?</div>
          <div className="title">Build your custom order</div>
        </Col>
        <Col xs={12} sm={5} className="rightPart">
          <NavLink
            className="buttonStyle1 ctaBtn"
            onClick={handleIntercom}
            href="#"
          >
            Request Custom Order
          </NavLink>
          {/* <div className="content">We usually replay in 2 to 4 hours</div> */}
        </Col>
      </Row>
    </section>
  );
};

export default CustomOrderCTA;
