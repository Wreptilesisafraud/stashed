import { Container, Row, Col } from "react-bootstrap";

// Image
import stepImage1 from "@/assets/images/step1_img1x.png";
import stepImage2 from "@/assets/images/step2_img1x.png";
import stepImage3 from "@/assets/images/step3_img1x.png";
import stepImage4 from "@/assets/images/step4_img1x.png";
import LazyLoad from "react-lazyload";
import Image from "next/image";

const HowItWork = () => (
  <section className="HowItWork">
    <Container>
      <div className="title">How it Works</div>
      <Row className="stepRow">
        <Col xs={12} sm={6} lg={3} className="stepCol step1">
          <div className="stepImage">
            <LazyLoad once>
              <Image
                src={stepImage1}
                alt="Step Images"
                width={180}
                height={96}
              />
            </LazyLoad>
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 1</div>
          </div>
          <div className="stepContent">
            Select Preferred options and place an order and we will contact you
            via our liver chat app or by sending and email.
          </div>
        </Col>
        <Col xs={12} sm={6} lg={3} className="stepCol step2">
          <div className="stepImage">
            <Image src={stepImage2} alt="Step Images" width={180} height={96} />
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 2</div>
          </div>
          <div className="stepContent">
            All the details will be discussed beforehand and the start time will
            be set according to your schedule in real life
          </div>
        </Col>
        <Col xs={12} sm={6} lg={3} className="stepCol step3">
          <div className="stepImage">
            <Image src={stepImage3} alt="Step Images" width={180} height={96} />
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 3</div>
          </div>
          <div className="stepContent">
            At the appointed time, our professional player will take your
            character and start the order
          </div>
        </Col>
        <Col xs={12} sm={6} lg={3} className="stepCol step4">
          <div className="stepImage">
            <Image src={stepImage4} alt="Step Images" width={180} height={96} />
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 4</div>
          </div>
          <div className="stepContent">
            We’ll notify you about the Classic leveling completion and enjoy the
            resoults!
          </div>
        </Col>
      </Row>
    </Container>
  </section>
);

export default HowItWork;
