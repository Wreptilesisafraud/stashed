import React from "react";

const PageNotFound = () => (
  <div className="pageNotFoundBlock">
    <h2>404</h2>
    <h6>Page Not Found</h6>
  </div>
);

export default PageNotFound;
