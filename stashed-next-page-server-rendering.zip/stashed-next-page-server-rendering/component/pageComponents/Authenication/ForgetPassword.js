import React, { useContext, useEffect } from "react";
import Button from "react-bootstrap/Button";
import { useFormik } from "formik";
import Form from "react-bootstrap/Form";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import {
  SignInGoogleService,
  ForgetPasswordService,
} from "@/redux/features/AuthsService";
import { toast } from "react-toastify";
import Cookies from "js-cookie";
import { AuthContext } from "@/contexts/AuthContexts";
import { addCartItem } from "@/redux/features/CartService";
// import axios from 'axios'
// import SocialSignIn from "./SocialSignIn";

const url = process.env.REACT_APP_API_URL;

const validate = (values) => {
  const errors = {};

  if (!values.email) {
    errors.email = "Please enter email address";
  } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = "Invalid email address";
  }
  return errors;
};

const getParameters = (queryParameters) => {
  const entries = queryParameters.entries();

  const data = {};
  for (const entry of entries) {
    data[entry[0]] = entry[1];
  }
  return data;
};

const ForgetPassword = () => {
  const { updateAuthStatus, authStatus } = useContext(AuthContext);
  const cartState = useSelector((state) => state.cart);
  const [queryParameters] = useSearchParams();

  // console.log(new URLSearchParams(getParameters(queryParameters)))
  const navigate = useNavigate();
  // Redirect to dashboard if user is already authenticated
  if (authStatus === 1) {
    navigate("/");
  }
  const dispatch = useDispatch();
  useEffect(() => {
    if (window.location.href.indexOf("social-login/google/callback") > 0) {
      dispatch(SignInGoogleService(getParameters(queryParameters))).then(
        (response) => {
          if (response.type === "auth/SignInGoogle/fulfilled") {
            const resData = response?.payload;
            if (resData?.data) {
              if (resData.data.user_type === "admin") {
                toast.error("Invalid Username or Password", {
                  autoClose: 3000,
                });
              } else if (
                resData.extra_meta.error ||
                !resData.extra_meta.token
              ) {
                toast.error(resData.extra_meta.message, { autoClose: 3000 });
              } else {
                Cookies.set("stashed_token", resData.extra_meta.token);
                if (cartState.preCartItem) {
                  dispatch(addCartItem(cartState.preCartItem));
                }
                updateAuthStatus(1);
                navigate("/");
              }
            } else {
              const msg =
                resData?.data?.user_type === "admin"
                  ? "Invalid Username or Password"
                  : resData.message;
              toast.error(msg, { autoClose: 3000 });
            }
          }
        }
      );
    }
  }, []);

  const formik = useFormik({
    initialValues: {
      email: "",
    },
    validate,
    onSubmit: async (values) => {
      const response = await dispatch(ForgetPasswordService(values));
      console.log("api res---", response);
      if (response.type === "auth/ForgetPassword/fulfilled") {
        const resData = response?.payload?.data;
        if (resData?.message) {
          toast.success(resData.message, { autoClose: 3000 });
        }
      } else if (response.type === "auth/ForgetPassword/rejected") {
        let resData = response?.payload?.response.data;
        console.log("test", response?.payload?.response.data);
        if (resData?.errors?.email) {
          toast.error(resData?.errors?.email[0], { autoClose: 3000 });
        }
      } else {
        toast.error("Something went wrong", { autoClose: 3000 });
      }
    },
  });
  return (
    <>
      <section className="formBlock signInOutPage">
        <div className="signInOutForm cForm forgetPassword">
          <div className="formTopContent">
            <div className="formTitle">Forget Password</div>
            <Form onSubmit={formik.handleSubmit}>
              <Form.Group className="formGroup" controlId="formBasicEmail">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="text"
                  name="email"
                  placeholder="Enter your Email"
                  onChange={formik.handleChange}
                  value={formik.values.email}
                />
                {formik.touched.email && formik.errors.email ? (
                  <div className="error">{formik.errors.email}</div>
                ) : null}
              </Form.Group>
              <Button
                variant="primary"
                type="submit"
                className="buttonStyle1 submitBtn"
              >
                Continue
              </Button>
            </Form>
          </div>
          {/* <SocialSignIn /> */}
        </div>
        <p className="switchOption">
          Don’t have account?{" "}
          <a href={() => false} onClick={() => navigate("/signup")}>
            Sign Up
          </a>
        </p>
      </section>
      <div className="AuthenicationBg"></div>
    </>
  );
};

export default ForgetPassword;
