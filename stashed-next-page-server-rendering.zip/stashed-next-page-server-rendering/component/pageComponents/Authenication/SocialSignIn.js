import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { SignInGoogleURLService } from "@/redux/features/AuthsService";
// import DiscordIcon from "../../assets/images/Discord.png";
// import FacebookIcon from "../../assets/images/Facebook.png";
import GoogleIcon from "@/assets/images/Google.png";
import { usePathname } from "next/navigation";
import Image from "next/image";

const SocialSignIn = () => {
  const dispatch = useDispatch();
  const pathname = usePathname();
  const type = pathname === "/signin" ? "Sign In" : "Sign Up";
  const selectorData = useSelector((state) => state.auths);
  const [googleParama, setGoogleParams] = useState(selectorData);

  useEffect(() => {
    if (!selectorData?.googleUrl) {
      dispatch(SignInGoogleURLService());
    }
  }, [selectorData]);

  return (
    <div className="formFooter">
      <div className="signupOptionList">
        {/* <a href={() => false} className="option">
					<img src={DiscordIcon} alt="Icon" />
					<div className="content">
						<p>{type}</p>
						<h4>Discord</h4>
					</div>
				</a> */}
        {/* <a href={() => false} className="option">
					<img src={FacebookIcon} alt="Icon" />
					<div className="content">
						<p>{type}</p>
						<h4>Facebook</h4>
					</div>
				</a> */}
        <a href={selectorData.googleUrl} className="option">
          <Image src={GoogleIcon} alt="Icon" width={21} height={21} />
          <div className="content">
            <p>{type}</p>
            <h4>Google</h4>
          </div>
        </a>
      </div>
    </div>
  );
};
export default SocialSignIn;
