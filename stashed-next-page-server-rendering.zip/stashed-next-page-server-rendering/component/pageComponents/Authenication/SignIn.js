import React, { useContext, useEffect } from "react";
import Button from "react-bootstrap/Button";
import { useFormik } from "formik";
import Form from "react-bootstrap/Form";
// import { useNavigate } from "react-router-dom";
import { useRouter, useSearchParams } from "next/navigation";
import { useSelector, useDispatch } from "react-redux";
// import { toast } from "react-toastify";
// Images
import {
  SignInService,
  SignInGoogleService,
} from "@/redux/features/AuthsService";
import { toast } from "react-toastify";
import Cookies from "js-cookie";
import { AuthContext } from "@/contexts/AuthContexts";
import { addCartItem } from "@/redux/features/CartService";
import axios from "axios";
import SocialSignIn from "./SocialSignIn";

const url = process.env.REACT_APP_API_URL;

const validate = (values) => {
  const errors = {};

  if (!values.email) {
    errors.email = "Please enter email address";
  } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = "Invalid email address";
  }

  if (!values.password) {
    errors.password = "Please enter password";
  }

  return errors;
};

const getParameters = (queryParameters) => {
  const entries = queryParameters.entries();

  const data = {};
  for (const entry of entries) {
    data[entry[0]] = entry[1];
  }
  return data;
};

const SignIn = () => {
  const { updateAuthStatus, authStatus } = useContext(AuthContext);
  const cartState = useSelector((state) => state.cart);
  const [queryParameters] = useSearchParams();
  // const navigate = useNavigate();
  const router = useRouter();

  const checkNavigate = () => {
    const pendingProductSlug = localStorage.getItem("pendingProductSlug");
    if (pendingProductSlug) {
      router.push(pendingProductSlug);
      localStorage.removeItem("pendingProductSlug");
    } else {
      router.push(`/`);
    }
  };

  if (authStatus === 1) {
    checkNavigate();
  }
  const dispatch = useDispatch();

  useEffect(() => {
    if (window.location.href.indexOf("social-login/google/callback") > 0) {
      dispatch(SignInGoogleService(getParameters(queryParameters))).then(
        (response) => {
          if (response.type === "auth/SignInGoogle/fulfilled") {
            const resData = response?.payload;
            if (resData?.data) {
              if (resData.data.user_type === "admin") {
                toast.error("Invalid Username or Password", {
                  autoClose: 3000,
                });
              } else if (
                resData.extra_meta.error ||
                !resData.extra_meta.token
              ) {
                toast.error(resData.extra_meta.message, { autoClose: 3000 });
              } else {
                Cookies.set("stashed_token", resData.extra_meta.token);
                if (cartState.preCartItem) {
                  dispatch(addCartItem(cartState.preCartItem));
                }
                updateAuthStatus(1);
                window.Intercom("update", {
                  api_base: "https://api-iam.intercom.io",
                  app_id: "a3rlm6s1",
                  name: resData.data.name, // Full name
                  email: resData.data.email, // Email address
                  user_id: resData.data.id, // current_user_id
                  created_at: Date.now(),
                });
                checkNavigate();
              }
            } else {
              const msg =
                resData?.data?.user_type === "admin"
                  ? "Invalid Username or Password"
                  : resData.message;
              toast.error(msg, { autoClose: 3000 });
            }
          }
        }
      );
    }
  }, []);

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validate,
    onSubmit: async (values) => {
      const response = await dispatch(SignInService(values));
      if (response.type === "auth/SignIn/fulfilled") {
        const resData = response?.payload?.data;
        if (resData?.data) {
          if (resData.data.user_type === "admin") {
            toast.error("Invalid Username or Password", { autoClose: 3000 });
          } else if (resData.extra_meta.error || !resData.extra_meta.token) {
            toast.error(resData.extra_meta.message, { autoClose: 3000 });
          } else {
            Cookies.set("stashed_token", resData.extra_meta.token);
            if (cartState.preCartItem) {
              dispatch(addCartItem(cartState.preCartItem));
            }
            console.log("resData", resData);
            updateAuthStatus(1);
            window.Intercom("update", {
              api_base: "https://api-iam.intercom.io",
              app_id: "a3rlm6s1",
              name: resData.data.name, // Full name
              email: resData.data.email, // Email address
              user_id: resData.data.id, // current_user_id
              created_at: Date.now(),
            });
            updateAuthStatus(1);
            checkNavigate();
          }
        } else {
          const msg =
            resData?.data?.user_type === "admin"
              ? "Invalid Username or Password"
              : resData.message;
          toast.error(msg, { autoClose: 3000 });
        }
      }
    },
  });
  return (
    <>
      <section className="formBlock signInOutPage">
        <div className="signInOutForm cForm">
          <div className="formTopContent">
            <div className="formTitle">Sign In</div>
            <Form onSubmit={formik.handleSubmit}>
              <Form.Group className="formGroup" controlId="formBasicEmail">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="text"
                  name="email"
                  placeholder="Enter your Email"
                  onChange={formik.handleChange}
                  value={formik.values.email}
                />
                {formik.touched.email && formik.errors.email ? (
                  <div className="error">{formik.errors.email}</div>
                ) : null}
              </Form.Group>

              <Form.Group className="formGroup" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Enter your password"
                  name="password"
                  onChange={formik.handleChange}
                  value={formik.values.password}
                />
                {formik.touched.password && formik.errors.password ? (
                  <div className="error">{formik.errors.password}</div>
                ) : null}
              </Form.Group>
              <div className="d-flex justify-content-between white-anchor">
                <Button
                  variant="primary"
                  type="submit"
                  className="buttonStyle1 submitBtn"
                >
                  Sign In
                </Button>
                <a href="#" onClick={() => router.push("/forget-password")}>
                  Forget Password
                </a>
              </div>
            </Form>
          </div>
          <SocialSignIn />
        </div>
        <p className="switchOption">
          Don’t have account?{" "}
          <a onClick={() => router.push("/signup")}>Sign Up</a>
        </p>
      </section>
      <div className="AuthenicationBg"></div>
    </>
  );
};

export default SignIn;
