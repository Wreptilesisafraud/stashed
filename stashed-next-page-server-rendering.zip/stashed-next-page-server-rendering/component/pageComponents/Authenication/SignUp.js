import React, { useContext, useState } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import { useFormik } from "formik";
import EyeIcon from "@/assets/images/eyeIcon.svg";
import EyeHIdeIcon from "@/assets/images/eyeHideIcon.svg";

import { useDispatch } from "react-redux";
import { SignUpService } from "@/redux/features/AuthsService";
import { toast } from "react-toastify";
import { AuthContext } from "@/contexts/AuthContexts";
import SocialSignIn from "./SocialSignIn";
import { useRouter } from "next/router";
import Image from "next/image";

const validate = (values) => {
  const errors = {};

  if (!values.name) {
    errors.name = "Please enter your User Name";
  }

  if (!values.email) {
    errors.email = "Please enter your email address";
  } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = "Invalid email address";
  }
  const passwordRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  if (!values.password) {
    errors.password = "Please enter your password";
  } else if (!passwordRegex.test(values.password)) {
    errors.password =
      "Password must greater than 8 characters, contain at least one number, have a mixture of uppercase, lowercase and one special character.";
  }
  if (values.password !== values.confirmPassword) {
    errors.confirmPassword = "Passwords do not match";
  }

  return errors;
};

const SignUp = () => {
  const { authStatus } = useContext(AuthContext);
  const dispatch = useDispatch();
  // const navigate = useNavigate();
  const router = useRouter();
  const [isEyesIcon, setEyesIcon] = useState(false);
  const [isEyesIconConfirm, setEyesIconConfirm] = useState(false);
  // Redirect to dashboard if user is already authenticated
  if (authStatus === 1) {
    router.push("/");
  }
  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
    validate,
    onSubmit: async (values) => {
      const response = await dispatch(SignUpService(values));
      if (response.type === "auth/SignUp/fulfilled") {
        const resData = response?.payload?.data?.extra_meta;
        if (resData?.error) {
          toast.error(resData.message, { autoClose: 3000 });
        } else {
          toast.success(resData.message, { autoClose: 2000 });
          router.push("/signin");
        }
      }
    },
  });

  const handlePasswordPassEyes = () => {
    setEyesIcon(!isEyesIcon);
  };

  const handleConfirmPassEyes = () => {
    setEyesIconConfirm(!isEyesIconConfirm);
  };

  return (
    <>
      <section className="formBlock signInOutPage customSignup">
        <div className="signInOutForm cForm">
          <div className="formTopContent">
            <div className="formTitle">Sign Up</div>
            <Form onSubmit={formik.handleSubmit}>
              <Form.Group
                className={`${
                  formik.errors.email ? "error_main" : ""
                } formGroup`}
                controlId="formBasicEmail"
              >
                <Form.Label>Username</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  placeholder="Enter your name"
                  onChange={formik.handleChange}
                  value={formik.values.name}
                />
                {formik.touched.name && formik.errors.name ? (
                  <div className="error">{formik.errors.name}</div>
                ) : null}
              </Form.Group>

              <Form.Group
                className={`${
                  formik.errors.email ? "error_main" : ""
                } formGroup`}
                controlId="formBasicEmail"
              >
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="email"
                  name="email"
                  placeholder="Enter your Email"
                  onChange={formik.handleChange}
                  value={formik.values.email}
                />
                {formik.touched.email && formik.errors.email ? (
                  <div className="error">{formik.errors.email}</div>
                ) : null}
              </Form.Group>

              <Form.Group
                className={`${
                  formik.errors.password ? "error_main " : ""
                } formGroup`}
                controlId="formBasicPassword"
              >
                <Form.Label>Password</Form.Label>
                <div className="field">
                  <Form.Control
                    type={!isEyesIcon ? "password" : "text"}
                    placeholder="Enter your password"
                    name="password"
                    onChange={formik.handleChange}
                    value={formik.values.password}
                    tocomplete="confirmPassword"
                  />
                  {isEyesIcon ? (
                    <>
                      <Image
                        className="eyeIcon show"
                        src={EyeIcon}
                        alt="eye"
                        onClick={handlePasswordPassEyes}
                        width={20}
                        height={20}
                      />
                    </>
                  ) : (
                    <>
                      <Image
                        className="eyeIcon hide"
                        src={EyeHIdeIcon}
                        alt="eye"
                        onClick={handlePasswordPassEyes}
                        width={20}
                        height={20}
                      />
                    </>
                  )}
                </div>
                {formik.errors.password ? (
                  <div className="error">{formik.errors.password}</div>
                ) : null}
              </Form.Group>

              <Form.Group
                className={`${
                  formik.errors.password ? "error_main " : ""
                } formGroup`}
                controlId="formBasicConfirmPassword"
              >
                <Form.Label>Confirm Password</Form.Label>
                <div className="field">
                  <Form.Control
                    type={!isEyesIconConfirm ? "password" : "text"}
                    placeholder="Enter your password"
                    name="confirmPassword"
                    onChange={formik.handleChange}
                    value={formik.values.confirmPassword}
                  />
                  {isEyesIconConfirm ? (
                    <>
                      <Image
                        className="eyeIcon show"
                        src={EyeIcon}
                        alt="eye"
                        onClick={handleConfirmPassEyes}
                        width={20}
                        height={20}
                      />
                    </>
                  ) : (
                    <>
                      <Image
                        className="eyeIcon hide"
                        src={EyeHIdeIcon}
                        alt="eye"
                        onClick={handleConfirmPassEyes}
                        width={20}
                        height={20}
                      />
                    </>
                  )}
                </div>
                {formik.errors.confirmPassword ? (
                  <div className="error">{formik.errors.confirmPassword}</div>
                ) : null}
              </Form.Group>

              <Form.Group className="formGroup">
                <Form.Check
                  type="checkbox"
                  id="check1"
                  label={
                    <span className="small">
                      I accept stashed.gg{" "}
                      <a
                        href="#"
                        onClick={() => router.push("/page/terms-of-service")}
                      >
                        terms & conditions
                      </a>
                    </span>
                  }
                />
                <Form.Check
                  type="checkbox"
                  id="check2"
                  label={
                    <span className="small">
                      Subscribe to our promo newsletter
                    </span>
                  }
                />
              </Form.Group>

              <Button
                variant="primary"
                type="submit"
                className="buttonStyle1 submitBtn"
              >
                Sign Up
              </Button>
            </Form>
          </div>
          <SocialSignIn />
        </div>
        <p className="switchOption">
          Already have an account?{" "}
          <a href="#" onClick={() => router.push("/signin")}>
            Sign In
          </a>
        </p>
      </section>
      <div className="AuthenicationBg"></div>
    </>
  );
};

export default SignUp;
