import React, { useState } from "react";
import { Button } from "react-bootstrap";
import Link from "next/link"; // Import Next.js Link component
// Images
import CookieImg from "@/assets/images/Cookie.svg";
import Close_icon from "@/assets/images/Close_icon.webp";
import Cookies from "js-cookie";
import Image from "next/image";

const CookieBar = () => {
  const [isShow, setShow] = useState(Cookies.get("stashed_accept"));

  const handleAcceptCookie = (e, id) => {
    e.preventDefault();
    if (id === 1) {
      Cookies.set("stashed_accept", true);
    } else {
      const expiryTime = 1;
      const options = { expires: expiryTime };
      Cookies.set("stashed_accept", true, options);
    }
    setShow(Cookies.get("stashed_accept"));
  };

  return (
    <>
      {!isShow && (
        <section className="CookieBlock">
          <Image
            src={CookieImg}
            alt="cookie Images"
            className="CookieImg"
            width={54}
            height={50}
          />
          <p className="CookieText">
            This website uses cookies to ensure you get the best experience on
            our website. To learn more, check out our{" "}
            <Link href="/home">
              <a>Privacy Policy</a>
            </Link>{" "}
            and{" "}
            <Link href="/home">
              <a>Cookies Policy</a>
            </Link>
            .
          </p>
          <Button
            className="CookieBTN buttonStyle1"
            onClick={(e) => handleAcceptCookie(e, 1)}
          >
            Accept
          </Button>
          <Button
            className="bg-transparent border-0 p-0"
            onClick={(e) => handleAcceptCookie(e, 0)}
          >
            <Image
              src={Close_icon}
              alt="Close Icon"
              className="CookieCloseBTN"
              width={24}
              height={24}
            />
          </Button>
        </section>
      )}
    </>
  );
};

export default CookieBar;
