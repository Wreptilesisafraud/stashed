import React, { useState, useRef, createRef } from "react";
// import { useNavigate, useParams } from "react-router-dom";
import { useRouter } from "next/navigation";
import { Breadcrumb, Col, Container, Row } from "react-bootstrap";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { SignleBlogListData } from "@/redux/features/BlogService";
import moment from "moment";
import LazyLoad from "react-lazyload";
import parse from "html-react-parser";

import _ from "lodash";
import slugify from "react-slugify";
import ScrollSpy from "react-ui-scrollspy";
import { Waypoint } from "react-waypoint";
import Image from "next/image";

const titleTag = "h3";

const SingleBlog = ({ blogData, params }) => {
  const slug = params.slug;
  const dispatch = useDispatch();
  // const navigate = useNavigate();
  const router = useRouter();
  // const { singleBlogDetail } = useSelector((state) => state.blogs);
  const singleBlogDetail = blogData.blog;
  // console.log(singleBlogDetail);
  const [subtitles, setSubtitles] = useState([]);
  const [parsedBlog, setParsedBlog] = useState(
    parse(singleBlogDetail?.description)
  );
  const [elementsRef, setElementRef] = useState([]);
  const [currentSubtitle, setCurrentSubtitle] = useState("");
  const [isStickySubtitle, setIsStickySubtitle] = useState(false);

  const subtitleNavigationRef = useRef();
  const parentContainerRef = useRef();
  const blogRef = useRef();
  const subtitleContainerRef = useRef();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    if (slug) {
      dispatch(SignleBlogListData({ slug }));
    }
  }, [dispatch, slug]);

  useEffect(() => {
    if (singleBlogDetail?.description) {
      const dom = renderBlog(singleBlogDetail?.description);
      setParsedBlog(dom);
    }
  }, [singleBlogDetail?.description]);

  const renderBlog = (description) => {
    const options = {
      replace: (node) => {
        if (
          node.type === "tag" &&
          (node.name === "h1" || node.name === "h2" || node.name === "h3")
        ) {
          if (node.children.length === 0) {
            return null;
          }

          let text = node.children[0].data;
          if (node.children.length && node.children[0]?.children?.length) {
            text = node.children[0].children[0].data;
          }

          setSubtitles((prev) => _.uniq([...prev, text]));
          const ref = createRef();
          let tag = "";
          if (node.name === "h1") {
            tag = (
              <h1
                className="blog-subtitle"
                id={slugify(text)}
                ref={(_ref) => {
                  ref.current = _ref;
                  setElementRef((prev) => [...prev, ref]);
                }}
              >
                {text}
              </h1>
            );
          } else if (node.name === "h2") {
            tag = (
              <h2
                className="blog-subtitle"
                id={slugify(text)}
                ref={(_ref) => {
                  ref.current = _ref;
                  setElementRef((prev) => [...prev, ref]);
                }}
              >
                {text}
              </h2>
            );
          } else if (node.name === "h3") {
            tag = (
              <h3
                className="blog-subtitle"
                id={slugify(text)}
                ref={(_ref) => {
                  ref.current = _ref;
                  setElementRef((prev) => [...prev, ref]);
                }}
              >
                {text}
              </h3>
            );
          }
          return (
            <Waypoint
              key={Math.random()}
              onEnter={() => setCurrentSubtitle(text)}
            >
              {tag}
            </Waypoint>
          );
        }
      },
    };
    return parse(description, options);
  };

  useEffect(() => {
    if (subtitleNavigationRef.current) {
      const onScroll = () => {
        // setScroll(window.pageYOffset > 10 ? "stickyHeader" : "");
        const y = blogRef.current.getBoundingClientRect().y;
        setIsStickySubtitle(y < 75);
      };
      // clean up code
      window.removeEventListener("scroll", onScroll);
      window.addEventListener("scroll", onScroll, { passive: true });
      return () => window.removeEventListener("scroll", onScroll);
    }
  }, [subtitleNavigationRef]);

  return (
    <ScrollSpy
      navContainerRef={subtitleNavigationRef}
      parentScrollContainerRef={parentContainerRef}
      activeClass="active"
      onUpdateCallback={(event) => console.log(event)}
    >
      <div className="blogDetailsPage" ref={parentContainerRef}>
        <Container>
          <div className="pageTitleBlock">
            <div className="titleBlock">
              <Breadcrumb>
                <Breadcrumb.Item onClick={() => router.push("/")}>
                  Home
                </Breadcrumb.Item>
                <Breadcrumb.Item active>
                  {singleBlogDetail?.blog_category?.name}
                </Breadcrumb.Item>
              </Breadcrumb>
              <div className="pageTitle">{singleBlogDetail?.title}</div>
              <div className="blogDate">
                {moment(singleBlogDetail?.created_at).format("DD.MM.YYYY")}
              </div>
            </div>
          </div>
          {singleBlogDetail?.banner_url && (
            <Image
              src={singleBlogDetail?.banner_url}
              alt="Blog"
              className="singalBlogImg"
              height={699}
              width={1116}
              priority
            />
          )}
          <Row className="blogdataBlock" ref={blogRef}>
            <Col xs={12} lg={9} className="blogContent overflow-hidden">
              {/* <h4>{singleBlogDetail?.title}</h4> */}
              {parsedBlog}
            </Col>
            <Col xs={12} lg={3} ref={subtitleContainerRef}>
              <div
                className={`blogSidebar ${
                  isStickySubtitle ? "sticky-side-bar" : ""
                }`}
                ref={subtitleNavigationRef}
                style={{
                  width:
                    subtitleContainerRef.current?.getBoundingClientRect()
                      ?.width ?? "auto",
                }}
              >
                <div
                  className={`blogCategory scrollDesign_y`}
                  style={{ maxHeight: "85vh", overflowY: "auto" }}
                >
                  {subtitles.map((subtitle, index) => (
                    <a
                      className={`categoryName ${
                        currentSubtitle == subtitle ? "active" : ""
                      }`}
                      key={slugify(subtitle)}
                      data-to-scrollspy-id={slugify(subtitle)}
                      onClick={() =>
                        elementsRef[index].current?.scrollIntoView({
                          behavior: "smooth",
                          block: "center",
                          inline: "nearest",
                        })
                      }
                    >
                      {subtitle}
                    </a>
                  ))}
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    </ScrollSpy>
  );
};

export default SingleBlog;
