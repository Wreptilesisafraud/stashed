import React, { useEffect, useState } from "react";
// import { Link } from "react-router-dom";
import Link from "next/link";

import BlogPageHeroBG from "@/assets/images/BlogPageHeroBG.png";
import SearchIcon from "@/assets/images/Search_Icon.svg";
import BlogArrow from "@/assets/images/BlogArrow.svg";
import dataEmptyImg from "@/assets/images/dataEmpty.webp";

import {
  Button,
  Col,
  Container,
  Form,
  Row,
  Spinner,
  Tabs,
  Tab,
} from "react-bootstrap";
// import { Tab } from "bootstrap";
import { useDispatch, useSelector } from "react-redux";
import {
  GetBlogListData,
  GetCategoryBlogListData,
} from "@/redux/features/BlogService";
import moment from "moment/moment";
import LazyLoad from "react-lazyload";
import slugify from "react-slugify";
import Image from "next/image";

const Blog = ({ categoryList }) => {
  const dispatch = useDispatch();
  const { blogsData, totalBlog, loading } = useSelector((state) => state.blogs);
  const categoriesBlogData = categoryList.categories;
  const [activeKey, setActiveKey] = useState(
    categoriesBlogData.length > 0 ? categoriesBlogData[0].id : null
  );
  const [isPerPage, setPerPage] = useState(6);
  const [isBlogData, setBlogData] = useState([]);
  const [isCategoryId, setCategoryId] = useState(0);
  const [isSearchBlog, setSearchBlog] = useState("");

  useEffect(() => {
    if (categoriesBlogData.length) {
      handleCategorySelect(categoriesBlogData[0].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoriesBlogData]);

  function handleEnterKey(event) {
    if (event.key === "Enter") {
      alert("hyyyyyy");
      // Handle the Enter key press
      console.log("Enter key was pressed");
    }
  }

  useEffect(() => {
    // Add the event listener
    document.addEventListener("keydown", handleEnterKey);

    // Remove the event listener
    document.removeEventListener("keydown", handleEnterKey);
  }, []);
  // Add the event listener
  // document?.addEventListener("keydown", handleEnterKey);

  // Remove the event listener
  // document?.removeEventListener("keydown", handleEnterKey);

  useEffect(() => {
    dispatch(GetCategoryBlogListData());
  }, [dispatch]);

  const handleCategorySelect = (categoryId) => {
    setActiveKey(categoryId);
    setCategoryId(categoryId);
    setPerPage(1);
    setBlogData([]);
    dispatch(GetBlogListData({ categoryId, perPage: 6, search: isSearchBlog }));
  };

  const handleLoadMore = () => {
    dispatch(
      GetBlogListData({
        categoryId: isCategoryId,
        perPage: isPerPage + 100,
        search: isSearchBlog,
      })
    );
  };

  useEffect(() => {
    setBlogData(blogsData);
  }, [blogsData]);

  const handleSearchBtn = () => {
    dispatch(
      GetBlogListData({
        categoryId: isCategoryId,
        perPage: isPerPage + 6,
        search: isSearchBlog,
      })
    );
  };

  return (
    <>
      <div className="blogPage">
        <div
          className="heroSection"
          style={{ backgroundImage: `url(${BlogPageHeroBG})` }}
        >
          <Container className="text-center">
            <h4 className="title">Welcome to our Blogs</h4>
            <p className="subText">
              Our boosters are the Top in the game with decades of gameplay
              experience, come and enioy the best servicesand enioy the best{" "}
            </p>
            <Form
              className="d-flex mx-auto searchForm"
              onSubmit={(e) => {
                e.preventDefault();
                handleSearchBtn();
              }}
            >
              <Form.Control
                type="search"
                placeholder="Search"
                aria-label="Search"
                value={isSearchBlog}
                onChange={(e) => setSearchBlog(e.target.value)}
              />
              <Button className="searchBTN" onClick={handleSearchBtn}>
                <Image
                  src={SearchIcon}
                  alt="Order Icon"
                  width={19}
                  height={19}
                />
              </Button>
            </Form>
          </Container>
        </div>
        <div className="blogList">
          {categoriesBlogData.length > 0 ? (
            <>
              <Container>
                <Tabs
                  activeKey={activeKey}
                  id="tabs"
                  className="position-relative scrollDesign_x"
                  fill
                  onSelect={handleCategorySelect}
                >
                  {categoriesBlogData.map((catergoryData) => (
                    <Tab
                      key={catergoryData.id}
                      eventKey={catergoryData.id}
                      title={
                        <div className="tabHeading">
                          {catergoryData.image_url ? (
                            <>
                              <LazyLoad once>
                                <Image
                                  src={catergoryData.image_url}
                                  alt="TabIcon"
                                  width={40}
                                  height={40}
                                />
                              </LazyLoad>
                            </>
                          ) : (
                            <></>
                          )}
                          <span className="categoryName">
                            {catergoryData.name}
                          </span>
                        </div>
                      }
                    >
                      <div className="tabContent">
                        <Container className="mt-5">
                          <Row className="justify-content-center blogCardList">
                            {isBlogData.length ? (
                              isBlogData.map((blog_data, itemIndex) => (
                                <Col
                                  xs={12}
                                  md={6}
                                  xl={4}
                                  key={itemIndex}
                                  className="cardItem mb-4"
                                >
                                  <div className="blogCard" key="">
                                    {blog_data.image_url ? (
                                      <>
                                        <LazyLoad once>
                                          <Image
                                            src={blog_data.image_url}
                                            alt="blog"
                                            className="blogImg"
                                            width={326}
                                            height={204}
                                          />
                                        </LazyLoad>
                                      </>
                                    ) : (
                                      <></>
                                    )}

                                    <div className="px-4 pt-4 pb-3">
                                      <Link
                                        href={`/blog/${slugify(
                                          blog_data.blog_category.name
                                        )}/${blog_data.slug}`}
                                      >
                                        <h6 className="blogTitle">
                                          {blog_data.title}
                                        </h6>
                                      </Link>
                                      <p className="blogText">
                                        {blog_data.short_description.length > 75
                                          ? `${blog_data.short_description.substring(
                                              0,
                                              75
                                            )}...`
                                          : blog_data.short_description}
                                      </p>
                                      <div className="blogDate d-flex justify-content-between">
                                        <span className="date">
                                          {moment(blog_data.created_at).format(
                                            "DD.MM.YYYY"
                                          )}
                                        </span>
                                        <Link
                                          href={`/blog/${slugify(
                                            blog_data.blog_category.name
                                          )}/${blog_data.slug}`}
                                        >
                                          <Image
                                            src={BlogArrow}
                                            alt="Blog Arrow"
                                          />
                                        </Link>
                                      </div>
                                    </div>
                                  </div>
                                </Col>
                              ))
                            ) : !loading ? (
                              <div className="dataNotFound text-center">
                                <Image
                                  src={dataEmptyImg}
                                  alt="Empty Img"
                                  className="DataEmptyImg"
                                  width={500}
                                />
                              </div>
                            ) : (
                              ""
                            )}
                          </Row>
                          {loading ? (
                            <>
                              <div className="text-center my-5">
                                <Spinner animation="border" variant="light" />
                              </div>
                            </>
                          ) : (
                            <></>
                          )}
                          {isBlogData.length < totalBlog && !loading ? (
                            <>
                              <a
                                className="buttonStyle1 loadMore"
                                onClick={() => handleLoadMore(isPerPage)}
                              >
                                Load More
                              </a>
                            </>
                          ) : (
                            <></>
                          )}
                        </Container>
                      </div>
                    </Tab>
                  ))}
                </Tabs>
              </Container>
            </>
          ) : (
            <p></p>
          )}
        </div>
      </div>
    </>
  );
};

export default Blog;
