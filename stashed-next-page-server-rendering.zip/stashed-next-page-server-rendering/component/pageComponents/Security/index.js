import React, { useState } from "react";
import { Form, Button, Col, Row } from "react-bootstrap";

// Images
import UserDashboard from "../UserDashboard";
import { useFormik } from "formik";
import EyeIcon from "@/assets/images/eyeIcon.svg";
import EyeHIdeIcon from "@/assets/images/eyeHideIcon.svg";

// Section
import UserDashboardSidebar from "../UserDashboard/Sidebar/index";
import { useDispatch } from "react-redux";
import { UpdateSecurityData } from "@/redux/features/UserService";
import { UserSessionsLogoutData } from "@/redux/features/UserService";
import { toast } from "react-toastify";
import Image from "next/image";

const validate = (values) => {
  const errors = {};
  if (!values.oldPassword) {
    errors.oldPassword = "Please enetr old password";
  }
  if (!values.newPassword) {
    errors.newPassword = "Please enter new password";
  }
  const passwordRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  if (!values.oldPassword) {
    errors.oldPassword = "Please enter your password";
  } else if (!passwordRegex.test(values.oldPassword)) {
    errors.oldPassword =
      "Password must contain at least one number, have a mixture of uppercase, lowercase and one special character.";
  }
  if (values.newPassword !== values.oldPassword) {
    errors.newPassword = "Passwords do not match";
  }
  return errors;
};

const Security = () => {
  const dispatch = useDispatch();
  const [isEyesIcon, setEyesIcon] = useState(false);
  const [isEyesIconNew, setEyesIconNew] = useState(false);

  const formik = useFormik({
    initialValues: {
      oldPassword: "",
      newPassword: "",
    },
    validate,
    onSubmit: async (values) => {
      const response = await dispatch(
        UpdateSecurityData({
          password: values.oldPassword,
          password_confirmation: values.newPassword,
        })
      );
      if (response.type === "users/UpdateSecurityData/fulfilled") {
        toast.success(response.payload.message, { autoClose: 3000 });
      } else {
        toast.error(response.payload.message, { autoClose: 3000 });
      }
    },
  });

  const handleLogoutUserSessions = async () => {
    const response = await dispatch(UserSessionsLogoutData({}));
    if (response.type === "users/UpdateSecurityData/fulfilled") {
      toast.success(response.payload.message, { autoClose: 2000 });
    } else {
      toast.error(response.payload.message, { autoClose: 2000 });
    }
  };
  const handleOldPassEyes = () => {
    setEyesIcon(!isEyesIcon);
  };

  const handleNewPassEyes = () => {
    setEyesIconNew(!isEyesIconNew);
  };

  return (
    <UserDashboard title="security" className="securityPage">
      <div className="pageTitleBlock">
        <div className="titleBlock">
          <div className="pageTitle">User Profile</div>
          <div className="d-lg-none categorySideBarBtn">
            <UserDashboardSidebar title="security" />
          </div>
        </div>
      </div>
      <div className="UserDashboard_body scrollDesign_y">
        <Row>
          <Col xs={12} sm={6} lg={5} className="changePassData">
            <div className="data">
              <h4>Change Password</h4>
              <Form onSubmit={formik.handleSubmit}>
                <Form.Group
                  className="formGroup"
                  controlId="formBasicOldPassword"
                >
                  <Form.Label>New Password</Form.Label>
                  <div className="field">
                    <Form.Control
                      type={!isEyesIcon ? "password" : "text"}
                      name="oldPassword"
                      placeholder="Enter new password"
                      onChange={formik.handleChange}
                      value={formik.values.oldPassword}
                      toComplete="newPassword"
                    />
                    {isEyesIcon ? (
                      <>
                        <Image
                          className="eyeIcon show"
                          src={EyeIcon}
                          alt="eye"
                          onClick={handleOldPassEyes}
                          width={20}
                          height={20}
                        />
                      </>
                    ) : (
                      <>
                        <Image
                          className="eyeIcon hide"
                          src={EyeHIdeIcon}
                          alt="eye"
                          onClick={handleOldPassEyes}
                          width={20}
                          height={20}
                        />
                      </>
                    )}
                  </div>
                  {formik.touched.oldPassword && formik.errors.oldPassword ? (
                    <div className="error">{formik.errors.oldPassword}</div>
                  ) : null}
                </Form.Group>

                <Form.Group
                  className="formGroup"
                  controlId="formBasicNewPassword"
                >
                  <Form.Label>Confirm New Password</Form.Label>
                  <div className="field">
                    <Form.Control
                      type={!isEyesIconNew ? "password" : "text"}
                      name="newPassword"
                      placeholder="Enter new password"
                      onChange={formik.handleChange}
                      value={formik.values.newPassword}
                    />
                    {isEyesIconNew ? (
                      <>
                        <Image
                          className="eyeIcon show"
                          src={EyeIcon}
                          alt="eye"
                          onClick={handleNewPassEyes}
                          width={20}
                          height={20}
                        />
                      </>
                    ) : (
                      <>
                        <Image
                          className="eyeIcon hide"
                          src={EyeHIdeIcon}
                          alt="eye"
                          onClick={handleNewPassEyes}
                          width={20}
                          height={20}
                        />
                      </>
                    )}
                  </div>
                  {formik.touched.newPassword && formik.errors.newPassword ? (
                    <div className="error">{formik.errors.newPassword}</div>
                  ) : null}
                </Form.Group>
                <Form.Group>
                  <Button type="submit" className="buttonStyle1">
                    Confirm
                  </Button>
                </Form.Group>
              </Form>
            </div>
          </Col>
          <Col xs={12} sm={6} lg={7} className="securityData">
            <div className="data">
              {/* <div className="dataItem">
                <h4>Security 2FA</h4>
                <p>Two factor Authentitaction</p>
                <Button type="submit" className="buttonStyle1">
                  Setup 2FA
                </Button>
              </div> */}
              {/* <hr /> */}
              <div className="dataItem">
                <h4>Logout from all sesions</h4>
                <p>This will log out your from all devices</p>
                <Button
                  type="submit"
                  onClick={handleLogoutUserSessions}
                  className="buttonStyle1"
                >
                  Logout
                </Button>
              </div>
            </div>
          </Col>
        </Row>
      </div>
    </UserDashboard>
  );
};

export default Security;
