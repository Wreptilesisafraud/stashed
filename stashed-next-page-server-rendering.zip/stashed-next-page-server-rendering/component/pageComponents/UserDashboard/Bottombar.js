import React from "react";
import { Card, OverlayTrigger, Popover } from "react-bootstrap";

const Bottombar = () => (
  <div>
    <OverlayTrigger
      trigger="click"
      key="bootom"
      placement="bottom"
      rootClose={true}
      overlay={
        <Popover id="popover-positioned-bottom">
          <Popover.Header>Shopping Cart</Popover.Header>
          <Popover.Body>
            <Card>
              <div>
                <p>World of worcorft Dragonflight</p>
                <p>$15.00</p>
              </div>
              <div>
                <p>Sold by: Bilzard Entertainment</p>
                <p>Delivery time: 20 Minutes</p>
              </div>
              <div className="d-flex justify-content-between">
                <p>Quantity: 10</p>
                <p>Remove</p>
              </div>
            </Card>
            <Card>
              <div>
                <p>World of worcorft Dragonflight</p>
                <p>$15.00</p>
              </div>
              <div>
                <p>Sold by: Bilzard Entertainment</p>
                <p>Delivery time: 20 Minutes</p>
              </div>
              <div className="d-flex justify-content-between">
                <p>Quantity: 10</p>
                <p>Remove</p>
              </div>
            </Card>
          </Popover.Body>
        </Popover>
      }
    ></OverlayTrigger>
  </div>
);

export default Bottombar;
