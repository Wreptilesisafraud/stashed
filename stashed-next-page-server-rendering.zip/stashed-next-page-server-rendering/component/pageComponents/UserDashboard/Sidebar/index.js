import React, { useState, useContext } from "react";
import {
  OverlayTrigger,
  Popover,
  Nav,
  NavDropdown,
  Button,
  Offcanvas,
} from "react-bootstrap";
import { Link } from "react-router-dom";

// Images
import menuItem1 from "@/assets/images/List_Icon.svg";
import menuItem2 from "@/assets/images/Wallet_Icon.svg";
import menuItem3 from "@/assets/images/Notifications_Icon.svg";
import menuItem4 from "@/assets/images/Messages_Icon.svg";
import menuItem5 from "@/assets/images/Transactions_Icon.svg";
import menuItem6 from "@/assets/images/Profile_Icon.svg";
import UserImage from "@/assets/images/dummyUser.webp";
import Cookies from "js-cookie";
import { AuthContext } from "@/contexts/AuthContexts";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";
import { LogoutService } from "@/redux/features/AuthsService";

const UserDashboardSidebar = ({ children, title, className }) => {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const { userData, loading } = useSelector((state) => state.users);
  const dispatch = useDispatch();

  const handleShow = () => {
    setShow(true);
  };

  const { updateAuthStatus } = useContext(AuthContext);
  const handleLogout = () => {
    Cookies.remove("stashed_token");
    dispatch(LogoutService());
    updateAuthStatus(0);
    window.location.href = "/signin";
  };
  return (
    <>
      <Button className="buttonStyle1" variant="primary" onClick={handleShow}>
        Sidebar Menu
      </Button>
      <Offcanvas className="sidebar" show={show} onHide={handleClose}>
        <Offcanvas.Header closeButton></Offcanvas.Header>
        <Offcanvas.Body className="scrollDesign_y">
          <Nav className="me-auto gap-5 flex-column">
            <div id="sidebar" className="UserSidebar scrollDesign_y">
              <div>
                <h3 className="sidebarTitle">Menu</h3>
                <Link
                  to="/order"
                  className={`${title === "order" ? "active" : ""} nav-link`}
                >
                  <div className="iconBlock">
                    <img src={menuItem1} alt="Order Icon" />
                  </div>
                  <span>Orders</span>
                </Link>
                <Link
                  to="/wallet"
                  className={`${title === "wallet" ? "active" : ""} nav-link`}
                >
                  <div className="iconBlock">
                    <img src={menuItem2} alt="Wallet Icon" />
                  </div>
                  <span>Wallet</span>
                </Link>
                <Link
                  to="/notifications"
                  className={`${
                    title === "notification" ? "active" : ""
                  } nav-link`}
                >
                  <div className="iconBlock">
                    <img src={menuItem3} alt="Notifications Icon" />
                  </div>
                  <span>Notifications</span>
                </Link>
                <Link
                  to="/#"
                  className={`${title === "message" ? "active" : ""} nav-link`}
                >
                  <div className="iconBlock">
                    <img src={menuItem4} alt="Messages Icon" />
                  </div>
                  <span>Messages</span>
                </Link>
                <Link
                  to="/transactions"
                  className={`${
                    title === "transaction" ? "active" : ""
                  } nav-link`}
                >
                  <div className="iconBlock">
                    <img src={menuItem5} alt="Transactions Icon" />
                  </div>
                  <span>Transactions</span>
                </Link>
                <Link
                  className={`${
                    title === "preferance" || title === "security"
                      ? "active"
                      : ""
                  } nav-link`}
                >
                  <Nav>
                    <NavDropdown
                      title={
                        <>
                          <div className="iconBlock">
                            <img src={menuItem6} alt="Profile Icon" />
                          </div>
                          <span>Profile</span>
                        </>
                      }
                      open={true}
                    >
                      <Link to="/preferance" className="dropdown-item">
                        Preferance
                      </Link>
                      <Link to="/security" className="dropdown-item">
                        Security
                      </Link>
                    </NavDropdown>
                  </Nav>
                </Link>
              </div>
              <div className="UserProfileData">
                <div className="d-flex align-items-center w-100 gap-2">
                  <OverlayTrigger
                    trigger="click"
                    key="top"
                    placement="top"
                    rootClose={true}
                    overlay={
                      <Popover
                        id="popover-positioned-bottom"
                        className="userDataModel"
                      >
                        <Popover.Header>
                          <div className="userData">
                            <div className="email">
                              <b>{userData?.email}</b>
                            </div>
                            <div className="JoinDate">
                              Registered{" "}
                              {moment(userData?.created_at).format(
                                "DD.MM.YYYY"
                              )}
                            </div>
                          </div>
                        </Popover.Header>
                        <Popover.Body>
                          <Link
                            to="/order"
                            className={`nav-link ${
                              title === "message" ? "active" : ""
                            }`}
                          >
                            <div className="iconBlock">
                              <img src={menuItem1} alt="Menu Icon" />
                            </div>
                            <span>My Order History</span>
                          </Link>
                          <Link
                            to="/messages"
                            className={`nav-link ${
                              title === "message" ? "active" : ""
                            }`}
                          >
                            <div className="iconBlock">
                              <img src={menuItem4} alt="Menu Icon" />
                            </div>
                            <span>Messages</span>
                          </Link>
                          <Link
                            to="/notification"
                            className={`nav-link ${
                              title === "message" ? "active" : ""
                            }`}
                          >
                            <div className="iconBlock">
                              <img src={menuItem3} alt="Menu Icon" />
                            </div>
                            <span>Notifications</span>
                          </Link>
                          <Link
                            to="/preferance"
                            className={`nav-link ${
                              title === "message" ? "active" : ""
                            }`}
                          >
                            <div className="iconBlock">
                              <img src={menuItem6} alt="Menu Icon" />
                            </div>
                            <span>Profile</span>
                          </Link>
                          <button
                            className="logoutBtn nav-link"
                            onClick={handleLogout}
                          >
                            Logout
                          </button>
                          {/* <Link
                            to="/#"
                            className={`nav-link text-center ${
                              title === "message" ? "active" : ""
                            }`}
                          >
                            Logout
                          </Link> */}
                        </Popover.Body>
                      </Popover>
                    }
                  >
                    <img
                      src={
                        userData?.avatar_url && !loading !== ""
                          ? userData?.avatar_url
                          : UserImage
                      }
                      alt="User"
                      className="userImage"
                      height={40}
                      width={40}
                    />
                  </OverlayTrigger>
                  <div className="userData">
                    <div className="email">{userData?.email}</div>
                    <div className="JoinDate">
                      Registered{" "}
                      {moment(userData?.created_at).format("DD.MM.YYYY")}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Nav>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
};

export default UserDashboardSidebar;
