import React, { useEffect } from "react";
import { Form, Button } from "react-bootstrap";
// import { useNavigate } from "react-router-dom";
import moment from "moment";

import UserDashboard from "../UserDashboard";
import UserDashboardSidebar from "../UserDashboard/Sidebar/index";
import { useDispatch, useSelector } from "react-redux";
import { GetOrderData } from "@/redux/features/OrderService";
import { useRouter } from "next/router";
import Table from "./table";

const Order = () => {
  // const navigate = useNavigate();
  const router = useRouter();
  const dispatch = useDispatch();
  const { orderListData } = useSelector((state) => state.orders);

  useEffect(() => {
    dispatch(GetOrderData());
  }, [dispatch]);

  const columns = [
    {
      dataField: "created_at",
      text: "Order Date",
      formatter: (text) => moment(text).format("DD.MM.YYYY, HH:mm"),
    },
    {
      dataField: "order_group_id",
      text: "Order ID",
    },
    {
      dataField: "order_items",
      text: "Product",
      formatter: (cell, row) => (
        <div>
          <span>{row.order_items.length}</span>
        </div>
      ),
    },
    {
      dataField: "payment_status",
      text: "Status",
      formatter: (cell) => (
        <span
          className={`text-capitalize ${
            cell === "completed" ? "balanceChangePrice" : "ChangePriceStatus"
          }`}
        >
          {cell}
        </span>
      ),
    },
    {
      dataField: "order_items",
      text: "Quantity",
      formatter: (order_items) => order_items[0].qty,
    },
    {
      dataField: "order_items",
      text: "Price",
      formatter: (order_items) => (
        <span className="amountCell">${order_items[0].total_price}</span>
      ),
    },
  ];

  return (
    <UserDashboard title="order" className="orderListPage">
      <div className="pageTitleBlock">
        <div className="titleBlock">
          <div className="pageTitle">My Orders</div>
          <div className="d-lg-none categorySideBarBtn">
            <UserDashboardSidebar title="order" />
          </div>
          <div className="d-flex flex-grow-1 gap-3 justify-content-end blockAction">
            <Form className="searchForm">
              <Form.Control
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
              <Button className="searchBTN">
                {/* <img src={SearchIcon} alt="Order Icon" /> */}
              </Button>
            </Form>
            <Button className="purchaseBTN" onClick={() => router.push("/")}>
              Purchase
            </Button>
          </div>
        </div>
      </div>
      <div className="UserDashboard_body productList scrollDesign_y orderProductList dataTable">
        {orderListData?.length > 0 ? (
          <Table data={orderListData} columns={columns} />
        ) : (
          ""
        )}
      </div>
    </UserDashboard>
  );
};

export default Order;
