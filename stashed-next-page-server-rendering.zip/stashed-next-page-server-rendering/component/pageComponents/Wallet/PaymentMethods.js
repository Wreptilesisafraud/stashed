import React, { useState } from "react";
import { Form } from "react-bootstrap";
// Images
import CardLogos from "@/assets/images/CardLogos.svg";
import ApplePay from "@/assets/images/applePay.svg";
import Gpay from "@/assets/images/gpay.png";
// import Gpay from "@/assets/images/Gpay.webp";
import cryptoLogos from "@/assets/images/cryptoLogos.svg";

const PaymentMethods = ({ onSelect, paymentMethod }) => {
  const [selectedOption, setSelectedOption] = useState("cardPayment");

  const handleOptionChange = (event) => {
    onSelect(event.target.value);
  };

  return (
    <Form className="paymentMethod">
      <Form.Check
        className="method"
        label={
          <>
            <div className="methodType">
              <div className="dataContent">
                <h4 className="title">Debit / Credit Card</h4>
                <h2 className="subTitle">+3% service charge</h2>
              </div>
            </div>
            <div className="methodImage">
              <img src={CardLogos} alt="Card Images" />
            </div>
          </>
        }
        name="paymentMethod"
        type="radio"
        id="cardPayment"
        value="cardPayment"
        onChange={handleOptionChange}
        checked={paymentMethod === "cardPayment"}
      />
      <Form.Check
        className="method"
        label={
          <>
            <div className="methodType">
              <div className="dataContent">
                <h4 className="title">Apple Pay</h4>
                <h2 className="subTitle">+3% service charge</h2>
              </div>
            </div>
            <div className="methodImage">
              <img src={ApplePay} alt="Apple Pay" />
            </div>
          </>
        }
        name="paymentMethod"
        type="radio"
        id="applePay"
        value="applePay"
        onChange={handleOptionChange}
        checked={paymentMethod === "applePay"}
      />
      <Form.Check
        className="method"
        label={
          <>
            <div className="methodType">
              <div className="dataContent">
                <h4 className="title">Google Pay</h4>
                <h2 className="subTitle">+3% service charge</h2>
              </div>
            </div>
            <div className="methodImage">
              <img src={Gpay} width={70} alt="G-Pay" />
            </div>
          </>
        }
        name="paymentMethod"
        type="radio"
        id="gPay"
        value="gPay"
        onChange={handleOptionChange}
        checked={paymentMethod === "gPay"}
      />
      <Form.Check
        className="method"
        label={
          <>
            <div className="methodType">
              <div className="dataContent">
                <h4 className="title">Crypto</h4>
                <h2 className="subTitle">+3% service charge</h2>
              </div>
            </div>
            <div className="methodImage">
              <img src={cryptoLogos} alt="Crypto Currency Images" />
            </div>
          </>
        }
        name="paymentMethod"
        type="radio"
        id="cryptoPay"
        value="cryptoPay"
        onChange={handleOptionChange}
        checked={paymentMethod === "cryptoPay"}
      />
    </Form>
  );
};

export default PaymentMethods;
