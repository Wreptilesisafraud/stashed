import { useFormik } from "formik";
import { useState } from "react";
import { Button, Form, Modal } from "react-bootstrap";
import { useDispatch } from "react-redux";
import PaymentMethods from "./PaymentMethods";
import { GetPaymentUrl } from "@/redux/features/WalletService";

const validate = (values) => {
  const errors = {};

  if (!values.amount) {
    errors.amount = "Please enter valid amount";
  } else if (values.amount <= 0) {
    errors.amount = "Please select a valid amount.";
  } else {
    const regex = /^\d+(\.\d{0,2})?$/;
    if (!regex.test(values.amount)) {
      errors.amount = "Amount can have up to two decimal places.";
    }
  }

  return errors;
};

function DepositAmountPopup() {
  const [show, setShow] = useState(false);
  const dispatch = useDispatch();
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const formikUserDetail = useFormik({
    initialValues: {
      amount: "",
    },
    validate,
    onSubmit: async (values) => {
      const response = await dispatch(GetPaymentUrl({ amount: values.amount }));
      window.location.href = response.payload.data.url;
    },
  });

  return (
    <>
      <Button className="purchaseBTN" onClick={handleShow}>
        Deposit
      </Button>

      <Modal className="deposit-money" show={show} onHide={handleClose}>
        <Form onSubmit={formikUserDetail.handleSubmit}>
          <Modal.Header closeButton>
            <Modal.Title>Deposit</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form.Group className="formGroup" controlId="formBasicEmail">
              <Form.Label>Amount</Form.Label>
              <Form.Control
                type="number"
                name="amount"
                placeholder="Enter amount to deposit"
                onChange={formikUserDetail.handleChange}
                value={formikUserDetail.values.amount}
              />
              {formikUserDetail.touched.amount &&
              formikUserDetail.errors.amount ? (
                <div className="error">{formikUserDetail.errors.amount}</div>
              ) : null}
            </Form.Group>
            <PaymentMethods
              onSelect={() => console.log("ll")}
              paymentMethod={"cardPayment"}
            />
          </Modal.Body>
          <Modal.Footer>
            <Button type="submit" className="purchaseBTN">
              Pay
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </>
  );
}
export default DepositAmountPopup;
