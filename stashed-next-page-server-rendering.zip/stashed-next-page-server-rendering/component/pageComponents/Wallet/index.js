import React, { useEffect, useState } from "react";
// import BootstrapTable from "react-bootstrap-table-next";
// import paginationFactory from "react-bootstrap-table2-paginator";
// import filterFactory from "react-bootstrap-table2-filter";
// import { Button, Form } from "react-bootstrap";
// import Modal from 'react-bootstrap/Modal';

// Images
import UserDashboard from "../UserDashboard";
// import dataEmptyImg from "../../assets/images/dataEmpty.webp";

// Section
import UserDashboardSidebar from "../UserDashboard/Sidebar/index";
import { useDispatch, useSelector } from "react-redux";
import {
  GetWalletData,
  StripeWalletUpdate,
} from "@/redux/features/WalletService";
import moment from "moment/moment";
import { useFormik } from "formik";
// import PaymentMethods from "./PaymentMethods";
import DepositAmountPopup from "./DepositAmountPopup";
// import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Table from "./table";
import { useRouter } from "next/router";

function PriceFormatter(cell) {
  return <span className="balanceChangePrice">${cell}</span>;
}
function Status(cell) {
  return (
    <span
      className={`${
        cell === "completed" ? "balanceChangePrice" : "ChangePriceStatus"
      }`}
    >
      {cell}
    </span>
  );
}

const Wallet = () => {
  // const location = useLocation();
  // const searchParams = new URLSearchParams(location.search);
  // const transactionStatus = searchParams.get("transaction");
  // const paymentStatus = searchParams.get("success");
  // const sessionId = searchParams.get("session_id");
  // const navigate = useNavigate();
  const router = useRouter();
  const { transaction, success, session_id } = router.query;
  const transactionStatus = transaction;
  const paymentStatus = success;
  const sessionId = session_id;
  const dispatch = useDispatch();
  const { walletListData } = useSelector((state) => state.wallets);
  const { userData } = useSelector((state) => state.users);

  useEffect(() => {
    if (transactionStatus && paymentStatus && sessionId) {
      dispatch(
        StripeWalletUpdate({
          transactionStatus,
          paymentStatus,
          sessionId,
        })
      ).then((response) => {
        console.log("response", response);
        if (response.type === "orders/WalletUpdate/fulfilled") {
          const resData = response?.payload;
          if (resData?.data) {
            if (resData?.data?.status) toast.success(resData.data?.message);
            else toast.error(resData.data?.message);
          }
        } else {
          toast.error(
            "Something went wrong. Please contact the administrator."
          );
        }
      });
      router.push("/wallet");
    }

    dispatch(GetWalletData());
  }, [dispatch]);

  const columns = [
    {
      dataField: "user",
      text: "User email",
      formatter: (user) => user.email,
    },
    // {
    //   dataField: "orderName",
    //   text: "Order Name",
    // },
    {
      dataField: "type",
      text: "Type",
    },
    {
      dataField: "for",
      text: "For",
    },
    {
      dataField: "created_at",
      text: "Date",
      formatter: (text) => moment(text).format("DD.MM.YYYY"),
    },
    {
      dataField: "amount",
      text: "Balance Change",
      formatter: PriceFormatter,
    },
    {
      dataField: "status",
      text: "Status",
      formatter: Status,
    },
  ];

  return (
    <UserDashboard title="wallet" className="walletPage">
      <div className="pageTitleBlock">
        <div className="titleBlock">
          <div className="pageTitle">Wallet</div>
          <div className="d-lg-none categorySideBarBtn">
            <UserDashboardSidebar title="wallet" />
          </div>
          <div className="d-flex flex-grow-1 gap-2 justify-content-between justify-content-lg-end blockAction">
            <span className="inMyWallet">
              ${userData?.user_balance ?? 0} USD
            </span>
            <DepositAmountPopup />
          </div>
        </div>
      </div>
      <div className="UserDashboard_body productList scrollDesign_y dataTable">
        {walletListData?.data?.data?.length > 0 ? (
          <div className="wallet">
            <Table
              data={walletListData?.data?.data} // Pass walletListData as data prop
              columns={columns} // Pass columns configuration as columns prop
              pagination={{ sizePerPage: 7 }} // Pass pagination options as pagination prop
              bordered={false} // Pass bordered prop if needed
            />
          </div>
        ) : (
          <></>
        )}
      </div>
    </UserDashboard>
  );
};

export default Wallet;
