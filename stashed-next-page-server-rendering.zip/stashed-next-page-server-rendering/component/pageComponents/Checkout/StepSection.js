import { Container, Row, Col } from "react-bootstrap";

// Image
import stepImage1 from "@/assets/images/OrderStepImg1.svg";
import stepImage2 from "@/assets/images/OrderStepImg2.svg";
import stepImage3 from "@/assets/images/OrderStepImg3.svg";
import stepImage4 from "@/assets/images/OrderStepImg4.svg";
import stepImage5 from "@/assets/images/OrderStepImg5.svg";
import Image from "next/image";

const StepSection = () => (
  <section className="StepSection">
    <Container>
      <div className="title">Step by Step</div>
      <Row className="stepRow">
        <Col xs={12} sm={6} lg={3} className="stepCol step1">
          <div className="stepImage">
            <Image src={stepImage1} alt="Step Images" width={90} height={90} />
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 1</div>
          </div>
          <div className="stepContent">Purchase is Completed</div>
        </Col>
        <Col xs={12} sm={6} lg={3} className="stepCol step2">
          <div className="stepImage">
            <Image src={stepImage2} alt="Step Images" width={90} height={90} />
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 2</div>
          </div>
          <div className="stepContent">
            In order to verify please open Live chat or intercom on the bottom
            right
          </div>
        </Col>
        <Col xs={12} sm={6} lg={3} className="stepCol step3">
          <div className="stepImage">
            <Image src={stepImage3} alt="Step Images" width={90} height={90} />
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 3</div>
          </div>
          <div className="stepContent">
            After our verification is complete you will need to enter the
            delivery details
          </div>
        </Col>
        <Col xs={12} sm={6} lg={3} className="stepCol step4">
          <div className="stepImage">
            <Image src={stepImage4} alt="Step Images" width={90} height={90} />
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 4</div>
          </div>
          <div className="stepContent">
            Any questions or concerns please contact our staff via chat
          </div>
        </Col>
        <Col xs={12} sm={6} lg={3} className="stepCol step5">
          <div className="stepImage">
            <Image src={stepImage5} alt="Step Images" width={90} height={90} />
          </div>
          <div className="stepTitle">
            <div className="Stitle">Step 5</div>
          </div>
          <div className="stepContent">Enjoy your order</div>
        </Col>
      </Row>
    </Container>
  </section>
);

export default StepSection;
