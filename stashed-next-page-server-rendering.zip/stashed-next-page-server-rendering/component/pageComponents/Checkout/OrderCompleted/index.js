import React, { useEffect, useState, useRef } from "react";
import { Container, Row, Col, Breadcrumb } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";
import { useQuery } from "@/utils/query";
import { completedPayment, clearCart } from "@/redux/features/CartService";
import { useRouter } from "next/router";
// Images
import OrderCompletedIcon from "@/assets/images/OrderCompleted.svg";
import OrderFailedIcon from "@/assets/images/OrderFailed.png";
import LeftRIghtArrow from "@/assets/images/LeftRIghtArrow.svg";
import StepSection from "../StepSection";
import Image from "next/image";
import { useSearchParams } from "next/navigation";

const OrderCompleted = () => {
  const router = useRouter();
  const { pathname } = router;
  // const params = useQuery();
  const searchParams = useSearchParams();
  const [eventData, setEventData] = useState(null);
  const { cartItems, totalPrice } = useSelector((state) => state.cart);
  const dispatch = useDispatch();
  const isSuccess = searchParams.get("success") == "true";
  const sessionId = searchParams.get("session_id");
  const orderId = searchParams.get("order");
  console.log(isSuccess, sessionId, orderId);
  const [loading, setLoading] = useState(false);
  const cartRef = useRef({ cartItems, totalPrice });

  useEffect(() => {
    if (!isSuccess || !sessionId || !orderId) {
      return;
    }
    dispatch(
      completedPayment({
        orderId: orderId,
        paymentSessionId: sessionId,
        isSuccess,
      })
    ).then((response) => {
      if (response.type === "cart/complate_order/fulfilled") {
        if (response?.payload?.order) {
          setEventData(response?.payload?.order);
        }
      }
    });
  }, [isSuccess, sessionId, orderId]);

  useEffect(() => {
    let orderCompleted = pathname === "/order-completed";
    if (orderCompleted && eventData && isSuccess) {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: "purchase", // The name of the conversion event
        transaction_id: eventData?.order?.id,
        value: eventData?.sub_total_amount.toFixed(2),
        tax: eventData?.total_tax_amount,
        shipping: eventData?.total_shipping_cost,
        currency: "USD",
        coupon: "",
        items: [
          // If someone purchases more than one item,
          // you can add those items to the items array
          {
            item_id: eventData.id,
            item_name: "",
            affiliation: "",
            coupon: eventData?.order?.applied_coupon_code,
            discount: eventData?.order?.coupon_discount_amount,
            index: eventData?.order?.id,
            item_brand: "",
            item_list_name: "",
            item_variant: "",
            location_id: eventData?.location_id,
            price: eventData?.sub_total_amount.toFixed(2),
            quantity: 1,
          },
        ],
      });
    }
  }, [eventData]);

  useEffect(() => {
    return () => {
      dispatch(clearCart());
    };
  }, []);

  return (
    <div className="OrderCompletedPage">
      <div className="TitleStepBlock">
        <Container>
          <div className="titleBlock">
            <Breadcrumb>
              <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
              <Breadcrumb.Item href="#">
                World Of Warcraft Wrath of The Lich King
              </Breadcrumb.Item>
              <Breadcrumb.Item active>Creative</Breadcrumb.Item>
            </Breadcrumb>
            <div className="pageTitle">Checkout</div>
            <div className="orderData">
              <div className="orderId">
                <span>Order ID: </span>
                {orderId}
              </div>
              <div className="orderDate">
                {/* <span>Created </span>Aug 24 12:25 */}
              </div>
            </div>
          </div>
          {pathname === "/order-completed" ? (
            <div className="orderCompleted">
              <Image
                src={OrderCompletedIcon}
                alt="Order Completed"
                width={40}
                height={40}
              />
              <h2>Order Completed</h2>
            </div>
          ) : (
            <div className="orderCompleted">
              <Image
                src={OrderFailedIcon}
                width={40}
                height={40}
                alt="Order Failed"
              />
              <h2>Order Failed</h2>
            </div>
          )}
        </Container>
      </div>
      <div className="checkoutBlock">
        <Container>
          <Row>
            <Col xs={12} md={6} className="leftPart">
              <div className="finalOrderData">
                <div className="finalOrderSummary">
                  <h3 className="mainTitle">Order Summary</h3>
                  {cartItems.map((item, index) => (
                    <div key={index} className="data">
                      <div className="dataImages">
                        <Image
                          src={item.product.image_url}
                          alt="Quantity"
                          width={30}
                          height={30}
                        />
                      </div>
                      <div className="dataContent">
                        <h4 className="title">{item.product.name}</h4>
                        <h2 className="dataValue">
                          ${item.subtotal.toFixed(2)}
                        </h2>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="orderSummary">
                  <h2 className="summaryTitle">Payment</h2>
                  <div className="summaryItems">
                    <p className="itemName">Order Price</p>
                    <h3 className="itemValue">${totalPrice.toFixed(2)}</h3>
                  </div>
                  <div className="summaryItems">
                    <p className="itemName">Comission</p>
                    <h3 className="itemValue">$0.00</h3>
                  </div>
                  <div className="summaryItems">
                    <p className="itemName">Total Payment</p>
                    <h3 className="itemValue mainPrice">
                      ${totalPrice.toFixed(2)}
                    </h3>
                  </div>
                </div>
              </div>
            </Col>
            <Col xs={12} md={6} className="rightPart">
              <div className="chatBox">Chat</div>
              <div className="chatInfo">
                Our boosters are the Top in the game with decades of gameplay
                experience, come and enioy the best servicesand enioy the best
              </div>
            </Col>
          </Row>
        </Container>
      </div>
      <StepSection />
    </div>
  );
};

export default OrderCompleted;
