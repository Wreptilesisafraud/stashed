import React, { useState } from "react";
import { Button } from "react-bootstrap";
import { useSelector } from "react-redux";
import ApplyPromoCheckout from "./ApplyPromoCheckout";

const CARD_OPTIONS = {
  iconStyle: "solid",
  style: {
    base: {
      iconColor: "#c4f0ff",
      color: "#fff",
      fontWeight: 500,
      fontFamily: "Roboto, Open Sans, Segoe UI, sans-serif",
      fontSize: "16px",
      fontSmoothing: "antialiased",
      ":-webkit-autofill": { color: "#fce883" },
      "::placeholder": { color: "#87bbfd" }
    },
    invalid: {
      iconColor: "#ffc7ee",
      color: "#ffc7ee"
    }
  }
}


const CheckoutSummary = ({ handleStep, step, handleStripeCheckout, paymentMethod }) => {
  const { cartItems, loading, totalPrice } = useSelector(state => state.cart);
  var sum = cartItems.reduce((accumulator, currentValue) => {
    return accumulator + currentValue.subtotal
  }, 0);

  const selectedPaymentMethod = () => {
    switch (paymentMethod) {
      case 'cardPayment': {
        return "Debit / Credit Card"
      }
      case 'applePay': {
        return "Apple Pay"
      }
      case 'gPay': {
        return 'Google Pay'
      }
      default: {
        return 'No Option Selected'
      }
    }
  }

  return (
    <div className="orderSummary">
      <form onSubmit={handleStripeCheckout}>
        <h2 className="summaryTitle">Summary</h2>
        <div className="summaryItems">
          <p className="itemName">Item(s):</p>
          <h3 className="itemValue">${sum.toFixed(2)}</h3>
        </div>
        <ApplyPromoCheckout cartItems={cartItems} />
        <div className="summaryItems">
          <p className="itemName">Total:</p>
          <h3 className="itemValue mainPrice">${totalPrice.toFixed(2)}</h3>
        </div>
        {step == 3 && (
          <div>
            <div className="paymentMethod">
              <h4 className="itemName">Payment Method</h4>
              <h3 className="itemValue">{selectedPaymentMethod()}</h3>
            </div>
            {/* <div className="cardForm">
              <CardElement options={CARD_OPTIONS} />
            </div> */}
          </div>
        )}
        {step === 3 ? (<div className="d-flex flex-direction-row ">
          <Button className="buttonStyle1 checkoutButton payWithCard" onClick={handleStripeCheckout} disabled={loading}>
            <div className="prefix">Pay With</div>
            <div className="">Payment Method</div>
          </Button>
          {/* <Button className="buttonStyle1 checkoutButton payWithWallet" onClick={handleStep}>
            <div className="prefix">Pay With</div>
            <div>Wallet</div>
          </Button> */}
        </div>) :
          (
            <Button className="buttonStyle1 checkoutButton nextButton" onClick={handleStep} htmlType="button">
              Next
            </Button>
          )
        }
      </form>
    </div>

  );
}

export default CheckoutSummary;
