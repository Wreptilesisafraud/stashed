import React, { useState, useEffect } from "react";
import { Container, Row, Col, Breadcrumb, Form } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";

// Images
import DividerImg from "@/assets/images/StepArrow.png";

import CheckoutStepOne from "./CheckoutStepOne";
import CheckoutStepTwo from "./CheckoutStepTwo";
import CheckoutStepThree from "./CheckoutStepThree";
import CheckoutSummary from "./CheckoutSummary";
// import { useNavigate } from "react-router-dom";
import { useRouter } from "next/router";
import { useFormik } from "formik";
import { toast } from "react-toastify";
import { checkoutStripe } from "@/redux/features/CartService";
import Image from "next/image";

const validate = (values) => {
  const errors = {};

  if (
    values.email &&
    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)
  ) {
    errors.email = "Invalid email address";
  }

  if (!values.gameName) {
    errors.gameName = "Please enter game name";
  }

  // if (!values.description) {
  //   errors.description = "Please enter description";
  // }

  return errors;
};

const CheckOut = () => {
  const [isStepNo, setStepNo] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState("cardPayment");
  // const navigate = useNavigate();
  const router = useRouter();
  const cart = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  useEffect(() => {
    if (!cart.loading && (cart.cartItems.length == 0 || cart.totalPrice == 0)) {
      router.push("/");
    } else {
      let isCheckoutPage = window.location.pathname === "/checkout";
      if (isCheckoutPage) {
        window.dataLayer?.push({
          event: "checkout",
          send_to: "checkout-converssion",
          value: cart.totalPrice.toFixed(2),
          currency: "USD",
          "total-items": cart.cartItems.length,
        });
      }
    }
  }, [cart]);

  const formik = useFormik({
    initialValues: {
      email: "",
    },
    validate,
    onSubmit: async (values) => {
      // handleCheckOut();
      setStepNo(isStepNo + 1);
    },
  });

  const stepData = [
    {
      id: 1,
      count: "Step 1",
      title: "Review Order",
    },
    {
      id: 2,
      count: "Step 2",
      title: "Review Order",
    },
    {
      id: 3,
      count: "Step 3",
      title: "Payment Method",
    },
    // {
    //   id: 4,
    //   count: "Step 4",
    //   title: "Payment Gateway",
    // },
  ];

  const handleStripeCheckOut = async (e) => {
    e.preventDefault();
    if (cart.totalPrice * 100 < 200) {
      toast.error("Total price must be greater than $2");
      return;
    }

    const products = cart.cartItems.map((item) => {
      return {
        name: item.product.name,
        image: item.product.image_url,
        price: item.subtotal.toFixed(2) * 100 * item.qty,
        qty: item.qty,
      };
    });
    const data = {
      amount: cart.totalPrice.toFixed(2) * 100,
      products: products,
      ...formik.values,
    };
    // Should add cart items to order.
    const response = await dispatch(checkoutStripe(data));
    if (response.payload.url) {
      // dispatch(clearCart())
      // toast.success("Success! You order has been placed successfully!");
      // handleStep && handleStep()
      window.location.href = response.payload.url;
    } else {
      toast.error("Oop! Something went wrong!");
    }
  };

  const handleStep = () => {
    if (isStepNo === 3) {
      router.push("/order-completed");
    } else if (isStepNo === 2) {
      formik.submitForm();
    } else {
      setStepNo(isStepNo + 1);
    }
  };

  return (
    <div className="CheckoutPage">
      <div className="TitleStepBlock">
        <Container>
          <div className="titleBlock">
            <Breadcrumb>
              <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
              <Breadcrumb.Item active>Checkout</Breadcrumb.Item>
            </Breadcrumb>
            <div className="pageTitle">Checkout</div>
          </div>
          <div className="stepBlock">
            {stepData.map((item, index) => {
              index = index + 1;
              return (
                <>
                  <div className={`${index === 1 ? "d-none" : ""} divider`}>
                    <Image
                      src={DividerImg}
                      alt="Divider Img"
                      width={30}
                      height={130}
                    />
                  </div>
                  <a
                    className={`${isStepNo === index ? "active" : ""} stepItem`}
                    // href={() => setStepNo(index)}
                    onClick={() => {
                      if (isStepNo > index) {
                        setStepNo(index);
                      }
                    }}
                  >
                    <div className="StepCount">{item.count}</div>
                    <div className="StepTitle">{item.title}</div>
                  </a>
                </>
              );
            })}
          </div>
        </Container>
      </div>
      <div className="checkoutBlock">
        <Container>
          <Row>
            <Form className="row" onSubmit={formik.handleSubmit}>
              <Col xs={12} lg={7} className="leftPart">
                {isStepNo === 1 ? (
                  <>
                    <CheckoutStepOne />
                  </>
                ) : isStepNo === 2 ? (
                  <>
                    <CheckoutStepTwo formik={formik} />
                  </>
                ) : (
                  isStepNo === 3 && (
                    <>
                      <CheckoutStepThree
                        onSelect={setPaymentMethod}
                        paymentMethod={paymentMethod}
                      />
                    </>
                  )
                )}
              </Col>
              {isStepNo !== 4 && (
                <>
                  <Col xs={12} lg={5} className="rightPart">
                    <CheckoutSummary
                      handleStep={handleStep}
                      step={isStepNo}
                      handleStripeCheckout={handleStripeCheckOut}
                      paymentMethod={paymentMethod}
                    />
                  </Col>
                </>
              )}
            </Form>
          </Row>
        </Container>
      </div>
    </div>
  );
};
export default CheckOut;
