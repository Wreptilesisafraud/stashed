import React from "react";
import { Col, Form } from "react-bootstrap";

const CheckoutStepTwo = ({ formik }) => (
  <div className="deliveryInformationCard mb-4 mb-lg-0">
    <h3 className="ProductName">Delivery Information</h3>
    <div className="row">
      <Col xs={12} md={6}>
        <Form.Group className="mb-2" controlId="gameName">
          <Form.Label>
            In Game Name <span>(Required)</span>
          </Form.Label>
          <Form.Control
            type="text"
            name="gameName"
            placeholder="Enter your in-Game name"
            onChange={formik.handleChange}
            value={formik.values.gameName}
          />
          {formik.errors.gameName ? (
            <div className="error">{formik.errors.gameName}</div>
          ) : null}
        </Form.Group>
      </Col>
      <Col xs={12} md={6}>
        <Form.Group className="mb-2" controlId="email">
          <Form.Label>
            Email <span>(Optional)</span>
          </Form.Label>
          <Form.Control
            type="email"
            name="email"
            placeholder="Enter your Email"
            onChange={formik.handleChange}
            value={formik.values.email}
          />
          {formik.errors.email ? (
            <div className="error">{formik.errors.email}</div>
          ) : null}
        </Form.Group>
      </Col>
      <Col xs={12}>
        <Form.Group controlId="formBasicPassword">
          <Form.Label>
            Delivery information <span>(Optional)</span>
          </Form.Label>
          <Form.Control
            as="textarea"
            name="description"
            placeholder="Anything you would like us to know or add?"
            style={{ height: "75px" }}
            onChange={formik.handleChange}
            value={formik.values.description}
          />

          {formik.errors.description ? (
            <div className="error">{formik.errors.description}</div>
          ) : null}
        </Form.Group>
      </Col>
    </div>
  </div>
);

export default CheckoutStepTwo;
