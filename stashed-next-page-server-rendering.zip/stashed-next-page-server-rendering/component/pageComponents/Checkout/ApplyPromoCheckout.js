import { useDispatch, useSelector } from "react-redux";
import { applyCouponCart } from "@/redux/features/CartService";
import { useState } from "react";
import { Button, Form, Spinner } from "react-bootstrap";
import { toast } from "react-toastify";

const ApplyPromoCheckout = ({ cartItems }) => {
  const [promoCode, setPromoCode] = useState("");
  const [promoActive, setPromoActive] = useState(false);
  const dispatch = useDispatch();
  const { loading } = useSelector((state) => state.cart);

  const handlePromocode = () => {
    if (promoCode?.length === 0) {
      toast.error("Please enter promocode");
      return false;
    }
    dispatch(applyCouponCart({ code: promoCode }));
  };
  return (
    <div className="summaryItems py-4">
      <p className="itemName">Apply Promo Code:</p>
      <h3 className="itemValue mainPrice d-flex">
        <Form.Control
          style={{ width: "110px" }}
          className="me-2"
          type="text"
          name="name"
          placeholder="Enter code"
          onChange={(e) => setPromoCode(e.target.value)}
        />
        <Button
          style={{ minWidth: "auto", width: "50px" }}
          variant="primary"
          type="button"
          className="buttonStyle1 submitBtn px-2"
          disabled={promoCode?.length === 0 || loading ? true : false}
          onClick={handlePromocode}
        >
          {!loading ? "Apply" : <Spinner size="sm" />}
        </Button>
      </h3>
    </div>
  );
};
export default ApplyPromoCheckout;
