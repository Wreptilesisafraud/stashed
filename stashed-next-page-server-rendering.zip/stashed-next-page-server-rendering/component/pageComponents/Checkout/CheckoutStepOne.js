import React from "react";
import { Button, Accordion } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";

// Images
import DustBin from "@/assets/images/DustBin.svg";
import ProductImgMini_1 from "@/assets/images/productImgMini_1.png";
import AccordionArrow from "@/assets/images/TopArrow.png";
import Check2Icon from "@/assets/images/Check2.svg";
import TimeIcon from "@/assets/images/Time.svg";
import DollarIcon from "@/assets/images/Dollar.svg";
import { removeCartItem } from "@/redux/features/CartService";
import Image from "next/image";

const CheckoutStepOne = () => {
  const cart = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  const handleClickRemove = (event, item) => {
    event.preventDefault();
    dispatch(removeCartItem(item.id));
  };

  return (
    <div className="orderProductList">
      {cart.cartItems.length > 0 && (
        <Accordion defaultActiveKey={cart.cartItems[0].product.productId}>
          {cart.cartItems.map((item) => (
            <Accordion.Item key={item.id} eventKey={item.id}>
              <Accordion.Header>
                <img
                  src={item.product.image_url}
                  alt="Product Preview Images"
                  className="ProductImage"
                />
                <h3 className="ProductName">{item.product.name}</h3>
                <div className="action">
                  <Button className="accordionArrow">
                    <Image
                      src={AccordionArrow}
                      alt="Arrow"
                      width={13}
                      height={8}
                    />
                  </Button>
                  <Button
                    className="deleteBtn"
                    onClick={(e) => handleClickRemove(e, item)}
                  >
                    <Image
                      src={DustBin}
                      alt="Product Preview Images"
                      width={10}
                      height={12}
                    />
                  </Button>
                </div>
              </Accordion.Header>
              <Accordion.Body>
                <div className="productData">
                  {item.variations.length > 0 && (
                    <div className="qty data">
                      <div className="dataImages">
                        <Image
                          src={Check2Icon}
                          alt="Quantity"
                          width={21}
                          height={21}
                        />
                      </div>
                      <div className="dataContent">
                        <h4 className="title">Product Variation</h4>
                        <ul>
                          {item.variations.map((variation, index) => (
                            <li key={index}>
                              <h4 className="dataValue">
                                {variation.variation.code}
                              </h4>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                  {item.product.hasLevelUp && (
                    <div className="qty data">
                      <div className="dataImages">
                        <Image
                          src={Check2Icon}
                          alt="Level Up"
                          width={21}
                          height={21}
                        />
                      </div>
                      <div className="dataContent">
                        <h4 className="title">Level Up</h4>
                        <h2 className="dataValue">Up to {item.level}</h2>
                      </div>
                    </div>
                  )}
                  {item.addons.length > 0 && (
                    <div className="qty data">
                      <div className="dataImages">
                        <Image
                          src={Check2Icon}
                          alt="Level Up"
                          width={21}
                          height={21}
                        />
                      </div>
                      <div className="dataContent">
                        <h4 className="title">Additional Options</h4>
                        <h2 className="dataValue">
                          {item.addons.length} Options
                        </h2>
                      </div>
                    </div>
                  )}
                  <div className="time data">
                    <div className="dataImages">
                      <Image
                        src={TimeIcon}
                        alt="Delivery Time"
                        width={21}
                        height={21}
                      />
                    </div>
                    <div className="dataContent">
                      <h4 className="title">Standard Delivery Time</h4>
                      <h2 className="dataValue">{item.product.unit.name}</h2>
                    </div>
                  </div>
                  <div className="qty data">
                    <div className="dataImages">
                      <Image
                        src={Check2Icon}
                        alt="Quantity"
                        width={21}
                        height={21}
                      />
                    </div>
                    <div className="dataContent">
                      <h4 className="title">Quantity</h4>
                      <h2 className="dataValue">{item.qty}</h2>
                    </div>
                  </div>
                  <div className="price data">
                    <div className="dataImages">
                      <Image
                        src={DollarIcon}
                        alt="Product Price"
                        width={21}
                        height={21}
                      />
                    </div>
                    <div className="dataContent">
                      <h4 className="title">Price</h4>
                      <h2 className="dataValue">${item.subtotal.toFixed(2)}</h2>
                    </div>
                  </div>
                </div>
              </Accordion.Body>
            </Accordion.Item>
          ))}
        </Accordion>
      )}
    </div>
  );
};

export default CheckoutStepOne;
