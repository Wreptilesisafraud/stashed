import Footer from "@/component/layout/Footer";
import SignUp from "@/component/pageComponents/Authenication/SignUp";
import React from "react";

const signup = () => {
  return (
    <>
      <SignUp />
      {/* <Footer /> */}
    </>
  );
};

export default signup;
