import CheckOut from "@/component/pageComponents/Checkout";
import React from "react";

const CheckoutPage = () => {
  return <CheckOut />;
};

export default CheckoutPage;
