import Transactions from "@/component/pageComponents/Transactions";
import React from "react";

const transactionsPage = () => {
  return <Transactions />;
};

export default transactionsPage;
