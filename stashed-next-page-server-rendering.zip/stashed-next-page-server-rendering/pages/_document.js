// import { Authprovider } from "@/contexts/AuthContexts";
import CookieBar from "@/component/pageComponents/CookieBar";
import { Html, Head, Main, NextScript } from "next/document";

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <title>Stashed | Boosting Services for WotLK & PoE</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta
          name="description"
          content="Enhance your gaming experience with Stashed.gg's safe and top-rated boosting services for World of Warcraft: Wrath of the Lich King (WotLK) and Path of Exile (PoE)."
        />{" "}
      </Head>
      <body className="App">
        <Main />
        <NextScript />
        {/* <CookieBar /> */}
      </body>
    </Html>
  );
}
