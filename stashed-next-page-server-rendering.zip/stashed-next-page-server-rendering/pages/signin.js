import Footer from "@/component/layout/Footer";
import SignIn from "@/component/pageComponents/Authenication/SignIn";
import React from "react";

const signin = () => {
  return (
    <>
      <SignIn />
      {/* <Footer /> */}
    </>
  );
};

export default signin;
