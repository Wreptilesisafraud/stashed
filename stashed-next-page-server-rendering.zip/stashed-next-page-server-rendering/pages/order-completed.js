import Footer from "@/component/layout/Footer";
import OrderCompleted from "@/component/pageComponents/Checkout/OrderCompleted";
import { getFooterData } from "@/utils/data/layout";
import React, { useEffect, useState } from "react";

const OrderFailedPage = () => {
  const [footerData, setFooterData] = useState({});
  useEffect(() => {
    async function data() {
      const footer = await getFooterData();
      return footer;
    }
    setFooterData(data());
  }, []);
  return (
    <>
      <OrderCompleted />
      <Footer res={footerData} />
    </>
  );
};

export default OrderFailedPage;
