import React from "react";
import Order from "@/component/pageComponents/Order";

const OrderPage = () => {
  return <Order />;
};

export default OrderPage;
