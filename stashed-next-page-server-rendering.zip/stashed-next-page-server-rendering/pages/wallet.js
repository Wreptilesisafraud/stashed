import React from "react";
import Wallet from "@/component/pageComponents/Wallet";

const WalletPage = () => {
  return <Wallet />;
};

export default WalletPage;
