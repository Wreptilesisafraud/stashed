import { Authprovider } from "@/contexts/AuthContexts";
import { store } from "@/redux/store";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-toastify/dist/ReactToastify.css";
import { Provider } from "react-redux";
import Header from "@/component/layout/Header";
import "@/styles/globals.scss";
import { ToastContainer } from "react-toastify";

export default function App({ Component, pageProps }) {
  return (
    <Provider store={store}>
      <Authprovider>
        <Header />
        <Component {...pageProps} />
      </Authprovider>
      <ToastContainer />
    </Provider>
  );
}
