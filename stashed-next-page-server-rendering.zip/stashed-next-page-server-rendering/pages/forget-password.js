import Footer from "@/component/layout/Footer";
// import ForgetPassword from "@/component/pageComponents/Authenication/ForgetPassword";
import React from "react";

const forgetPassword = () => {
  return (
    <>
      {/* <ForgetPassword /> */}
      {/* <Footer /> */}
    </>
  );
};

export default forgetPassword;
