import Notifications from "@/component/pageComponents/Notification";
import React from "react";

const NotificationsPage = () => {
  return <Notifications />;
};

export default NotificationsPage;
