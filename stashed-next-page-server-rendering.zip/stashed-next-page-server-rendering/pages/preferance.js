import Preferance from "@/component/pageComponents/ProfilePreferance";
import React from "react";

const preferancePage = () => {
  return <Preferance />;
};

export default preferancePage;
