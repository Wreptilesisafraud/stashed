import Head from "next/head";
import Image from "next/image";
import { Inter } from "next/font/google";
import Home from "@/component/pageComponents/Home/Home";
import { Provider } from "react-redux";
import { store } from "@/redux/store";
// import Header from "@/component/layout/Header";
import Footer from "@/component/layout/Footer";
import { getHomePageService } from "@/utils/data/homeData";
import { getFooterData } from "@/utils/data/layout";

// const inter = Inter({ subsets: ["latin"] });
// const url = process.env.API_URL;
export default function Homepage({ home, footer }) {
  return (
    <>
      <Provider store={store}>
        {/* <Header /> */}
        <Home res={home} />
        <Footer res={footer} />
      </Provider>
    </>
  );
}

export const getServerSideProps = async () => {
  const home = await getHomePageService();
  const footer = await getFooterData();
  return {
    props: { home, footer },
  };
};
