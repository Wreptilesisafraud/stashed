import Security from "@/component/pageComponents/Security";
import React from "react";

const securityPage = () => {
  return <Security />;
};

export default securityPage;
