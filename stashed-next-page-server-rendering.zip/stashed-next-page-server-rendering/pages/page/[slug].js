import { getSinglePageData } from "@/utils/data/pageData";
import React from "react";
import Page from "@/component/pageComponents/Page/index";
import { getFooterData } from "@/utils/data/layout";
import Footer from "@/component/layout/Footer";

const Pager = ({ res, footer }) => {
  return (
    <>
      <Page data={res} />
      <Footer res={footer} />
    </>
  );
};

export const getServerSideProps = async ({ params }) => {
  const slug = params.slug;
  const res = await getSinglePageData(slug);
  const footer = await getFooterData();
  return {
    props: { res, footer },
  };
};

export default Pager;
