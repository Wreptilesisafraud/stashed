import Footer from "@/component/layout/Footer";
import Blog from "@/component/pageComponents/Blog";
import {
  getBlogListData,
  getCategoryBlogListData,
} from "@/utils/data/blogData";
import { getFooterData } from "@/utils/data/layout";
import React from "react";

const blog = ({ res, footer }) => {
  // console.log(res);
  return (
    <>
      <Blog categoryList={res} />
      <Footer res={footer} />
    </>
  );
};

export const getServerSideProps = async () => {
  const res = await getCategoryBlogListData();
  const footer = await getFooterData();
  return {
    props: { res, footer },
  };
};

export default blog;
