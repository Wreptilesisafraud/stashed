import Footer from "@/component/layout/Footer";
import SingleBlog from "@/component/pageComponents/Blog/SingleBlog";
import React from "react";
import { useRouter } from "next/router";
import { getSingleBlogListData } from "@/utils/data/blogData";
import { getFooterData } from "@/utils/data/layout";

const BlogPost = ({ res, footer }) => {
  console.log(res);
  const router = useRouter();
  const params = { gameId: router.query.gameId, slug: router.query.slug };
  return (
    <>
      <SingleBlog blogData={res} params={params} />
      <Footer res={footer} />
    </>
  );
};

export const getServerSideProps = async ({ params }) => {
  const res = await getSingleBlogListData(params.slug);
  const footer = await getFooterData();
  return {
    props: { res, footer },
  };
};

export default BlogPost;
