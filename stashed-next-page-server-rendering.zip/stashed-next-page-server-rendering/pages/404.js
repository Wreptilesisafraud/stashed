import Footer from "@/component/layout/Footer";
import PageNotFound from "@/component/pageComponents/PageNotFound";
import React from "react";

const NotFound = ({ footer }) => {
  return (
    <>
      <PageNotFound />
    </>
  );
};

export default NotFound;
