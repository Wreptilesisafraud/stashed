import Footer from "@/component/layout/Footer";
import AboutUs from "@/component/pageComponents/AboutUs";
import { getAboutUsData } from "@/utils/data/aboutData";
import { getFooterData } from "@/utils/data/layout";
import React from "react";

const About = ({ res, footer }) => {
  return (
    <>
      <AboutUs data={res} />
      <Footer res={footer} />
    </>
  );
};

export const getServerSideProps = async () => {
  const res = await getAboutUsData();
  const footer = await getFooterData();
  return {
    props: { res, footer },
  };
};

export default About;
