import Footer from "@/component/layout/Footer";
// import CategoryList from "@/component/pageComponents/Category/CategoryList";
import React from "react";
// import { useRouter } from "next/router";
import ProductCategoryList from "@/component/pageComponents/Category/ProductCategoryList";
import { getFooterData } from "@/utils/data/layout";
import {
  getCategoryProductListData,
  getParentProductListData,
} from "@/utils/data/productServices";
// import { getSingleCategoryData } from "@/utils/data/categoryData";

const Category = ({
  categoryId,
  parentProductCategoryData,
  categoryProductListData,
  footer,
}) => {
  // console.log(parentProductCategoryData);
  const singleProductCategoryData =
    parentProductCategoryData.products.data.length > 0
      ? parentProductCategoryData.products.data[0].categories.length === 1
        ? parentProductCategoryData.products.data[0].categories[0]
        : parentProductCategoryData.products.data[0].categories.find(
            (categoryData) =>
              categoryData.slug === parentProductCategoryData.categoryIdMatch
          )
      : null;
  // console.log(singleProductCategoryData);
  return (
    <>
      <ProductCategoryList
        categoryId={categoryId}
        singleProductCategoryData={singleProductCategoryData}
        categoryProductListData={categoryProductListData}
      />
      <Footer res={footer} />
    </>
  );
};

export const getServerSideProps = async ({ params }) => {
  const categoryId = params.categoryId;
  const categoryProductListData = await getCategoryProductListData(
    categoryId,
    null,
    1,
    30
  );
  const parentProductCategoryData = await getParentProductListData(
    categoryId,
    null
  );
  // const singleCategoryData = await getSingleCategoryData();
  const footer = await getFooterData();
  return {
    props: {
      categoryId,
      categoryProductListData,
      parentProductCategoryData,
      footer,
    },
  };
};

export default Category;
