import Footer from "@/component/layout/Footer";
import ProductsList from "@/component/pageComponents/Product";
import ProductData from "@/component/pageComponents/Product/ProductData";
import React from "react";
import { useRouter } from "next/router";
import { getFooterData } from "@/utils/data/layout";
import {
  getParentProductListData,
  getSingleProductListData,
} from "@/utils/data/productServices";

const CategoryProduct = ({
  categoryId,
  childCategoryId,
  singleProductListData,
  parentProductCategoryData,
  productId,
  footer,
}) => {
  const singleProductCategoryData =
    parentProductCategoryData.products.data.length > 0
      ? parentProductCategoryData.products.data[0].categories.length === 1
        ? parentProductCategoryData.products.data[0].categories[0]
        : parentProductCategoryData.products.data[0].categories.find(
            (categoryData) =>
              categoryData.slug === parentProductCategoryData.categoryIdMatch
          )
      : null;
  const singleProductData = singleProductListData.products.data[0];
  return (
    <>
      <ProductsList
        categoryId={categoryId}
        childCategoryId={childCategoryId}
        productId={productId}
        singleProductCategoryData={singleProductCategoryData}
        singleProductData={singleProductData}
      />
      <Footer res={footer} />
    </>
  );
};

export const getServerSideProps = async ({ params }) => {
  const categoryId = params.categoryId;
  const childCategoryId = params.childCategoryId;
  const productId = params.productId;
  const parentProductCategoryData = await getParentProductListData(
    categoryId,
    childCategoryId
  );
  const singleProductListData = await getSingleProductListData(
    categoryId,
    childCategoryId,
    productId
  );
  const footer = await getFooterData();
  return {
    props: {
      categoryId,
      childCategoryId,
      singleProductListData,
      parentProductCategoryData,
      productId,
      footer,
    },
  };
};

export default CategoryProduct;
