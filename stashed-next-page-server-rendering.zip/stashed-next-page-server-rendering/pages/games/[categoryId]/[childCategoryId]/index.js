import Footer from "@/component/layout/Footer";
import CategoryList from "@/component/pageComponents/Category/CategoryList";
import React from "react";
// import { useRouter } from "next/router";
import { getFooterData } from "@/utils/data/layout";
import {
  getCategoryProductListData,
  getParentProductListData,
} from "@/utils/data/productServices";

const Category = ({
  categoryId,
  childCategoryId,
  categoryProductListData,
  parentProductCategoryData,
  footer,
}) => {
  const singleProductCategoryData =
    parentProductCategoryData.products.data.length > 0
      ? parentProductCategoryData.products.data[0].categories.length === 1
        ? parentProductCategoryData.products.data[0].categories[0]
        : parentProductCategoryData.products.data[0].categories.find(
            (categoryData) =>
              categoryData.slug === parentProductCategoryData.categoryIdMatch
          )
      : null;
  return (
    <>
      <CategoryList
        childCategoryId={childCategoryId}
        categoryId={categoryId}
        categoryProductListData={categoryProductListData}
        singleProductCategoryData={singleProductCategoryData}
      />
      <Footer res={footer} />
    </>
  );
};

export const getServerSideProps = async ({ params }) => {
  const categoryId = params.categoryId;
  const childCategoryId = params.childCategoryId;
  const categoryProductListData = await getCategoryProductListData(
    categoryId,
    childCategoryId,
    1,
    30
  );
  const parentProductCategoryData = await getParentProductListData(
    categoryId,
    childCategoryId
  );
  // const singleCategoryData = await getSingleCategoryData();
  const footer = await getFooterData();
  return {
    props: {
      categoryId,
      childCategoryId,
      categoryProductListData,
      parentProductCategoryData,
      footer,
    },
  };
};

export default Category;
