import axios from "axios";
import { getHeader } from "../axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const getCategoryBlogListData = async () => {
  try {
    const resp = await axios.get(`${url}/blog?category=true`, {
      headers: getHeader(),
    });
    return resp.data;
  } catch (err) {
    return err;
  }
};

export const getBlogListData = async (categoryId, perPage, search) => {
  try {
    const resp = await axios.get(
      `${url}/blog?category=true&category_id=${categoryId}&per_page=${perPage}&search=${search}`,
      {
        headers: getHeader(),
      }
    );
    return resp.data;
  } catch (err) {
    return rejectWithValue(err);
  }
};

export const getSingleBlogListData = async (slug) => {
  try {
    const resp = await axios.get(`${url}/blog/${slug}`, {
      headers: getHeader(),
    });
    return resp.data;
  } catch (err) {
    return err;
  }
};

// const BlogSlice = createSlice({
//   name: "blogs",
//   initialState: {
//     error: false,
//     loading: false,
//     categoriesBlogData: [],
//     blogsData: [],
//     singleBlogDetail: null,
//     totalBlog: 0,
//   },
//   reducers: {
//     setBlogPage: (state, action) => {
//       state.currentPage = action.payload;
//     },
//   },
//   extraReducers: {
//     [GetCategoryBlogListData.pending]: (state) => {
//       state.loading = true;
//     },
//     [GetCategoryBlogListData.fulfilled]: (state, action) => {
//       state.loading = false;
//       state.categoriesBlogData = action.payload.categories;
//     },
//     [GetCategoryBlogListData.rejected]: (state) => {
//       state.loading = false;
//     },
//     [GetBlogListData.pending]: (state) => {
//       state.loading = true;
//     },
//     [GetBlogListData.fulfilled]: (state, action) => {
//       state.loading = false;
//       state.totalBlog = action.payload.blogs.total;
//       state.blogsData = action.payload.blogs.data;
//     },
//     [GetBlogListData.rejected]: (state) => {
//       state.loading = false;
//     },
//     [SignleBlogListData.pending]: (state) => {
//       state.loading = true;
//     },
//     [SignleBlogListData.fulfilled]: (state, action) => {
//       state.loading = false;
//       state.singleBlogDetail = action.payload.blog;
//     },
//     [SignleBlogListData.rejected]: (state) => {
//       state.loading = false;
//     },
//   },
// });
