import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const getHomePageService = async () => {
  try {
    const resp = await axios.get(`${url}/home`, {
      headers: getHeader(),
    });
    return resp.data;
  } catch (err) {
    return err;
  }
};
