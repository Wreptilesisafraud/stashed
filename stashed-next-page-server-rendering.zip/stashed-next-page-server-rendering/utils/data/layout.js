// import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { getHeader } from "../axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const getFooterData = async () => {
  try {
    const resp = await axios.get(`${url}/footer`, {
      headers: getHeader(),
    });
    return resp.data;
  } catch (err) {
    return rejectWithValue(err);
  }
};

// const FooterSlice = createSlice({
//   name: "footers",
//   initialState: {
//     error: false,
//     loading: false,
//     footerData: [],
//   },
//   reducers: {
//     setFooterPage: (state, action) => {
//       state.currentPage = action.payload;
//     },
//   },
//   extraReducers: {
//     [GetFooterData.pending]: (state) => {
//       state.loading = true;
//     },
//     [GetFooterData.fulfilled]: (state, action) => {
//       state.loading = false;
//       state.footerData = action.payload;
//     },
//     [GetFooterData.rejected]: (state) => {
//       state.loading = false;
//     },
//   },
// });
