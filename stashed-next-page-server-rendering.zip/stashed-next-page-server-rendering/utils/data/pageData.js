import axios from "axios";
import { getHeader } from "../axiosHeader";

let url = process.env.NEXT_PUBLIC_API_URL;

export const getSinglePageData = async (slug) => {
  try {
    const resp = await axios.get(`${url}/pages/${slug}`, {
      headers: getHeader(),
    });
    return resp.data;
  } catch (err) {
    return err;
  }
};
