import { useState, useEffect } from "react";

export function useDeviceWidth() {
  const isClient = typeof window === "object"; // Check if window is defined

  const [windowWidth, setWindowWidth] = useState(
    isClient ? window.innerWidth : undefined
  );

  useEffect(() => {
    if (!isClient) return; // Exit early if running on server-side

    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, [isClient]); // Add isClient to dependencies to ensure useEffect runs only on client-side

  return windowWidth;
}
