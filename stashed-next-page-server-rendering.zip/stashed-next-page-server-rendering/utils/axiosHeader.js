import Cookies from "js-cookie";

export const getHeader = () => {
  const headers = {
    "Accept": "application/vnd.api+json",
    "Content-Type": "application/vnd.api+json",
    "X-Requested-With": "XMLHttpRequest"
  };
  return headers;
};

export const getAuthenticationHeader = () => {
  const headers = {
    "Accept": "application/json",
    "Content-Type": "application/json",
    "X-Requested-With": "XMLHttpRequest",
    Authorization: "Bearer " + Cookies.get("stashed_token"),
  };
  return headers;
};

