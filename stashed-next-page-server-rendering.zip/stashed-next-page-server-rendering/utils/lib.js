// The idea of having this file is we can write common function. Supposed to used in multiple components.

export const NumberWithCommas = (value) => {
    return value.toLocaleString();
}

export const isEmptyObject = (obj) => {
    return Object.keys(obj).length === 0;
};

export const isMobileUi = (screen) => {
    return screen < 768;
}

