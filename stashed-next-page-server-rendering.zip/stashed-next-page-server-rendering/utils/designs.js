export const handleOnClickNon = () => {
  if (typeof document !== "undefined") {
    let root = document.getElementsByTagName("html")[0];
    root.setAttribute("class", "overflow-hidden");
    document.body.style.overflow = "hidden";
  }
};

export const handleOnClickBlock = () => {
  if (typeof document !== "undefined") {
    let root = document.getElementsByTagName("html")[0];
    root.removeAttribute("class", "overflow-hidden");
    document.body.style.overflow = "visible";
  }
};
