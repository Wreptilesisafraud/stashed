import { useRouter } from "next/router";
import { useMemo } from "react";

export const useQuery = () => {
  const { query } = useRouter();

  return useMemo(
    () =>
      new URLSearchParams(
        Object.entries(query)
          .map(([key, value]) => [
            key,
            Array.isArray(value) ? value.join(",") : value,
          ])
          .join("&")
      ),
    [query]
  );
};
